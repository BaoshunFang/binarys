/** ==========================================================================
 * @file        hml_vml_common.h
 * @copyright   Copyright (c) 2025 Hygon Company. All rights reserved.
 * @author      zhongtao <zhongtao AT hygon DOT cn>
 * @brief       Vector Math Library (VML) commonly used definitions.
 *
 * Provides definitions about:
 * - VML_COMPLEX*
 * - HygonVML_FUNCNAME
 ** ==========================================================================
 */

/* * Copyright (c) 2014, 2015                                          Zhang Xianyi
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _HYGONVML_COMMON_H_
#define _HYGONVML_COMMON_H_

#include "hml_vml_config.h"

/* =------------------------------------= */
/*     VML_COMPLEX8 & VML_COMPLEX16       */
/* =------------------------------------= */
/** HygonVML Complex type for single precision
 * Note that VML_Complex8 could be overwitten by -DVML_COMPLEX8="...".
 */
#ifndef VML_COMPLEX8
typedef
struct _VML_COMPLEX8 {
    float real;
    float imag;
} VML_COMPLEX8;
#endif

/** HygonVML Complex type for double precision
 * Note that VML_COMPLEX16 could be overwitten by -DVML_COMPLEX16="...".
 */
#ifndef VML_COMPLEX16
typedef
struct _VML_COMPLEX16 {
    double real;
    double imag;
} VML_COMPLEX16;
#endif

/* =-------------------------------------------= */
/*     VML_CMPLX_UNION16 & VML_CMPLX_UNION8      */
/* =-------------------------------------------= */
/** @attention: This union type definition assumes that Complex
 * number's real part and imaginary part are stored consecutively in
 * memory.
 */
#if !defined(__STDC_NO_COMPLEX__)
typedef
union {
  double _Complex c;
  VML_COMPLEX16 t;
} VML_CMPLX_UNION16;

typedef
union {
  float _Complex c;
  VML_COMPLEX8 t;
} VML_CMPLX_UNION8;
#endif

/* =---------------------------------------------= */
/*     VML_FLOAT & VML_COMPLEX & VML_CMPLX_UNION   */
/* =---------------------------------------------= */
#ifdef DOUBLE
typedef double            VML_FLOAT;
typedef VML_COMPLEX16     VML_COMPLEX;
typedef VML_CMPLX_UNION16 VML_CMPLX_UNION;
#else /* DOUBLE */
typedef float             VML_FLOAT;
typedef VML_COMPLEX8      VML_COMPLEX;
typedef VML_CMPLX_UNION8  VML_CMPLX_UNION;
#endif /* FLOAT */

#if defined(OS_WINDOWS) && defined(__64BIT__)
typedef long long VMLLONG;
typedef unsigned long long VMLULONG;
#else
typedef long VMLLONG;
typedef unsigned long VMLULONG;
#endif

#ifdef USE64BITINT
typedef VMLLONG VML_INT;
#else
typedef int VML_INT;
#endif

// These macros in the comments below are previously used
//#define HygonVML_FUNCNAME_3(pre,x,suf) pre##x##suf
//#define HygonVML_FUNCNAME_2(pre,x,suf) HygonVML_FUNCNAME_3(pre, x, suf)
//#define HygonVML_FUNCNAME_1(x) HygonVML_FUNCNAME_2(HYGONVML_FUNC_PREFIX, x, HYGONVML_FUNC_SUFFIX)
//#define HygonVML_FUNCNAME(x) HygonVML_FUNCNAME_1(x)

#define HygonVML_FUNCNAME(x) x

#endif
