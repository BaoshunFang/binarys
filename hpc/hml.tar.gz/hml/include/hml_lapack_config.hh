#pragma once

/// @details lapack int宽度和complex 定义

#define SIMD_WIDTH 32 
#define CACHELINE  64   

// 每次调用启用检查 HML_VERBOSE等环境变量
#define HYGON_LAPACK_RUNTIME_CHECK 1

#include <complex>

#define LAPACK_COMPLEX_CUSTOM

typedef std::complex<float> lapack_complex_float;
typedef std::complex<double> lapack_complex_double;

// 使用lapacke的基本定义
#include "hml_lapacke_config.h"

// hblas also define hml_int_t 
// using hml_int_t = lapack_int;
typedef lapack_int hml_int_t;


/// modified by cmake 
#define HLAPACK_VERSION_MAJOR 1
#define HLAPACK_VERSION_MINOR 9
#define HLAPACK_VERSION_PATCH 0

#define HLAPACK_VERSION "1.9.0"
#define HLAPACK_GIT_VERSION "028c75f"
