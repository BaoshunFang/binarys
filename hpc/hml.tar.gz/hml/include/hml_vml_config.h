/** ==========================================================================
 * @file        hml_vml_config.h
 * @copyright   Copyright (c) 2025 Hygon Company. All rights reserved.
 * @author      zhongtao <zhongtao AT hygon DOT cn>
 * @brief       Vector Math Library (VML) configuration file.
 *
 * Provides definitions about:
 * - HYGONVML_ARCH
 * - HYGONVML_SINGLE_THREAD
 ** ==========================================================================
 */

/* * Copyright (c) 2014, 2015                                          Zhang Xianyi
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#define HYGONVML_VERSION_MAJOR 1
#define HYGONVML_VERSION_MINOR 9
#define HYGONVML_VERSION_PATCH 19
#define HYGONVML_GIT_VERSION "028c75f"
#define HYGONVML_FULL_VERSION "1.9.19-028c75f"
#define HYGONVML_COMPILER "GCC 8.5.0"
#define HYGONVML_COMPILER_FULL "gcc (gcc public:gcc-8.5.0 Build:20260409) 8.5.0"

#define HYGONVML_FUNC_PREFIX 
#define HYGONVML_FUNC_SUFFIX 

#define HYGONVML_ARCH x86_64
#define HYGONVML_CPU_CORENAME hygon
#define HYGONVML_BINARY 64

#define HYGONVML_SINGLE_THREAD
/* #undef USE64BITINT */
#define __64BIT__
/* #undef __32BIT__ */
/* #undef OS_WINDOWS */
/* #undef OS_DARWIN */
/* #undef OS_LINUX */

/* #undef COMPILER_MSVC */

#ifdef COMPILER_MSVC
#define inline __inline
#endif
