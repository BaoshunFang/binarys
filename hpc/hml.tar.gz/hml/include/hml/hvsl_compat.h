/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file include/hml/hvsl_compat.h
/// @brief MKL VSL 兼容层公共头——可选独立链接 libhvsl_compat.so。
///
/// 包含此头并链接 libhvsl_compat.so 即可将 MKL VSL 的 vsl*/vi*/vd*/vs*
/// RNG API 替换为 HVSL 实现。兼容层薄转发到 libhvsl.so 原生 API。
///
/// 与 hpc-hppl 的 ipps_compat.h 同为 replacement-style：本头不能与真实
/// MKL 头同时包含，也不表示完整 MKL VSL 兼容。

#pragma once

#include "hml/hvsl.h"
#include "hml/hvsl_rng.h"
#include "hml/hvsl_stats.h"
#include "hml/hvsl_conv.h"

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
//  MKL VSL RNG 兼容符号（libhvsl_compat.so 导出，原生库不导出）
// ============================================================

// ---------------------------------------------------------------------------
// 流管理
// ---------------------------------------------------------------------------

/// @brief 创建随机数流（MKL vslNewStream）。
int vslNewStream(VSLStreamStatePtr* stream, int brng, unsigned int seed);

/// @brief 使用扩展参数创建随机数流。
int vslNewStreamEx(VSLStreamStatePtr* stream, int brng, int n,
                   const unsigned int params[]);

/// @brief 删除随机数流。
int vslDeleteStream(VSLStreamStatePtr* stream);

/// @brief 复制随机数流（深拷贝）。
int vslCopyStream(VSLStreamStatePtr* newstream, VSLStreamStatePtr srcstream);

/// @brief 复制随机数流状态。
int vslCopyStreamState(VSLStreamStatePtr deststream,
                       VSLStreamStatePtr srcstream);

/// @brief 保存流状态到文件。
int vslSaveStreamF(VSLStreamStatePtr stream, const char* fname);

/// @brief 从文件恢复流状态。
int vslLoadStreamF(VSLStreamStatePtr* stream, const char* fname);

/// @brief 保存流状态到内存缓冲区。
int vslSaveStreamM(VSLStreamStatePtr stream, char* memptr);

/// @brief 从内存缓冲区恢复流状态。
int vslLoadStreamM(VSLStreamStatePtr* stream, const char* memptr);

/// @brief 获取流的基础生成器类型。
int vslGetStreamStateBrng(VSLStreamStatePtr stream, int* brng);

/// @brief 获取流状态大小（字节）。
int vslGetStreamSize(VSLStreamStatePtr stream);

/// @brief 获取 BRNG 属性信息（MKL vslGetBrngProperties）。
int vslGetBrngProperties(int brng, VSLBRngProperties* properties);

/// @brief 获取已注册 BRNG 数量（MKL vslGetNumRegBrngs）。
int vslGetNumRegBrngs(void);

/// @brief 跳蛙法将流分裂为并行子流。
int vslLeapfrogStream(VSLStreamStatePtr stream, int k, int nstreams);

/// @brief 跳过流中指定数量的元素。
int vslSkipAheadStream(VSLStreamStatePtr stream, long long int nskip);

/// @brief 跳过流中指定数量的元素（扩展版，MKL vslSkipAheadStreamEx）。
int vslSkipAheadStreamEx(VSLStreamStatePtr stream, int n,
                         const unsigned long long nskip[]);

// ---------------------------------------------------------------------------
// 整型分布
// ---------------------------------------------------------------------------

/// @brief 均匀分布整数（MKL viRngUniform）。
int viRngUniform(int method, VSLStreamStatePtr stream, int n, int r[], int a,
                 int b);

/// @brief 原始 32 位均匀位（MKL 标准名 viRngUniformBits）。
int viRngUniformBits(int method, VSLStreamStatePtr stream, int n,
                     unsigned int r[]);

/// @brief 原始 32 位均匀位（别名）。
int viRngUniformBits32(int method, VSLStreamStatePtr stream, int n,
                       unsigned int r[]);

/// @brief 原始 64 位均匀位。
int viRngUniformBits64(int method, VSLStreamStatePtr stream, int n,
                       openrng_uint64_t r[]);

/// @brief 伯努利分布。
int viRngBernoulli(int method, VSLStreamStatePtr stream, int n, int r[],
                   double p);

/// @brief 几何分布。
int viRngGeometric(int method, VSLStreamStatePtr stream, int n, int r[],
                   double p);

/// @brief 二项分布。
int viRngBinomial(int method, VSLStreamStatePtr stream, int n, int r[],
                  int ntrial, double p);

/// @brief 超几何分布 — 底层为桩函数（NotImplErr）。
int viRngHypergeometric(int method, VSLStreamStatePtr stream, int n, int r[],
                        int l, int s, int m);

/// @brief 泊松分布。
int viRngPoisson(int method, VSLStreamStatePtr stream, int n, int r[],
                 double lambda);

/// @brief 泊松分布（向量化 lambda）。
int viRngPoissonV(int method, VSLStreamStatePtr stream, int n, int r[],
                  const double lambda[]);

/// @brief 负二项分布 — 底层为桩函数（NotImplErr）。
int viRngNegbinomial(int method, VSLStreamStatePtr stream, int n, int r[],
                     double a, double p);

/// @brief 多项分布。
int viRngMultinomial(int method, VSLStreamStatePtr stream, int n, int r[],
                     int k, int m, const double p[]);

// ---------------------------------------------------------------------------
// 浮点分布（float / double）
// ---------------------------------------------------------------------------
/// @brief Uniform 分布（float）。
int vsRngUniform(int method, VSLStreamStatePtr stream, int n, float r[], float a, float b);

/// @brief Uniform 分布（double）。
int vdRngUniform(int method, VSLStreamStatePtr stream, int n, double r[], double a, double b);

/// @brief Gaussian 分布（float）。
int vsRngGaussian(int method, VSLStreamStatePtr stream, int n, float r[], float a, float sigma);

/// @brief Gaussian 分布（double）。
int vdRngGaussian(int method, VSLStreamStatePtr stream, int n, double r[], double a, double sigma);

/// @brief Exponential 分布（float）。
int vsRngExponential(int method, VSLStreamStatePtr stream, int n, float r[], float a, float beta);

/// @brief Exponential 分布（double）。
int vdRngExponential(int method, VSLStreamStatePtr stream, int n, double r[], double a, double beta);

/// @brief Laplace 分布（float）。
int vsRngLaplace(int method, VSLStreamStatePtr stream, int n, float r[], float a, float beta);

/// @brief Laplace 分布（double）。
int vdRngLaplace(int method, VSLStreamStatePtr stream, int n, double r[], double a, double beta);

/// @brief Weibull 分布（float）。
int vsRngWeibull(int method, VSLStreamStatePtr stream, int n, float r[], float alpha, float a, float beta);

/// @brief Weibull 分布（double）。
int vdRngWeibull(int method, VSLStreamStatePtr stream, int n, double r[], double alpha, double a, double beta);

/// @brief Cauchy 分布（float）。
int vsRngCauchy(int method, VSLStreamStatePtr stream, int n, float r[], float a, float beta);

/// @brief Cauchy 分布（double）。
int vdRngCauchy(int method, VSLStreamStatePtr stream, int n, double r[], double a, double beta);

/// @brief Rayleigh 分布（float）。
int vsRngRayleigh(int method, VSLStreamStatePtr stream, int n, float r[], float a, float beta);

/// @brief Rayleigh 分布（double）。
int vdRngRayleigh(int method, VSLStreamStatePtr stream, int n, double r[], double a, double beta);

/// @brief Lognormal 分布（float）。
int vsRngLognormal(int method, VSLStreamStatePtr stream, int n, float r[], float a, float sigma, float b, float disp);

/// @brief Lognormal 分布（double）。
int vdRngLognormal(int method, VSLStreamStatePtr stream, int n, double r[], double a, double sigma, double b, double disp);

/// @brief Gumbel 分布（float）。
int vsRngGumbel(int method, VSLStreamStatePtr stream, int n, float r[], float a, float beta);

/// @brief Gumbel 分布（double）。
int vdRngGumbel(int method, VSLStreamStatePtr stream, int n, double r[], double a, double beta);

/// @brief Gamma 分布（float）。
int vsRngGamma(int method, VSLStreamStatePtr stream, int n, float r[], float alpha, float a, float beta);

/// @brief Gamma 分布（double）。
int vdRngGamma(int method, VSLStreamStatePtr stream, int n, double r[], double alpha, double a, double beta);

/// @brief Beta 分布（float）。
int vsRngBeta(int method, VSLStreamStatePtr stream, int n, float r[], float p, float q, float a, float beta);

/// @brief Beta 分布（double）。
int vdRngBeta(int method, VSLStreamStatePtr stream, int n, double r[], double p, double q, double a, double beta);

/// @brief 多元高斯分布（float）。
int vsRngGaussianMV(int method, VSLStreamStatePtr stream, int n, float r[],
                    int dimen, int mstorage, const float a[], const float t[]);

/// @brief 多元高斯分布（double）。
int vdRngGaussianMV(int method, VSLStreamStatePtr stream, int n, double r[],
                    int dimen, int mstorage, const double a[],
                    const double t[]);

/// @brief 卡方分布（double）— 未实现。
int vdRngChiSquare(int method, VSLStreamStatePtr stream, int n, double r[],
                   int df);

/// @brief 卡方分布（float）— 未实现。
int vsRngChiSquare(int method, VSLStreamStatePtr stream, int n, float r[],
                   int df);

/// @brief 注册自定义 BRNG — 不支持。
int vslRegisterBrng(const VSLBRngProperties* properties);

/// @brief 创建抽象流（double）— 未实现。
int vsldNewAbstractStream(VSLStreamStatePtr* stream, int n,
                          const double params[], double a, double beta,
                          const void* r);

/// @brief 创建抽象流（int）— 未实现。
int vsliNewAbstractStream(VSLStreamStatePtr* stream, int n,
                          const unsigned int params[], const void* r);

/// @brief 创建抽象流（float）— 未实现。
int vslsNewAbstractStream(VSLStreamStatePtr* stream, int n,
                          const float params[], float a, float beta,
                          const void* r);

#ifdef __cplusplus
}
#endif
