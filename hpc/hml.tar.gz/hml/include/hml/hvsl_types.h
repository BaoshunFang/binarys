/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file   hvsl_types.h
/// @brief  HVSL 核心类型定义 — 状态码、后端、BRNG、分发方法、数据结构等。

#pragma once

#include <stddef.h>
#include <stdint.h>

#if defined(_WIN32) || defined(__CYGWIN__)
  #ifdef HVSL_BUILDING_LIBRARY
    #define HVSL_API __declspec(dllexport)
    #define HML_EXPORT __declspec(dllexport)
  #else
    #define HVSL_API __declspec(dllimport)
    #define HML_EXPORT __declspec(dllimport)
  #endif
#else
  #define HVSL_API __attribute__((visibility("default")))
  #define HML_EXPORT __attribute__((visibility("default")))
#endif

/// @brief CPU feature flags — populated by CPUID/XGETBV at library init.
typedef struct
{
    int avx;
    int avx2;
    int fma3;
    int osxsave;
    int xcr0_xmm_ymm;
    int avx512f;
    int avx512dq;
    int avx512bw;
    int avx512vl;
    int xcr0_opmask_zmm;
    int rdrand;
} HvslCpuFeatures;

/// @brief HVSL status codes（数值与 MKL VSL_ERROR_* 对齐）。
typedef enum
{
    HvslStatusNoErr = 0,
    HvslStatusNotImplErr = -1,            ///< VSL_ERROR_FEATURE_NOT_IMPLEMENTED
    HvslStatusInternalErr = -2,           ///< VSL_ERROR_UNKNOWN
    HvslStatusBadArgErr = -3,             ///< VSL_ERROR_BADARGS
    HvslStatusMemErr = -4,                ///< VSL_ERROR_MEM_FAILURE
    HvslStatusNullPtrErr = -5,            ///< VSL_ERROR_NULL_PTR
    HvslStatusBackendUnsupportedErr = -6, ///< VSL_ERROR_CPU_NOT_SUPPORTED

    // VSL_RNG_ERROR_* 专用错误码（与 MKL 数值一致）
    HvslStatusLeapfrogUnsupportedErr = -1002, ///< VSL_RNG_ERROR_LEAPFROG_UNSUPPORTED
    HvslStatusSkipAheadUnsupportedErr = -1003, ///< VSL_RNG_ERROR_SKIPAHEAD_UNSUPPORTED
    HvslStatusSkipAheadExUnsupportedErr = -1004, ///< VSL_RNG_ERROR_SKIPAHEADEX_UNSUPPORTED
    HvslStatusBrngsIncompatibleErr = -1005, ///< VSL_RNG_ERROR_BRNGS_INCOMPATIBLE
    HvslStatusBrngNotSupportedErr = -1014, ///< VSL_RNG_ERROR_BRNG_NOT_SUPPORTED
    HvslStatusNondetermNotSupportedErr = -1130, ///< VSL_RNG_ERROR_NONDETERM_NOT_SUPPORTED
    HvslStatusArs5NotSupportedErr = -1140, ///< VSL_RNG_ERROR_ARS5_NOT_SUPPORTED
} HvslStatus;

/// @brief HVSL backend selection.
typedef enum
{
    HvslBackendAuto = 0,
    HvslBackendAvx2 = 1,
    HvslBackendAvx512 = 2,
} HvslBackend;

/// @brief RNG base generator identifiers.
///
/// 数值与 Intel MKL VSL 的 `VSL_BRNG_*` 位空间一致（步进 1<<20），
/// 每个 BRNG 族预留 2^20 个子流编号空间（如 MT2203: base + i, i < 6024），
/// 保证 base ID 与子流 ID 互不重叠。
typedef enum
{
    HVSL_BRNG_MCG31         = 0x100000,
    HVSL_BRNG_R250          = 0x200000,
    HVSL_BRNG_MRG32K3A      = 0x300000,
    HVSL_BRNG_MCG59         = 0x400000,
    HVSL_BRNG_WH            = 0x500000,
    HVSL_BRNG_SOBOL         = 0x600000,
    HVSL_BRNG_NIEDERR       = 0x700000,
    HVSL_BRNG_MT19937       = 0x800000,
    HVSL_BRNG_MT2203        = 0x900000,
    HVSL_BRNG_IABSTRACT     = 0xA00000,
    HVSL_BRNG_DABSTRACT     = 0xB00000,
    HVSL_BRNG_SABSTRACT     = 0xC00000,
    HVSL_BRNG_SFMT19937     = 0xD00000,
    HVSL_BRNG_NONDETERM     = 0xE00000,
    HVSL_BRNG_ARS5          = 0xF00000,
    HVSL_BRNG_PHILOX4X32X10 = 0x1000000,
} HvslBrng;

/// @brief RNG 分布方法精度标志（与 MKL `VSL_RNG_METHOD_ACCURACY_FLAG` 一致）。
#define HVSL_RNG_METHOD_ACCURACY_FLAG (1 << 30)

/// @brief RNG distribution method identifiers。
///
/// 数值与 Intel MKL VSL 的 `VSL_RNG_METHOD_*` 逐位一致：每个分布的
/// standard 方法均为 0（部分分布 0/1/2 区分具体算法），accurate 变体
/// 在 standard 值上置 HVSL_RNG_METHOD_ACCURACY_FLAG。不同分布可共用
/// 相同的数值（方法编号按分布命名空间解释，与 MKL 一致）。
typedef enum
{
    HVSL_RNG_METHOD_UNIFORM_STD = 0,
    HVSL_RNG_METHOD_UNIFORM_STD_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,
    HVSL_RNG_METHOD_UNIFORMBITS_STD = 0,
    HVSL_RNG_METHOD_UNIFORMBITS32_STD = 0,
    HVSL_RNG_METHOD_UNIFORMBITS64_STD = 0,

    HVSL_RNG_METHOD_GAUSSIAN_BOXMULLER = 0,
    HVSL_RNG_METHOD_GAUSSIAN_BOXMULLER2 = 1,
    HVSL_RNG_METHOD_GAUSSIAN_ICDF = 2,

    HVSL_RNG_METHOD_GAUSSIANMV_BOXMULLER = 0,
    HVSL_RNG_METHOD_GAUSSIANMV_BOXMULLER2 = 1,
    HVSL_RNG_METHOD_GAUSSIANMV_ICDF = 2,

    HVSL_RNG_METHOD_EXPONENTIAL_ICDF = 0,
    HVSL_RNG_METHOD_EXPONENTIAL_ICDF_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,

    HVSL_RNG_METHOD_LAPLACE_ICDF = 0,

    HVSL_RNG_METHOD_WEIBULL_ICDF = 0,
    HVSL_RNG_METHOD_WEIBULL_ICDF_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,

    HVSL_RNG_METHOD_CAUCHY_ICDF = 0,

    HVSL_RNG_METHOD_RAYLEIGH_ICDF = 0,
    HVSL_RNG_METHOD_RAYLEIGH_ICDF_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,

    HVSL_RNG_METHOD_LOGNORMAL_BOXMULLER2 = 0,
    HVSL_RNG_METHOD_LOGNORMAL_ICDF = 1,
    HVSL_RNG_METHOD_LOGNORMAL_BOXMULLER2_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,
    HVSL_RNG_METHOD_LOGNORMAL_ICDF_ACCURATE = 1 | HVSL_RNG_METHOD_ACCURACY_FLAG,

    HVSL_RNG_METHOD_GUMBEL_ICDF = 0,

    HVSL_RNG_METHOD_GAMMA_GNORM = 0,
    HVSL_RNG_METHOD_GAMMA_GNORM_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,

    HVSL_RNG_METHOD_BETA_CJA = 0,
    HVSL_RNG_METHOD_BETA_CJA_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,

    HVSL_RNG_METHOD_CHISQUARE_CHI2GAMMA = 0,
    HVSL_RNG_METHOD_CHISQUARE_CHI2GAMMA_ACCURATE = 0 | HVSL_RNG_METHOD_ACCURACY_FLAG,

    HVSL_RNG_METHOD_BERNOULLI_ICDF = 0,

    HVSL_RNG_METHOD_POISSON_PTPE = 0,
    HVSL_RNG_METHOD_POISSON_POISNORM = 1,
    HVSL_RNG_METHOD_POISSONV_POISNORM = 0,

    HVSL_RNG_METHOD_BINOMIAL_BTPE = 0,
    HVSL_RNG_METHOD_MULTINOMIAL_MULTPOISSON = 0,
    HVSL_RNG_METHOD_GEOMETRIC_ICDF = 0,
    HVSL_RNG_METHOD_HYPERGEOMETRIC_H2PE = 0,
    HVSL_RNG_METHOD_NEGBINOMIAL_NBAR = 0,
} HvslRngMethod;

#define HVSL_MATRIX_STORAGE_FULL    0
#define HVSL_MATRIX_STORAGE_PACKED  1
#define HVSL_MATRIX_STORAGE_DIAGONAL 2

/// @name 内部迁移兼容别名
/// @{

// Legacy type aliases for internal migration compatibility
typedef int hvsl_int_t;
typedef int openrng_int_t;
typedef uint64_t openrng_uint64_t;
typedef void* HvslStreamStatePtr;
#define VSLStreamStatePtr HvslStreamStatePtr

// Legacy error codes for internal migration
#define VSL_DISTR_MULTINOMIAL_BAD_PROBABILITY_ARRAY  HvslStatusBadArgErr
#define VSL_RNG_ERROR_BRNG_NOT_SUPPORTED             HvslStatusNotImplErr
#define VSL_RNG_ERROR_FILE_OPEN                      HvslStatusBadArgErr
#define VSL_RNG_ERROR_FILE_READ                      HvslStatusInternalErr
#define VSL_RNG_ERROR_FILE_WRITE                     HvslStatusInternalErr
#define VSL_RNG_ERROR_FILE_CLOSE                     HvslStatusInternalErr

typedef int openrng_uint_t;

// QRNG flags
#define HVSL_USER_QRNG_INITIAL_VALUES      0x1
#define HVSL_USER_PRIMITIVE_POLYMS          0x1
#define HVSL_USER_IRRED_POLYMS              0x1
#define HVSL_USER_INIT_DIRECTION_NUMBERS    0x2
#define HVSL_USER_DIRECTION_NUMBERS         0x4
#define HVSL_QRNG_OVERRIDE_1ST_DIM_INIT     0x8
/// @}

/// @brief BRNG properties struct (legacy openrng compatibility).
typedef struct
{
    int StreamStateSize;
    void* InitStream;
    int sBRng;
    int dBRng;
    int iBRng;
    int NSeeds;
    int IncludesZero;
    int WordSize;
    int NBits;
} VSLBRngProperties;

/// @brief Data type identifiers for Statistics and Convolution operations.
typedef enum
{
    HVSL_DTYPE_F32 = 0,
    HVSL_DTYPE_F64 = 1,
    HVSL_DTYPE_F32C = 2,
    HVSL_DTYPE_F64C = 3,
    HVSL_DTYPE_I32 = 4,
    HVSL_DTYPE_I64 = 5,
    HVSL_DTYPE_U32 = 6,
    HVSL_DTYPE_U64 = 7,
} HvslDtype;

/// @brief Statistics operation type.
typedef enum
{
    HVSL_STATS_OP_SUM = 0,
    HVSL_STATS_OP_DOTPROD = 1,
    HVSL_STATS_OP_MIN = 2,
    HVSL_STATS_OP_MAX = 3,
    HVSL_STATS_OP_MEAN = 4,
    HVSL_STATS_OP_STDDEV = 5,
    HVSL_STATS_OP_NORM_L1 = 6,
    HVSL_STATS_OP_NORM_L2 = 7,
    HVSL_STATS_OP_NORM_INF = 8,
} HvslStatsOp;

/// @brief Statistics task storage format for estimates.
typedef enum
{
    HVSL_STATS_STORAGE_FULL = 0,
    HVSL_STATS_STORAGE_DIAGONAL = 1,
} HvslStatsStorage;

/// @brief Convolution mode.
typedef enum
{
    HVSL_CONV_MODE_FULL = 0,
    HVSL_CONV_MODE_SAME = 1,
    HVSL_CONV_MODE_VALID = 2,
} HvslConvMode;

/// @brief Convolution algorithm selection.
/// 数值与 MKL `VSL_CONV_MODE_*` 一致（AUTO=0/DIRECT=1/FFT=2）。
typedef enum
{
    HVSL_CONV_ALGO_AUTO = 0,
    HVSL_CONV_ALGO_DIRECT = 1,
    HVSL_CONV_ALGO_FFT = 2,
} HvslConvAlgo;

/// @brief ──── Statistics: 统计量位掩码（与 MKL VSL_SS_* 值逐位一致）────
/// 通过位或组合多个统计量，一次 Compute 调用即可全部计算。
typedef enum
{
    HVSL_SS_MEAN = 0x0000000000000001,
    HVSL_SS_2R_MOM = 0x0000000000000002,
    HVSL_SS_3R_MOM = 0x0000000000000004,
    HVSL_SS_4R_MOM = 0x0000000000000008,
    HVSL_SS_2C_MOM = 0x0000000000000010,
    HVSL_SS_3C_MOM = 0x0000000000000020,
    HVSL_SS_4C_MOM = 0x0000000000000040,
    HVSL_SS_KURTOSIS = 0x0000000000000080,
    HVSL_SS_SKEWNESS = 0x0000000000000100,
    HVSL_SS_VARIATION = 0x0000000000000200,
    HVSL_SS_MIN = 0x0000000000000400,
    HVSL_SS_MAX = 0x0000000000000800,
    HVSL_SS_COV = 0x0000000000001000,
    HVSL_SS_COR = 0x0000000000002000,
    HVSL_SS_POOLED_COV = 0x0000000000004000,
    HVSL_SS_GROUP_COV = 0x0000000000008000,
    HVSL_SS_QUANTS = 0x0000000000010000,
    HVSL_SS_ORDER_STATS = 0x0000000000020000,
    HVSL_SS_ROBUST_COV = 0x0000000000040000,
    HVSL_SS_OUTLIERS = 0x0000000000080000,
    HVSL_SS_PARTIAL_COV = 0x0000000000100000,
    HVSL_SS_PARTIAL_COR = 0x0000000000200000,
    HVSL_SS_MISSING_VALS = 0x0000000000400000,
    HVSL_SS_PARAMTR_COR = 0x0000000000800000,
    HVSL_SS_STREAM_QUANTS = 0x0000000001000000,
    HVSL_SS_SUM = 0x0000000002000000,
    HVSL_SS_2R_SUM = 0x0000000004000000,
    HVSL_SS_3R_SUM = 0x0000000008000000,
    HVSL_SS_4R_SUM = 0x0000000010000000,
    HVSL_SS_2C_SUM = 0x0000000020000000,
    HVSL_SS_3C_SUM = 0x0000000040000000
} HvslSsEstimates;

// 超出 int 范围的估计量位标志：ISO C（C23 前）限制枚举值必须在 int
// 范围内，-Wpedantic 下报错。改为宏定义（与 MKL VSL 的 VSL_SS_* 宏
// 风格一致），数值与语义不变。
#define HVSL_SS_4C_SUM 0x0000000080000000u
#define HVSL_SS_CP 0x0000000100000000ULL
#define HVSL_SS_MDAD 0x0000000200000000ULL
#define HVSL_SS_MNAD 0x0000000400000000ULL
#define HVSL_SS_POOLED_MEAN 0x0000000800000000ULL
#define HVSL_SS_GROUP_MEAN 0x0000001000000000ULL
#define HVSL_SS_SORTED_OBSERV 0x0000008000000000ULL

/// @brief Statistics computation methods.
typedef enum
{
    HVSL_SS_METHOD_FAST = 0,
    HVSL_SS_METHOD_1PASS = 1,
    HVSL_SS_METHOD_FAST_USER_MEAN = 2,
    HVSL_SS_METHOD_CP_TO_COVCOR = 3,
    HVSL_SS_METHOD_SUM_TO_MOM = 4,
    HVSL_SS_METHOD_SD = 5,
    HVSL_SS_METHOD_TBS = 6,
    HVSL_SS_METHOD_MI = 7,
    HVSL_SS_METHOD_BACON = 8,
    HVSL_SS_METHOD_SQUANTS_ZW = 9,
    HVSL_SS_METHOD_SQUANTS_ZW_FAST = 10,
    HVSL_SS_METHOD_RADIX = 11,
} HvslSsMethod;

/// @brief Matrix storage layout for observations and covariance/correlation output.
typedef enum
{
    HVSL_SS_MATRIX_STORAGE_ROWS = 0,
    HVSL_SS_MATRIX_STORAGE_COLS = 1,
    HVSL_SS_MATRIX_STORAGE_FULL = 2,
    HVSL_SS_MATRIX_STORAGE_L_PACKED = 3,
    HVSL_SS_MATRIX_STORAGE_U_PACKED = 4,
} HvslSsMatrixStorage;

/// @brief ──── Statistics: params 结构体（一次声明所有输出 buffer）────
/// 用户填充需要的字段（非 NULL = 需要该统计量），一次 hvslStatsCompute 完成所有计算。
typedef struct
{
    int dim;        int64_t n_observ;  
    const void* data;                  
    int data_layout;                   
    const void* weights;               
    double* mean;
    double* raw_mom2;
    double* raw_mom3;
    double* raw_mom4;
    double* cen_mom2;
    double* cen_mom3;
    double* cen_mom4;
    double* sum;
    double* raw_sum2;
    double* raw_sum3;
    double* raw_sum4;
    double* cen_sum2;
    double* cen_sum3;
    double* cen_sum4;
    double* kurtosis;
    double* skewness;
    double* variation;
    double* min;
    double* max;
    void* cov;
    void* cor;
    void* cp;
    int cov_storage;
    int cor_storage;
    int cp_storage;
    void* pooled_cov;
    void* pooled_mean;
    void* group_cov;
    void* group_mean;
    const int* group_indices;
    int n_groups;
    void* quantiles;
    int quant_order_n;
    const double* quant_order;
    void* order_stats;
    void* sorted_observ;
    void* robust_cov;
    void* robust_mean;
    void* outliers;
    void* outlier_weights;
    void* partial_cov;
    void* partial_cor;
    void* missing_vals;
    void* mi_params;
    void* mi_estimates;
    void* stream_quants;
    void* paramtr_cor;
    double* mdad;
    double* mnad;
} HvslStatsParams;

/// @brief ──── Convolution: params 结构体（统一多维/1D/X/X1D）────
typedef struct
{
    int ndim;                          
    int64_t xshape[3];                 
    int64_t yshape[3];                 
    int64_t zshape[3];                 
    int mode;                          
    int algo;                          
    int dtype;                         
    int internal_precision;            
    int64_t start[3];                  
    int64_t decimation[3];             
    int is_correlation;                
    const void* x;                     
    const void* y;                     
    void* z;                           
    const void* ref_data;              
    int64_t ref_len;                   
} HvslConvParams;

/// @brief Opaque stream handle for RNG.
typedef struct HvslStreamImpl* HvslStream;

/// @brief Opaque task handle for Statistics.
typedef struct HvslStatsTaskImpl* HvslStatsTask;

/// @brief Opaque task handle for Convolution.
typedef struct HvslConvTaskImpl* HvslConvTask;

/// @name hml_vsl_ 类型别名 — HML 统一命名规范
/// @{

typedef HvslStatus       hml_vsl_status_t;
typedef HvslBackend      hml_vsl_backend_t;
typedef HvslBrng         hml_vsl_brng_t;
typedef HvslRngMethod    hml_vsl_rng_method_t;
typedef HvslStatsOp      hml_vsl_stats_op_t;
typedef HvslStatsStorage hml_vsl_stats_storage_t;
typedef HvslConvMode     hml_vsl_conv_mode_t;
typedef HvslStream       hml_vsl_stream_t;
typedef HvslStatsTask    hml_vsl_stats_task_t;
typedef HvslConvTask     hml_vsl_conv_task_t;
typedef VSLBRngProperties hml_vsl_brng_properties_t;

// hml_vsl_ status codes
#define HML_VSL_STATUS_NO_ERR              HvslStatusNoErr
#define HML_VSL_STATUS_BAD_ARG             HvslStatusBadArgErr
#define HML_VSL_STATUS_MEM_ERR             HvslStatusMemErr
#define HML_VSL_STATUS_NOT_IMPL            HvslStatusNotImplErr
#define HML_VSL_STATUS_BACKEND_UNSUPPORTED HvslStatusBackendUnsupportedErr
#define HML_VSL_STATUS_INTERNAL_ERR        HvslStatusInternalErr

// hml_vsl_ backend constants
#define HML_VSL_BACKEND_AUTO   HvslBackendAuto
#define HML_VSL_BACKEND_AVX2   HvslBackendAvx2
#define HML_VSL_BACKEND_AVX512 HvslBackendAvx512
/// @}
