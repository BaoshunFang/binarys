/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

#pragma once

/// @file   hvsl_mkl_compat.h
/// @brief  MKL VSL 兼容 API 层 — 所有 MKL 接口的薄封装
///
/// 设计原则：
///   - 全部 API 实现为 inline 函数（zero-cost abstraction）
///   - MKL 的多精度多变量函数统一展开到 HVSL Layer 2 引擎
///   - 24 个专用编辑器用宏生成，单次展开
///   - 32 个 Conv 创建/执行函数用宏生成，机械映射
///
/// 用法：用户只需 `#include <hml/hvsl_mkl_compat.h>`，零修改迁移旧代码。

#include <hml/hvsl_mkl_constants.h>
#include <hml/hvsl_stats.h>
#include <hml/hvsl_conv.h>
#include <hml/hvsl_types.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
//  MKL VSL type aliases（MKL 旧类型名 → HVSL 新类型名）
// ============================================================

typedef HvslStatsTask VSLSSTaskPtr;
typedef HvslConvTask  VSLConvTaskPtr;

// ============================================================
//  Statistics: Task 管理（3 个 × 2 精度 = 6，统一映射到 hvslStatsNewTask）
// ============================================================

static inline int vsldSSNewTask(VSLSSTaskPtr* task, const int* dim,
                                const int64_t* n_observ, const int* storage)
{
    HvslStatus st = hvslStatsNewTask(task, HVSL_DTYPE_F64);
    if (st != HvslStatusNoErr) return st;
    hvslStatsEditTask(*task, HVSL_SS_ED_DIMEN, dim);
    hvslStatsEditTask(*task, HVSL_SS_ED_OBSERV_N, n_observ);
    hvslStatsEditTask(*task, HVSL_SS_ED_OBSERV_STORAGE, storage);
    return HvslStatusNoErr;
}

static inline int vslsSSNewTask(VSLSSTaskPtr* task, const int* dim,
                                const int64_t* n_observ, const int* storage)
{
    HvslStatus st = hvslStatsNewTask(task, HVSL_DTYPE_F32);
    if (st != HvslStatusNoErr) return st;
    hvslStatsEditTask(*task, HVSL_SS_ED_DIMEN, dim);
    hvslStatsEditTask(*task, HVSL_SS_ED_OBSERV_N, n_observ);
    hvslStatsEditTask(*task, HVSL_SS_ED_OBSERV_STORAGE, storage);
    return HvslStatusNoErr;
}

static inline int vslSSDeleteTask(VSLSSTaskPtr* task)
{
    return hvslStatsDeleteTask(task);
}

// ============================================================
//  Statistics: 通用任务编辑器（3 个）
// ============================================================

static inline int vsldSSEditTask(VSLSSTaskPtr task, int param_id, const double* value)
{
    return hvslStatsEditTask(task, param_id, value);
}

static inline int vslsSSEditTask(VSLSSTaskPtr task, int param_id, const float* value)
{
    return hvslStatsEditTask(task, param_id, value);
}

static inline int vsliSSEditTask(VSLSSTaskPtr task, int param_id, const int* value)
{
    return hvslStatsEditTask(task, param_id, value);
}

// ============================================================
//  Statistics: 专用任务编辑器 — 宏生成（24 个）
//  每个专用编辑器映射到一组 hvslStatsEditTask 调用
// ============================================================

#define HVSL_MKL_GEN_SS_EDITOR(name, double_type, float_type)                    \
    static inline int vsldSSEdit##name(VSLSSTaskPtr task, double_type* a,        \
                                        double_type* b, double_type* c,          \
                                        double_type* d, double_type* e,          \
                                        double_type* f)                          \
    {                                                                             \
        int rc = 0;                                                               \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_A, a);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_B, b);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_C, c);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_D, d);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_E, e);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_F, f);                 \
        return rc;                                                                \
    }                                                                             \
    static inline int vslsSSEdit##name(VSLSSTaskPtr task, float_type* a,         \
                                        float_type* b, float_type* c,            \
                                        float_type* d, float_type* e,            \
                                        float_type* f)                           \
    {                                                                             \
        int rc = 0;                                                               \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_A, a);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_B, b);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_C, c);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_D, d);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_E, e);                 \
        rc |= hvslStatsEditTask(task, HVSL_SS_ED_##name##_F, f);                 \
        return rc;                                                                \
    }

// 实际映射：每个 MKL 专用编辑器对应一组 EditTask 调用
// Momentes: raw_mom2/3/4 + cen_mom2/3/4（6 个参数）
static inline int vsldSSEditMoments(VSLSSTaskPtr task,
    double* r2m, double* r3m, double* r4m,
    double* c2m, double* c3m, double* c4m)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2R_MOM, r2m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3R_MOM, r3m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4R_MOM, r4m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2C_MOM, c2m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3C_MOM, c3m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4C_MOM, c4m);
    return rc;
}
static inline int vslsSSEditMoments(VSLSSTaskPtr task,
    float* r2m, float* r3m, float* r4m,
    float* c2m, float* c3m, float* c4m)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2R_MOM, r2m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3R_MOM, r3m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4R_MOM, r4m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2C_MOM, c2m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3C_MOM, c3m);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4C_MOM, c4m);
    return rc;
}

// Sums: sum + 2R/3R/4R/2C/3C/4C sum
static inline int vsldSSEditSums(VSLSSTaskPtr task,
    double* sum, double* r2s, double* r3s, double* r4s,
    double* c2s, double* c3s, double* c4s)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_SUM, sum);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2R_SUM, r2s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3R_SUM, r3s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4R_SUM, r4s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2C_SUM, c2s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3C_SUM, c3s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4C_SUM, c4s);
    return rc;
}
static inline int vslsSSEditSums(VSLSSTaskPtr task,
    float* sum, float* r2s, float* r3s, float* r4s,
    float* c2s, float* c3s, float* c4s)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_SUM, sum);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2R_SUM, r2s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3R_SUM, r3s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4R_SUM, r4s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_2C_SUM, c2s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_3C_SUM, c3s);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_4C_SUM, c4s);
    return rc;
}

// Convariance/Correlation matrix
static inline int vsldSSEditCovCor(VSLSSTaskPtr task,
    double* cov, int* cov_storage, double* cor, int* cor_storage)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COV, cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COV_STORAGE, cov_storage);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COR, cor);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COR_STORAGE, cor_storage);
    return rc;
}
static inline int vslsSSEditCovCor(VSLSSTaskPtr task,
    float* cov, int* cov_storage, float* cor, int* cor_storage)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COV, cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COV_STORAGE, cov_storage);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COR, cor);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_COR_STORAGE, cor_storage);
    return rc;
}

// Cross Product matrix
static inline int vsldSSEditCP(VSLSSTaskPtr task,
    double* cp, int* cp_storage)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_CP, cp);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_CP_STORAGE, cp_storage);
    return rc;
}
static inline int vslsSSEditCP(VSLSSTaskPtr task,
    float* cp, int* cp_storage)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_CP, cp);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_CP_STORAGE, cp_storage);
    return rc;
}

// Partial Covariance/Correlation
static inline int vsldSSEditPartialCovCor(VSLSSTaskPtr task,
    double* partial_cov, double* partial_cor)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_PARTIAL_COV, partial_cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_PARTIAL_COR, partial_cor);
    return rc;
}
static inline int vslsSSEditPartialCovCor(VSLSSTaskPtr task,
    float* partial_cov, float* partial_cor)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_PARTIAL_COV, partial_cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_PARTIAL_COR, partial_cor);
    return rc;
}

// Quantiles
static inline int vsldSSEditQuantiles(VSLSSTaskPtr task,
    int* quant_order_n, double* quant_order, double* quantiles)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_QUANT_ORDER_N, quant_order_n);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_QUANT_ORDER, quant_order);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_QUANT_QUANTILES, quantiles);
    return rc;
}
static inline int vslsSSEditQuantiles(VSLSSTaskPtr task,
    int* quant_order_n, float* quant_order, float* quantiles)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_QUANT_ORDER_N, quant_order_n);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_QUANT_ORDER, quant_order);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_QUANT_QUANTILES, quantiles);
    return rc;
}

// Stream Quantiles
static inline int vsldSSEditStreamQuantiles(VSLSSTaskPtr task,
    void* stream_quant_params)
{
    return hvslStatsEditTask(task, HVSL_SS_ED_STREAM_QUANT_PARAMS, stream_quant_params);
}
static inline int vslsSSEditStreamQuantiles(VSLSSTaskPtr task,
    void* stream_quant_params)
{
    return hvslStatsEditTask(task, HVSL_SS_ED_STREAM_QUANT_PARAMS, stream_quant_params);
}

// Pooled Covariance
static inline int vsldSSEditPooledCovariance(VSLSSTaskPtr task,
    double* pooled_cov, double* pooled_mean)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_POOLED_COV, pooled_cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_POOLED_MEAN, pooled_mean);
    return rc;
}
static inline int vslsSSEditPooledCovariance(VSLSSTaskPtr task,
    float* pooled_cov, float* pooled_mean)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_POOLED_COV, pooled_cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_POOLED_MEAN, pooled_mean);
    return rc;
}

// Robust Covariance
static inline int vsldSSEditRobustCovariance(VSLSSTaskPtr task,
    double* robust_cov, double* robust_mean)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_ROBUST_COV, robust_cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_ROBUST_MEAN, robust_mean);
    return rc;
}
static inline int vslsSSEditRobustCovariance(VSLSSTaskPtr task,
    float* robust_cov, float* robust_mean)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_ROBUST_COV, robust_cov);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_ROBUST_MEAN, robust_mean);
    return rc;
}

// Outliers Detection
static inline int vsldSSEditOutliersDetection(VSLSSTaskPtr task,
    double* outliers, double* outlier_weights)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_OUTLIERS, outliers);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_OUTLIERS_WEIGHT, outlier_weights);
    return rc;
}
static inline int vslsSSEditOutliersDetection(VSLSSTaskPtr task,
    float* outliers, float* outlier_weights)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_OUTLIERS, outliers);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_OUTLIERS_WEIGHT, outlier_weights);
    return rc;
}

// Missing Values
static inline int vsldSSEditMissingValues(VSLSSTaskPtr task,
    void* mi_params, void* mi_estimates)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_MI_PARAMS, mi_params);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_MI_ESTIMATES, mi_estimates);
    return rc;
}
static inline int vslsSSEditMissingValues(VSLSSTaskPtr task,
    void* mi_params, void* mi_estimates)
{
    int rc = 0;
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_MI_PARAMS, mi_params);
    rc |= hvslStatsEditTask(task, HVSL_SS_ED_MI_ESTIMATES, mi_estimates);
    return rc;
}

// Correlation Parameterization
static inline int vsldSSEditCorParameterization(VSLSSTaskPtr task,
    void* paramtr_cor)
{
    return hvslStatsEditTask(task, HVSL_SS_ED_PARAMTR_COR, paramtr_cor);
}
static inline int vslsSSEditCorParameterization(VSLSSTaskPtr task,
    void* paramtr_cor)
{
    return hvslStatsEditTask(task, HVSL_SS_ED_PARAMTR_COR, paramtr_cor);
}

// ============================================================
//  Statistics: 计算执行（2 个 × 2 精度 = 4）
// ============================================================

static inline int vsldSSCompute(VSLSSTaskPtr task, uint64_t estimates, int method)
{
    return hvslStatsCompute(task, estimates, method, nullptr);
}

static inline int vslsSSCompute(VSLSSTaskPtr task, uint64_t estimates, int method)
{
    return hvslStatsCompute(task, estimates, method, nullptr);
}

// ============================================================
//  Convolution: 任务创建 — 宏生成（32 个）
// ============================================================

#define HVSL_MKL_CONV_NEW_TASK(prefix, task_type, dtype_val, suffix, dim_form, corr) \
    static inline int prefix##task_type##NewTask##suffix(VSLConvTaskPtr* task, \
        int mode, int64_t* xshape, int64_t* yshape, int64_t* zshape)     \
    {                                                                       \
        HvslConvParams p;                                                   \
        int i;                                                              \
        for (i = 0; i < (dim_form); ++i) p.xshape[i] = xshape[i];          \
        for (i = 0; i < (dim_form); ++i) p.yshape[i] = yshape[i];          \
        for (i = 0; i < (dim_form); ++i) p.zshape[i] = zshape[i];          \
        p.ndim = (dim_form);                                                \
        p.mode = mode;                                                      \
        p.dtype = (dtype_val);                                              \
        p.algo = HVSL_CONV_ALGO_DIRECT;                                     \
        p.internal_precision = 1;                                           \
        p.is_correlation = (corr);                                          \
        p.ref_data = nullptr;                                               \
        p.ref_len = 0;                                                      \
        p.x = nullptr; p.y = nullptr; p.z = nullptr;                        \
        return hvslConvNewTask(task, &p);                                   \
    }

#define HVSL_MKL_CONV_NEW_TASK_X(prefix, task_type, dtype_val, suffix, dim_form, corr) \
    static inline int prefix##task_type##NewTask##suffix(VSLConvTaskPtr* task, \
        int mode, int64_t* xshape, int64_t* yshape, int64_t* zshape,      \
        const void* x, int64_t xstride)                                     \
    {                                                                       \
        HvslConvParams p;                                                   \
        int i;                                                              \
        (void)xstride;                                                      \
        for (i = 0; i < (dim_form); ++i) p.xshape[i] = xshape[i];          \
        for (i = 0; i < (dim_form); ++i) p.yshape[i] = yshape[i];          \
        for (i = 0; i < (dim_form); ++i) p.zshape[i] = zshape[i];          \
        p.ndim = (dim_form);                                                \
        p.mode = mode;                                                      \
        p.dtype = (dtype_val);                                              \
        p.algo = HVSL_CONV_ALGO_DIRECT;                                     \
        p.internal_precision = 1;                                           \
        p.is_correlation = (corr);                                          \
        p.ref_data = x;                                                     \
        p.ref_len = xshape[0];                                              \
        p.x = nullptr; p.y = nullptr; p.z = nullptr;                        \
        return hvslConvNewTask(task, &p);                                   \
    }

// Conv: double precision
HVSL_MKL_CONV_NEW_TASK(vsld, Conv, 1, 1D, 1, 0)        // HVSL_DTYPE_F64
HVSL_MKL_CONV_NEW_TASK(vsld, Conv, 1, ,   1, 0)

// Conv: float precision
HVSL_MKL_CONV_NEW_TASK(vsls, Conv, 0, 1D, 1, 0)        // HVSL_DTYPE_F32
HVSL_MKL_CONV_NEW_TASK(vsls, Conv, 0, ,   1, 0)

// Conv: Complex double
HVSL_MKL_CONV_NEW_TASK(vslz, Conv, 3, 1D, 1, 0)        // HVSL_DTYPE_F64C
HVSL_MKL_CONV_NEW_TASK(vslz, Conv, 3, ,   1, 0)

// Conv: Complex float
HVSL_MKL_CONV_NEW_TASK(vslc, Conv, 2, 1D, 1, 0)        // HVSL_DTYPE_F32C
HVSL_MKL_CONV_NEW_TASK(vslc, Conv, 2, ,   1, 0)

// Corr: double precision
HVSL_MKL_CONV_NEW_TASK(vsld, Corr, 1, 1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK(vsld, Corr, 1, ,   1, 1)

// Corr: float precision
HVSL_MKL_CONV_NEW_TASK(vsls, Corr, 0, 1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK(vsls, Corr, 0, ,   1, 1)

// Corr: Complex double
HVSL_MKL_CONV_NEW_TASK(vslz, Corr, 3, 1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK(vslz, Corr, 3, ,   1, 1)

// Corr: Complex float
HVSL_MKL_CONV_NEW_TASK(vslc, Corr, 2, 1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK(vslc, Corr, 2, ,   1, 1)

// X variants (Conv)
HVSL_MKL_CONV_NEW_TASK_X(vsld, Conv, 1, X1D, 1, 0)
HVSL_MKL_CONV_NEW_TASK_X(vsls, Conv, 0, X1D, 1, 0)
HVSL_MKL_CONV_NEW_TASK_X(vslz, Conv, 3, X1D, 1, 0)
HVSL_MKL_CONV_NEW_TASK_X(vslc, Conv, 2, X1D, 1, 0)
HVSL_MKL_CONV_NEW_TASK_X(vsld, Conv, 1, X,   1, 0)
HVSL_MKL_CONV_NEW_TASK_X(vsls, Conv, 0, X,   1, 0)
HVSL_MKL_CONV_NEW_TASK_X(vslz, Conv, 3, X,   1, 0)
HVSL_MKL_CONV_NEW_TASK_X(vslc, Conv, 2, X,   1, 0)

// X variants (Corr)
HVSL_MKL_CONV_NEW_TASK_X(vsld, Corr, 1, X1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK_X(vsls, Corr, 0, X1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK_X(vslz, Corr, 3, X1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK_X(vslc, Corr, 2, X1D, 1, 1)
HVSL_MKL_CONV_NEW_TASK_X(vsld, Corr, 1, X,   1, 1)
HVSL_MKL_CONV_NEW_TASK_X(vsls, Corr, 0, X,   1, 1)
HVSL_MKL_CONV_NEW_TASK_X(vslz, Corr, 3, X,   1, 1)
HVSL_MKL_CONV_NEW_TASK_X(vslc, Corr, 2, X,   1, 1)

// ============================================================
//  Convolution: 执行 — 宏生成（32 个）
// ============================================================

#define HVSL_MKL_CONV_EXEC_INNER(prefix, base, dim)                          \
    static inline int prefix##base##Exec##dim(VSLConvTaskPtr task,           \
        const void* x, const void* y, void* z)                               \
    {                                                                          \
        HvslConvParams p;                                                      \
        p.x = x; p.y = y; p.z = z;                                            \
        return hvslConvExec(task, &p);                                         \
    }

HVSL_MKL_CONV_EXEC_INNER(vsld, Conv, )     // vsldConvExec
HVSL_MKL_CONV_EXEC_INNER(vsls, Conv, )     // vslsConvExec
HVSL_MKL_CONV_EXEC_INNER(vslz, Conv, )     // vslzConvExec
HVSL_MKL_CONV_EXEC_INNER(vslc, Conv, )     // vslcConvExec

HVSL_MKL_CONV_EXEC_INNER(vsld, Conv, 1D)   // vsldConvExec1D
HVSL_MKL_CONV_EXEC_INNER(vsls, Conv, 1D)   // vslsConvExec1D
HVSL_MKL_CONV_EXEC_INNER(vslz, Conv, 1D)   // vslzConvExec1D
HVSL_MKL_CONV_EXEC_INNER(vslc, Conv, 1D)   // vslcConvExec1D

HVSL_MKL_CONV_EXEC_INNER(vsld, Conv, X)    // vsldConvExecX
HVSL_MKL_CONV_EXEC_INNER(vsls, Conv, X)    // vslsConvExecX
HVSL_MKL_CONV_EXEC_INNER(vslz, Conv, X)    // vslzConvExecX
HVSL_MKL_CONV_EXEC_INNER(vslc, Conv, X)    // vslcConvExecX

HVSL_MKL_CONV_EXEC_INNER(vsld, Conv, X1D)  // vsldConvExecX1D
HVSL_MKL_CONV_EXEC_INNER(vsls, Conv, X1D)  // vslsConvExecX1D
HVSL_MKL_CONV_EXEC_INNER(vslz, Conv, X1D)  // vslzConvExecX1D
HVSL_MKL_CONV_EXEC_INNER(vslc, Conv, X1D)  // vslcConvExecX1D

HVSL_MKL_CONV_EXEC_INNER(vsld, Corr, ) // vsldCorrExec
HVSL_MKL_CONV_EXEC_INNER(vsls, Corr, ) // vslsCorrExec
HVSL_MKL_CONV_EXEC_INNER(vslz, Corr, ) // vslzCorrExec
HVSL_MKL_CONV_EXEC_INNER(vslc, Corr, ) // vslcCorrExec

HVSL_MKL_CONV_EXEC_INNER(vsld, Corr, 1D) // vsldCorrExec1D
HVSL_MKL_CONV_EXEC_INNER(vsls, Corr, 1D) // vslsCorrExec1D
HVSL_MKL_CONV_EXEC_INNER(vslz, Corr, 1D) // vslzCorrExec1D
HVSL_MKL_CONV_EXEC_INNER(vslc, Corr, 1D) // vslcCorrExec1D

HVSL_MKL_CONV_EXEC_INNER(vsld, Corr, X)   // vsldCorrExecX
HVSL_MKL_CONV_EXEC_INNER(vsls, Corr, X)   // vslsCorrExecX
HVSL_MKL_CONV_EXEC_INNER(vslz, Corr, X)   // vslzCorrExecX
HVSL_MKL_CONV_EXEC_INNER(vslc, Corr, X)   // vslcCorrExecX

HVSL_MKL_CONV_EXEC_INNER(vsld, Corr, X1D) // vsldCorrExecX1D
HVSL_MKL_CONV_EXEC_INNER(vsls, Corr, X1D) // vslsCorrExecX1D
HVSL_MKL_CONV_EXEC_INNER(vslz, Corr, X1D) // vslzCorrExecX1D
HVSL_MKL_CONV_EXEC_INNER(vslc, Corr, X1D) // vslcCorrExecX1D

#undef HVSL_MKL_CONV_NEW_TASK
#undef HVSL_MKL_CONV_NEW_TASK_X
#undef HVSL_MKL_CONV_EXEC_INNER

// ============================================================
//  Convolution: 任务删除/复制
// ============================================================

static inline int vslConvDeleteTask(VSLConvTaskPtr* task)
{
    return hvslConvDeleteTask(task);
}

static inline int vslCorrDeleteTask(VSLConvTaskPtr* task)
{
    return hvslConvDeleteTask(task);
}

static inline int vslConvCopyTask(VSLConvTaskPtr* dest, VSLConvTaskPtr src)
{
    return hvslConvCopyTask(dest, src);
}

static inline int vslCorrCopyTask(VSLConvTaskPtr* dest, VSLConvTaskPtr src)
{
    return hvslConvCopyTask(dest, src);
}

// ============================================================
//  Convolution: 参数编辑
// ============================================================

static inline int vslConvSetMode(VSLConvTaskPtr task, int mode)
{
    return hvslConvSetAlgo(task, mode);
}

static inline int vslCorrSetMode(VSLConvTaskPtr task, int mode)
{
    return hvslConvSetAlgo(task, mode);
}

static inline int vslConvSetInternalPrecision(VSLConvTaskPtr task, int precision)
{
    return hvslConvSetInternalPrecision(task, precision);
}

static inline int vslCorrSetInternalPrecision(VSLConvTaskPtr task, int precision)
{
    return hvslConvSetInternalPrecision(task, precision);
}

static inline int vslConvSetStart(VSLConvTaskPtr task, const int64_t* start)
{
    return hvslConvSetStart(task, start);
}

static inline int vslCorrSetStart(VSLConvTaskPtr task, const int64_t* start)
{
    return hvslConvSetStart(task, start);
}

static inline int vslConvSetDecimation(VSLConvTaskPtr task, const int64_t* decimation)
{
    return hvslConvSetDecimation(task, decimation);
}

static inline int vslCorrSetDecimation(VSLConvTaskPtr task, const int64_t* decimation)
{
    return hvslConvSetDecimation(task, decimation);
}

#ifdef __cplusplus
}
#endif
