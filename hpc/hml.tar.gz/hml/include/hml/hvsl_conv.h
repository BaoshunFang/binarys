/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file   hvsl_conv.h
/// @brief  HVSL 一维卷积（1D Convolution）公共 API — Task + Params 统一模型。

#pragma once

#include <hml/hvsl_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @name Layer 2：核心引擎 — 统一 Task + Params API
/// 10 个 API 替代 MKL VSL 的 81 个 API
/// @{

/// @brief 创建卷积任务
/// @param[out] task   输出任务句柄
/// @param[in]  params 卷积参数结构体（定义维度、形状、数据类型等）
/// @return 状态码（`HvslStatusNoErr` 表示成功）
HML_EXPORT HvslStatus hvslConvNewTask(HvslConvTask* task,
                                    const HvslConvParams* params);

/// @brief 编辑卷积任务参数（单参数）
/// @param[in] task     任务句柄
/// @param[in] param_id 参数 ID（见 `HVSL_CONV_ED_*` 常量）
/// @param[in] value    参数值指针
/// @return 状态码
HML_EXPORT HvslStatus hvslConvEditTask(HvslConvTask task, int param_id,
                                     const void* value);

/// @brief 提交卷积任务配置（锁定参数，准备执行）
/// @param[in] task  任务句柄
/// @return 状态码
HML_EXPORT HvslStatus hvslConvCommit(HvslConvTask task);

/// @brief 执行卷积计算
/// @param[in] task   任务句柄
/// @param[in] params 卷积参数结构体（输入 x/y、输出 z 等）
/// @return 状态码
HML_EXPORT HvslStatus hvslConvExec(HvslConvTask task,
                                 const HvslConvParams* params);

/// @brief 删除卷积任务并释放资源
/// @param[in,out] task  任务句柄指针（函数将置 NULL）
/// @return 状态码
HML_EXPORT HvslStatus hvslConvDeleteTask(HvslConvTask* task);

/// @brief 复制卷积任务（深拷贝）
/// @param[out] dest  目标任务句柄
/// @param[in]  src   源任务句柄
/// @return 状态码
HML_EXPORT HvslStatus hvslConvCopyTask(HvslConvTask* dest, HvslConvTask src);

/// @brief 设置卷积算法
/// @param[in] task  任务句柄
/// @param[in] algo  算法类型（见 `HvslConvAlgo`）
/// @return 状态码
HML_EXPORT HvslStatus hvslConvSetAlgo(HvslConvTask task, int algo);

/// @brief 设置卷积内部精度
/// @param[in] task      任务句柄
/// @param[in] precision 内部精度（1=单精度, 2=双精度）
/// @return 状态码
HML_EXPORT HvslStatus hvslConvSetInternalPrecision(HvslConvTask task,
                                                  int precision);

/// @brief 设置卷积起始偏移
/// @param[in] task  任务句柄
/// @param[in] start 各维度的起始索引（长度 ndim）
/// @return 状态码
HML_EXPORT HvslStatus hvslConvSetStart(HvslConvTask task,
                                     const int64_t* start);

/// @brief 设置卷积抽取率
/// @param[in] task       任务句柄
/// @param[in] decimation 各维度的抽取率（长度 ndim）
/// @return 状态码
HML_EXPORT HvslStatus hvslConvSetDecimation(HvslConvTask task,
                                          const int64_t* decimation);

/// @brief 一步式卷积执行（无需预先创建任务）
/// @param[in] params  卷积参数结构体
/// @return 状态码
HML_EXPORT HvslStatus hvslConvExecSimple(const HvslConvParams* params);
/// @}

// ============================================================
//  Layer 2 param_id 常量表（用于 hvslConvEditTask）
// ============================================================

#define HVSL_CONV_ED_MODE              0
#define HVSL_CONV_ED_ALGO              1
#define HVSL_CONV_ED_DTYPE             2
#define HVSL_CONV_ED_X                 3
#define HVSL_CONV_ED_Y                 4
#define HVSL_CONV_ED_Z                 5
#define HVSL_CONV_ED_REF_DATA          6
#define HVSL_CONV_ED_START             7
#define HVSL_CONV_ED_DECIMATION        8
#define HVSL_CONV_ED_INTERNAL_PRECISION 9

#ifdef __cplusplus
}
#endif
