/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file   hvsl.h
/// @brief  HVSL 统一头文件 — 包含所有 HVSL 公共 API 声明。

#pragma once

// Layer 2: Core engine — HVSL unified APIs
#include <hml/hvsl_types.h>
#include <hml/hvsl_rng.h>
#include <hml/hvsl_ref.h>
#include <hml/hvsl_stats.h>
#include <hml/hvsl_conv.h>

#ifdef __cplusplus
// hml_vsl_ snake_case wrappers use C++ (static_cast); C consumers skip them.
#include <hml/hml_vsl.h>
#endif

// Layer 1: MKL VSL compatibility — zero-cost inline wrappers
// Include this header to use MKL VSL API names without code changes.
// #include <hml/hvsl_mkl_compat.h>
