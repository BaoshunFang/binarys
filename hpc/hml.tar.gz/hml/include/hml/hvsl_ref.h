/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file   hvsl_ref.h
/// @brief  HVS Reference (hvsr_) API — always uses generic (scalar) path.
///
/// These functions mirror the hvsl_ RNG API but always select the generic
/// (scalar reference) generator path, bypassing AVX2/TRNG optimizations.
/// Used as the correctness oracle in tests: hvsr_ output vs hvsl_ output.

#pragma once

#include <hml/hvsl_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @name 流生命周期
/// @{

/// @brief 创建参考流（始终使用标量参考路径）
/// @param[out] stream  输出流句柄
/// @param[in]  brng    基础生成器类型
/// @param[in]  seed    初始种子
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrNewStream(VSLStreamStatePtr* stream, int brng, int seed);

/// @brief 使用扩展参数创建参考流
/// @param[out] stream  输出流句柄
/// @param[in]  brng    基础生成器类型
/// @param[in]  nparams 参数个数
/// @param[in]  params  参数数组
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrNewStreamEx(VSLStreamStatePtr* stream, int brng,
                               int nparams, const unsigned int* params);

/// @brief 删除参考流
/// @param[in,out] stream  流句柄指针（函数将置 NULL）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrDeleteStream(VSLStreamStatePtr* stream);

/// @brief 复制参考流（深拷贝）
/// @param[out] newstream  新流句柄
/// @param[in]  srcstream  源流句柄
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrCopyStream(VSLStreamStatePtr* newstream,
                              VSLStreamStatePtr srcstream);

/// @brief 复制参考流状态（浅拷贝）
/// @param[out] newstate  新状态指针
/// @param[in]  srcstream 源流句柄
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrCopyStreamState(VSLStreamStatePtr* newstate,
                                   VSLStreamStatePtr srcstream);

/// @brief 跳过指定数量的随机数
/// @param[in]  stream  流句柄
/// @param[in]  nskip   跳过的样本数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrSkipAheadStream(VSLStreamStatePtr stream, long long int nskip);

/// @brief 跳蛙法将流分裂为多个并行子流
/// @param[in]  stream    流句柄
/// @param[in]  k         当前子流序号
/// @param[in]  nstreams  子流总数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrLeapfrogStream(VSLStreamStatePtr stream, int k, int nstreams);

/// @brief 保存参考流到文件
/// @param[in]  stream  流句柄
/// @param[in]  fname   文件名
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrSaveStreamF(VSLStreamStatePtr stream, const char* fname);

/// @brief 保存参考流到内存
/// @param[in]  stream  流句柄
/// @param[out] memptr  内存指针
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrSaveStreamM(VSLStreamStatePtr stream, char* memptr);

/// @brief 从文件加载参考流
/// @param[out] stream  输出流句柄
/// @param[in]  fname   文件名
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrLoadStreamF(VSLStreamStatePtr* stream, const char* fname);

/// @brief 从内存加载参考流
/// @param[out] stream  输出流句柄
/// @param[in]  memptr  内存指针
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrLoadStreamM(VSLStreamStatePtr* stream, const char* memptr);

/// @brief 查询 BRNG 属性
/// @param[in]  brng    基础生成器类型
/// @param[out] props   输出属性结构体
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrGetBrngProperties(int brng, VSLBRngProperties* props);

/// @brief 查询流的 BRNG 类型
/// @param[in]  stream  流句柄
/// @param[out] brng    输出 BRNG 类型
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvsrGetStreamStateBrng(VSLStreamStatePtr stream, int* brng);

/// @brief 查询已注册 BRNG 数量
/// @return 注册数量（当前未实现返回 NotImplErr）
HML_EXPORT int hvsrGetNumRegBrngs(void);
/// @}

/// @name 分布生成 — 单精度连续分布
/// @{

/// @brief 均匀分布 U(a, b)，参考实现
HML_EXPORT int hvsrRngUniform(const int method, VSLStreamStatePtr stream,
                              const int n, float* r, const float a,
                              const float b);

/// @brief 高斯分布 N(a, sigma^2)，参考实现
HML_EXPORT int hvsrRngGaussian(const int method, VSLStreamStatePtr stream,
                               const int n, float* r, const float a,
                               const float sigma);

/// @brief 多元高斯分布，参考实现
HML_EXPORT int hvsrRngGaussianMV(const int method, VSLStreamStatePtr stream,
                                 const int n, float* r, const int dimen,
                                 const int mstorage, const float* a,
                                 const float* t);

/// @brief 指数分布 Exp(a, beta)，参考实现
HML_EXPORT int hvsrRngExponential(const int method, VSLStreamStatePtr stream,
                                  const int n, float* r, const float a,
                                  const float beta);

/// @brief 拉普拉斯分布，参考实现
HML_EXPORT int hvsrRngLaplace(const int method, VSLStreamStatePtr stream,
                              const int n, float* r, const float a,
                              const float beta);

/// @brief Weibull 分布，参考实现
HML_EXPORT int hvsrRngWeibull(const int method, VSLStreamStatePtr stream,
                              const int n, float* r, const float alpha,
                              const float a, const float beta);

/// @brief Cauchy 分布，参考实现
HML_EXPORT int hvsrRngCauchy(const int method, VSLStreamStatePtr stream,
                             const int n, float* r, const float a,
                             const float beta);

/// @brief Rayleigh 分布，参考实现
HML_EXPORT int hvsrRngRayleigh(const int method, VSLStreamStatePtr stream,
                               const int n, float* r, const float a,
                               const float beta);

/// @brief 对数正态分布，参考实现
HML_EXPORT int hvsrRngLognormal(const int method, VSLStreamStatePtr stream,
                                const int n, float* r, const float a,
                                const float sigma, const float b,
                                const float beta);

/// @brief Gumbel 分布，参考实现
HML_EXPORT int hvsrRngGumbel(const int method, VSLStreamStatePtr stream,
                             const int n, float* r, const float a,
                             const float beta);

/// @brief Gamma 分布，参考实现
HML_EXPORT int hvsrRngGamma(const int method, VSLStreamStatePtr stream,
                            const int n, float* r, const float alpha,
                            const float a, const float beta);

/// @brief Beta 分布，参考实现
HML_EXPORT int hvsrRngBeta(const int method, VSLStreamStatePtr stream,
                           const int n, float* r, const float p,
                           const float q, const float a, const float beta);

/// @brief 卡方分布 ChiSquare(v)，参考实现
HML_EXPORT int hvsrRngChiSquare(const int method, VSLStreamStatePtr stream,
                                const int n, float* r, const int v);
/// @}

/// @name 分布生成 — 双精度连续分布
/// @{

/// @brief 均匀分布 U(a, b)，参考实现
HML_EXPORT int hvsrRngUniformD(const int method, VSLStreamStatePtr stream,
                               const int n, double* r, const double a,
                               const double b);

/// @brief 高斯分布 N(a, sigma^2)，参考实现
HML_EXPORT int hvsrRngGaussianD(const int method, VSLStreamStatePtr stream,
                                const int n, double* r, const double a,
                                const double sigma);

/// @brief 多元高斯分布，参考实现
HML_EXPORT int hvsrRngGaussianMVD(const int method, VSLStreamStatePtr stream,
                                  const int n, double* r, const int dimen,
                                  const int mstorage, const double* a,
                                  const double* t);

/// @brief 指数分布 Exp(a, beta)，参考实现
HML_EXPORT int hvsrRngExponentialD(const int method, VSLStreamStatePtr stream,
                                   const int n, double* r, const double a,
                                   const double beta);

/// @brief 拉普拉斯分布，参考实现
HML_EXPORT int hvsrRngLaplaceD(const int method, VSLStreamStatePtr stream,
                               const int n, double* r, const double a,
                               const double beta);

/// @brief Weibull 分布，参考实现
HML_EXPORT int hvsrRngWeibullD(const int method, VSLStreamStatePtr stream,
                               const int n, double* r, const double alpha,
                               const double a, const double beta);

/// @brief Cauchy 分布，参考实现
HML_EXPORT int hvsrRngCauchyD(const int method, VSLStreamStatePtr stream,
                              const int n, double* r, const double a,
                              const double beta);

/// @brief Rayleigh 分布，参考实现
HML_EXPORT int hvsrRngRayleighD(const int method, VSLStreamStatePtr stream,
                                const int n, double* r, const double a,
                                const double beta);

/// @brief 对数正态分布，参考实现
HML_EXPORT int hvsrRngLognormalD(const int method, VSLStreamStatePtr stream,
                                 const int n, double* r, const double a,
                                 const double sigma, const double b,
                                 const double beta);

/// @brief Gumbel 分布，参考实现
HML_EXPORT int hvsrRngGumbelD(const int method, VSLStreamStatePtr stream,
                              const int n, double* r, const double a,
                              const double beta);

/// @brief Gamma 分布，参考实现
HML_EXPORT int hvsrRngGammaD(const int method, VSLStreamStatePtr stream,
                             const int n, double* r, const double alpha,
                             const double a, const double beta);

/// @brief Beta 分布，参考实现
HML_EXPORT int hvsrRngBetaD(const int method, VSLStreamStatePtr stream,
                            const int n, double* r, const double p,
                            const double q, const double a, const double beta);

/// @brief 卡方分布 ChiSquare(v)，双精度参考实现
HML_EXPORT int hvsrRngChiSquareD(const int method, VSLStreamStatePtr stream,
                                 const int n, double* r, const int v);
/// @}

/// @name 分布生成 — 离散分布
/// @{

/// @brief 均匀随机比特位，参考实现
HML_EXPORT int hvsrRngUniformBits(const int method, VSLStreamStatePtr stream,
                                  const int n, unsigned int* r);

/// @brief 均匀随机 64 位比特位，参考实现
HML_EXPORT int hvsrRngUniformBits64(const int method, VSLStreamStatePtr stream,
                                    const int n, unsigned long long* r);

/// @brief 均匀整数分布，参考实现
HML_EXPORT int hvsrRngUniformI(const int method, VSLStreamStatePtr stream,
                               const int n, int* r, const int a, const int b);

/// @brief Bernoulli 分布 Bernoulli(p)，参考实现
HML_EXPORT int hvsrRngBernoulli(const int method, VSLStreamStatePtr stream,
                                const int n, int* r, const double p);

/// @brief Geometric 分布，参考实现
HML_EXPORT int hvsrRngGeometric(const int method, VSLStreamStatePtr stream,
                                const int n, int* r, const double p);

/// @brief Binomial 分布，参考实现
HML_EXPORT int hvsrRngBinomial(const int method, VSLStreamStatePtr stream,
                               const int n, int* r, const int ntrial,
                               const double p);

/// @brief Hypergeometric 分布，参考实现
HML_EXPORT int hvsrRngHypergeometric(const int method, VSLStreamStatePtr stream,
                                     const int n, int* r, const int l,
                                     const int m, const int s);

/// @brief Poisson 分布 Poisson(lambda)，参考实现
HML_EXPORT int hvsrRngPoisson(const int method, VSLStreamStatePtr stream,
                              const int n, int* r, const double lambda);

/// @brief 向量化 Poisson 分布，参考实现
HML_EXPORT int hvsrRngPoissonV(const int method, VSLStreamStatePtr stream,
                               const int n, int* r, const double* lambda);

/// @brief 负二项分布，参考实现
HML_EXPORT int hvsrRngNegBinomial(const int method, VSLStreamStatePtr stream,
                                  const int n, int* r, const double a,
                                  const double p);

/// @brief 多项分布，参考实现
HML_EXPORT int hvsrRngMultinomial(const int method, VSLStreamStatePtr stream,
                                  const int n, int* r, const int k,
                                  const int m, const double* p);
/// @}

#ifdef __cplusplus
} // extern "C"
#endif
