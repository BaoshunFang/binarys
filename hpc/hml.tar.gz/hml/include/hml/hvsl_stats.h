/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file   hvsl_stats.h
/// @brief  HVSL 汇总统计（Summary Statistics）公共 API — Task + Params 统一模型。

#pragma once

#include <hml/hvsl_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @name Layer 2：核心引擎 — 统一 Task + Params API
/// 18 个 API 替代 MKL VSL 的 105 个 API
/// @{

/// @brief 创建统计任务
/// @param[out] task   输出任务句柄
/// @param[in]  dtype  数据类型（见 `HvslDtype`）
/// @return 状态码（`HvslStatusNoErr` 表示成功）
HML_EXPORT HvslStatus hvslStatsNewTask(HvslStatsTask* task, int dtype);

/// @brief 编辑统计任务参数（单参数）
/// @param[in] task     任务句柄
/// @param[in] param_id 参数 ID（见 `HVSL_SS_ED_*` 常量）
/// @param[in] value    参数值指针
/// @return 状态码
HML_EXPORT HvslStatus hvslStatsEditTask(HvslStatsTask task, int param_id,
                                      const void* value);

/// @brief 批量编辑统计任务参数
/// @param[in] task      任务句柄
/// @param[in] n         参数个数
/// @param[in] param_ids 参数 ID 数组（长度 n）
/// @param[in] values    参数值指针数组（长度 n）
/// @return 状态码
HML_EXPORT HvslStatus hvslStatsEditTaskBatch(HvslStatsTask task, int n,
                                           const int* param_ids,
                                           const void* const* values);

/// @brief 提交统计任务配置（锁定参数，准备计算）
/// @param[in] task  任务句柄
/// @return 状态码
HML_EXPORT HvslStatus hvslStatsCommit(HvslStatsTask task);

/// @brief 执行统计计算
/// @param[in]  task      任务句柄
/// @param[in]  estimates 统计量位掩码（见 `HvslSsEstimates`）
/// @param[in]  method    计算方法（见 `HvslSsMethod`）
/// @param[in]  params    输入数据和输出 buffer 参数
/// @return 状态码
HML_EXPORT HvslStatus hvslStatsCompute(HvslStatsTask task,
                                     uint64_t estimates, int method,
                                     const HvslStatsParams* params);

/// @brief 删除统计任务并释放资源
/// @param[in,out] task  任务句柄指针（函数将置 NULL）
/// @return 状态码
HML_EXPORT HvslStatus hvslStatsDeleteTask(HvslStatsTask* task);

/// @brief 复制统计任务（深拷贝）
/// @param[out] dest  目标任务句柄
/// @param[in]  src   源任务句柄
/// @return 状态码
HML_EXPORT HvslStatus hvslStatsCopyTask(HvslStatsTask* dest, HvslStatsTask src);

/// @brief 获取统计任务大小（字节）
/// @param[in] task  任务句柄
/// @return 任务占用字节数
HML_EXPORT int64_t hvslStatsGetTaskSize(HvslStatsTask task);

/// @brief 一步式统计计算（无需预先创建任务）
/// @param[in] estimates 统计量位掩码
/// @param[in] method    计算方法
/// @param[in] params    输入数据和输出 buffer 参数
/// @return 状态码
HML_EXPORT HvslStatus hvslStatsComputeSimple(uint64_t estimates, int method,
                                           const HvslStatsParams* params);
/// @}

// ============================================================
//  Layer 2 param_id 常量表（用于 hvslStatsEditTask）
//  与 MKL VSL_SS_ED_* 一一对应，但不暴露 24 个专用 Editor
// ============================================================

#define HVSL_SS_ED_DIMEN              0
#define HVSL_SS_ED_OBSERV_N           1
#define HVSL_SS_ED_OBSERV             2
#define HVSL_SS_ED_OBSERV_STORAGE     3
#define HVSL_SS_ED_WEIGHTS            4
#define HVSL_SS_ED_MEAN               5
#define HVSL_SS_ED_2R_MOM             6
#define HVSL_SS_ED_3R_MOM             7
#define HVSL_SS_ED_4R_MOM             8
#define HVSL_SS_ED_2C_MOM             9
#define HVSL_SS_ED_3C_MOM             10
#define HVSL_SS_ED_4C_MOM             11
#define HVSL_SS_ED_SUM                12
#define HVSL_SS_ED_2R_SUM             13
#define HVSL_SS_ED_3R_SUM             14
#define HVSL_SS_ED_4R_SUM             15
#define HVSL_SS_ED_2C_SUM             16
#define HVSL_SS_ED_3C_SUM             17
#define HVSL_SS_ED_4C_SUM             18
#define HVSL_SS_ED_KURTOSIS           19
#define HVSL_SS_ED_SKEWNESS           20
#define HVSL_SS_ED_MIN                21
#define HVSL_SS_ED_MAX                22
#define HVSL_SS_ED_VARIATION          23
#define HVSL_SS_ED_COV                24
#define HVSL_SS_ED_COR                25
#define HVSL_SS_ED_COV_STORAGE        26
#define HVSL_SS_ED_COR_STORAGE        27
#define HVSL_SS_ED_CP                 28
#define HVSL_SS_ED_CP_STORAGE         29
#define HVSL_SS_ED_QUANT_ORDER_N      30
#define HVSL_SS_ED_QUANT_ORDER        31
#define HVSL_SS_ED_QUANT_QUANTILES    32
#define HVSL_SS_ED_ORDER_STATS        33
#define HVSL_SS_ED_GROUP_INDC         34
#define HVSL_SS_ED_GROUP_N            35
#define HVSL_SS_ED_POOLED_COV         36
#define HVSL_SS_ED_POOLED_MEAN        37
#define HVSL_SS_ED_GROUP_COV          38
#define HVSL_SS_ED_GROUP_MEAN         39
#define HVSL_SS_ED_ROBUST_COV         40
#define HVSL_SS_ED_ROBUST_MEAN        41
#define HVSL_SS_ED_OUTLIERS           42
#define HVSL_SS_ED_OUTLIERS_WEIGHT    43
#define HVSL_SS_ED_PARTIAL_COV        44
#define HVSL_SS_ED_PARTIAL_COR        45
#define HVSL_SS_ED_MI_PARAMS          46
#define HVSL_SS_ED_MI_ESTIMATES       47
#define HVSL_SS_ED_STREAM_QUANT_PARAMS  48
#define HVSL_SS_ED_MDAD               49
#define HVSL_SS_ED_MNAD               50
#define HVSL_SS_ED_SORTED_OBSERV      51
#define HVSL_SS_ED_PARAMTR_COR        52

// ============================================================
//  向后兼容：保留旧有的单 OP Init 风格（内部映射到新引擎）
// ============================================================

/// @brief [Deprecated] Use hvslStatsEditTask + hvslStatsCommit instead.
HML_EXPORT HvslStatus hvslStatsSumInit(HvslStatsTask task, int backend);

/// @brief [Deprecated] Use hvslStatsEditTask + hvslStatsCommit instead.
HML_EXPORT HvslStatus hvslStatsDotProdInit(HvslStatsTask task, int backend);

/// @brief [Deprecated] Use hvslStatsComputeSimple instead.
HML_EXPORT HvslStatus hvslStatsSum(HvslStatsOp op, int dtype,
                                 int64_t n, const void* data, void* result);

#ifdef __cplusplus
}
#endif
