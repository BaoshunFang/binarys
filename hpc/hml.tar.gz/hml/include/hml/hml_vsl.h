/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file   hml_vsl.h
/// @brief  HML 统一命名规范包装层 — hml_vsl_ 前缀零开销 inline 函数。

#pragma once

#include <hml/hvsl.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
// hml_vsl_ wrapper API — HML统一命名规范
// 零开销：所有函数为inline，直接转发到对应 hvsl_ 实现
// ============================================================

/// @name 后端控制
/// @{

/// @brief 设置后端
/// @param[in] backend  目标后端（见 `hml_vsl_backend_t`）
/// @return 状态码
static inline hml_vsl_status_t
hml_vsl_backend_set(hml_vsl_backend_t backend)
{
    return hvslSetBackend(backend);
}

/// @brief 获取当前后端
/// @return 当前后端枚举值
static inline hml_vsl_backend_t
hml_vsl_backend_get(void)
{
    return hvslGetBackend();
}

/// @brief 获取 CPU 特性信息
/// @param[out] features  输出 CPU 特性结构体
static inline void
hml_vsl_cpu_features(HvslCpuFeatures* features)
{
    hvslGetCpuFeatures(features);
}
/// @}

/// @name RNG 流生命周期
/// @{

/// @brief 创建随机数流
static inline int
hml_vsl_rng_new_stream(hml_vsl_stream_t* stream, hml_vsl_brng_t brng, int seed)
{
    return hvslNewStream((VSLStreamStatePtr*)stream, (int)brng, seed);
}

/// @brief 使用扩展参数创建随机数流
static inline int
hml_vsl_rng_new_stream_ex(hml_vsl_stream_t* stream, hml_vsl_brng_t brng,
                          int nparams, const unsigned int* params)
{
    return hvslNewStreamEx((VSLStreamStatePtr*)stream, (int)brng, nparams,
                           params);
}

/// @brief 删除随机数流
static inline int
hml_vsl_rng_delete_stream(hml_vsl_stream_t* stream)
{
    return hvslDeleteStream((VSLStreamStatePtr*)stream);
}

/// @brief 复制随机数流
static inline int
hml_vsl_rng_copy_stream(hml_vsl_stream_t* dest, hml_vsl_stream_t src)
{
    return hvslCopyStream((VSLStreamStatePtr*)dest, (VSLStreamStatePtr)src);
}

/// @brief 复制随机数流状态
static inline int
hml_vsl_rng_copy_stream_state(hml_vsl_stream_t* dest, hml_vsl_stream_t src)
{
    return hvslCopyStreamState((VSLStreamStatePtr*)dest,
                               (VSLStreamStatePtr)src);
}

/// @brief 跳蛙分流
static inline int
hml_vsl_rng_skip_ahead(hml_vsl_stream_t stream, int nskip)
{
    return hvslSkipAheadStream((VSLStreamStatePtr)stream, nskip);
}

/// @brief 跳蛙分流（扩展版，多段跳跃量）
static inline int
hml_vsl_rng_skip_ahead_ex(hml_vsl_stream_t stream, int n,
                          const unsigned long long nskip[])
{
    return hvslSkipAheadStreamEx((VSLStreamStatePtr)stream, n, nskip);
}

/// @brief 跳蛙法将流分裂为并行子流
static inline int
hml_vsl_rng_leapfrog(hml_vsl_stream_t stream, int k, int nstreams)
{
    return hvslLeapfrogStream((VSLStreamStatePtr)stream, k, nstreams);
}

/// @brief 保存流状态到文件
static inline int
hml_vsl_rng_save_stream_f(hml_vsl_stream_t stream, const char* fname)
{
    return hvslSaveStreamF((VSLStreamStatePtr)stream, fname);
}

/// @brief 从文件加载流状态
static inline int
hml_vsl_rng_load_stream_f(hml_vsl_stream_t* stream, const char* fname)
{
    return hvslLoadStreamF((VSLStreamStatePtr*)stream, fname);
}

/// @brief 保存流状态到内存缓冲区
static inline int
hml_vsl_rng_save_stream_m(hml_vsl_stream_t stream, char* memptr)
{
    return hvslSaveStreamM((VSLStreamStatePtr)stream, memptr);
}

/// @brief 从内存缓冲区加载流状态
static inline int
hml_vsl_rng_load_stream_m(hml_vsl_stream_t* stream, const char* memptr)
{
    return hvslLoadStreamM((VSLStreamStatePtr*)stream, memptr);
}

/// @brief 获取流的 BRNG 类型
static inline int
hml_vsl_rng_get_stream_state_brng(hml_vsl_stream_t stream, int* brng)
{
    return hvslGetStreamStateBrng((VSLStreamStatePtr)stream, brng);
}

/// @brief 获取流状态序列化大小（字节）
static inline int
hml_vsl_rng_get_stream_size(hml_vsl_stream_t stream, int* size)
{
    return hvslGetStreamSize((VSLStreamStatePtr)stream, size);
}

/// @brief 获取 BRNG 属性信息
static inline int
hml_vsl_rng_get_brng_properties(hml_vsl_brng_t brng,
                                hml_vsl_brng_properties_t* properties)
{
    return hvslGetBrngProperties((int)brng, properties);
}

/// @brief 获取已注册 BRNG 数量
static inline int
hml_vsl_rng_get_num_reg_brngs(void)
{
    return hvslGetNumRegBrngs();
}
/// @}

/// @name RNG 分布 — 均匀分布
/// @{

/// @brief 均匀分布，单精度
static inline int
hml_vsl_rng_uniform(const int method, hml_vsl_stream_t stream, const int n,
                    float* r, const float a, const float b)
{
    return hvslRngUniform(method, (VSLStreamStatePtr)stream, n, r, a, b);
}

/// @brief 均匀分布，双精度
static inline int
hml_vsl_rng_uniform_d(const int method, hml_vsl_stream_t stream, const int n,
                       double* r, const double a, const double b)
{
    return hvslRngUniformD(method, (VSLStreamStatePtr)stream, n, r, a, b);
}

/// @brief 离散均匀分布
static inline int
hml_vsl_rng_uniform_i(const int method, hml_vsl_stream_t stream, const int n,
                       int* r, const int a, const int b)
{
    return hvslRngUniformI(method, (VSLStreamStatePtr)stream, n, r, a, b);
}
/// @}

/// @name RNG 分布 — 高斯分布
/// @{

/// @brief 高斯分布，单精度
static inline int
hml_vsl_rng_gaussian(const int method, hml_vsl_stream_t stream, const int n,
                      float* r, const float a, const float sigma)
{
    return hvslRngGaussian(method, (VSLStreamStatePtr)stream, n, r, a, sigma);
}

/// @brief 高斯分布，双精度
static inline int
hml_vsl_rng_gaussian_d(const int method, hml_vsl_stream_t stream, const int n,
                        double* r, const double a, const double sigma)
{
    return hvslRngGaussianD(method, (VSLStreamStatePtr)stream, n, r, a, sigma);
}
/// @}

/// @name RNG 分布 — 指数分布
/// @{

/// @brief 指数分布，单精度
static inline int
hml_vsl_rng_exponential(const int method, hml_vsl_stream_t stream, const int n,
                         float* r, const float a, const float beta)
{
    return hvslRngExponential(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief 指数分布，双精度
static inline int
hml_vsl_rng_exponential_d(const int method, hml_vsl_stream_t stream, const int n,
                           double* r, const double a, const double beta)
{
    return hvslRngExponentialD(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}
/// @}

/// @name RNG 分布 — 离散分布
/// @{

/// @brief Bernoulli 分布
static inline int
hml_vsl_rng_bernoulli(const int method, hml_vsl_stream_t stream, const int n,
                       int* r, const double p)
{
    return hvslRngBernoulli(method, (VSLStreamStatePtr)stream, n, r, p);
}

/// @brief Poisson 分布
static inline int
hml_vsl_rng_poisson(const int method, hml_vsl_stream_t stream, const int n,
                     int* r, const double lambda)
{
    return hvslRngPoisson(method, (VSLStreamStatePtr)stream, n, r, lambda);
}

/// @brief Poisson 分布（逐样本独立 lambda）
static inline int
hml_vsl_rng_poisson_v(const int method, hml_vsl_stream_t stream, const int n,
                       int* r, const double* lambda)
{
    return hvslRngPoissonV(method, (VSLStreamStatePtr)stream, n, r, lambda);
}

/// @brief 均匀随机比特位
static inline int
hml_vsl_rng_uniform_bits(const int method, hml_vsl_stream_t stream, const int n,
                          unsigned int* r)
{
    return hvslRngUniformBits(method, (VSLStreamStatePtr)stream, n, r);
}

/// @brief 均匀随机 64 位比特位
static inline int
hml_vsl_rng_uniform_bits64(const int method, hml_vsl_stream_t stream,
                            const int n, unsigned long long* r)
{
    return hvslRngUniformBits64(method, (VSLStreamStatePtr)stream, n, r);
}

/// @brief 超几何分布（MKL 语义：l=总体数量, s=抽样数, m=成功数量）
static inline int
hml_vsl_rng_hypergeometric(const int method, hml_vsl_stream_t stream,
                            const int n, int* r, const int l, const int s,
                            const int m)
{
    return hvslRngHypergeometric(method, (VSLStreamStatePtr)stream, n, r, l, s,
                                 m);
}

/// @brief 负二项分布（失败次数参数化，mean = a(1-p)/p）
static inline int
hml_vsl_rng_neg_binomial(const int method, hml_vsl_stream_t stream, const int n,
                          int* r, const double a, const double p)
{
    return hvslRngNegBinomial(method, (VSLStreamStatePtr)stream, n, r, a, p);
}

/// @brief 卡方分布，单精度
static inline int
hml_vsl_rng_chi_square(const int method, hml_vsl_stream_t stream, const int n,
                        float* r, const int v)
{
    return hvslRngChiSquare(method, (VSLStreamStatePtr)stream, n, r, v);
}

/// @brief 卡方分布，双精度
static inline int
hml_vsl_rng_chi_square_d(const int method, hml_vsl_stream_t stream, const int n,
                          double* r, const int v)
{
    return hvslRngChiSquareD(method, (VSLStreamStatePtr)stream, n, r, v);
}

/// @brief 二项分布
static inline int
hml_vsl_rng_binomial(const int method, hml_vsl_stream_t stream, const int n,
                      int* r, const int ntrial, const double p)
{
    return hvslRngBinomial(method, (VSLStreamStatePtr)stream, n, r, ntrial, p);
}

/// @brief 几何分布
static inline int
hml_vsl_rng_geometric(const int method, hml_vsl_stream_t stream, const int n,
                       int* r, const double p)
{
    return hvslRngGeometric(method, (VSLStreamStatePtr)stream, n, r, p);
}
/// @}

/// @name RNG 分布 — Laplacian / Cauchy / Rayleigh
/// @{

/// @brief 拉普拉斯分布，单精度
static inline int
hml_vsl_rng_laplace(const int method, hml_vsl_stream_t stream, const int n,
                     float* r, const float a, const float beta)
{
    return hvslRngLaplace(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief 拉普拉斯分布，双精度
static inline int
hml_vsl_rng_laplace_d(const int method, hml_vsl_stream_t stream, const int n,
                       double* r, const double a, const double beta)
{
    return hvslRngLaplaceD(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief Cauchy 分布，单精度
static inline int
hml_vsl_rng_cauchy(const int method, hml_vsl_stream_t stream, const int n,
                    float* r, const float a, const float beta)
{
    return hvslRngCauchy(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief Cauchy 分布，双精度
static inline int
hml_vsl_rng_cauchy_d(const int method, hml_vsl_stream_t stream, const int n,
                      double* r, const double a, const double beta)
{
    return hvslRngCauchyD(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief Rayleigh 分布，单精度
static inline int
hml_vsl_rng_rayleigh(const int method, hml_vsl_stream_t stream, const int n,
                      float* r, const float a, const float beta)
{
    return hvslRngRayleigh(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief Rayleigh 分布，双精度
static inline int
hml_vsl_rng_rayleigh_d(const int method, hml_vsl_stream_t stream, const int n,
                        double* r, const double a, const double beta)
{
    return hvslRngRayleighD(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}
/// @}

/// @name RNG 分布 — 对数正态 / Gumbel / Gamma / Weibull / Beta
/// @{

/// @brief 对数正态分布，单精度
static inline int
hml_vsl_rng_lognormal(const int method, hml_vsl_stream_t stream, const int n,
                       float* r, const float a, const float sigma,
                       const float b, const float beta)
{
    return hvslRngLognormal(method, (VSLStreamStatePtr)stream, n, r, a, sigma, b, beta);
}

/// @brief 对数正态分布，双精度
static inline int
hml_vsl_rng_lognormal_d(const int method, hml_vsl_stream_t stream, const int n,
                         double* r, const double a, const double sigma,
                         const double b, const double beta)
{
    return hvslRngLognormalD(method, (VSLStreamStatePtr)stream, n, r, a, sigma, b, beta);
}

/// @brief Gumbel 分布，单精度
static inline int
hml_vsl_rng_gumbel(const int method, hml_vsl_stream_t stream, const int n,
                    float* r, const float a, const float beta)
{
    return hvslRngGumbel(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief Gumbel 分布，双精度
static inline int
hml_vsl_rng_gumbel_d(const int method, hml_vsl_stream_t stream, const int n,
                      double* r, const double a, const double beta)
{
    return hvslRngGumbelD(method, (VSLStreamStatePtr)stream, n, r, a, beta);
}

/// @brief Gamma 分布，单精度
static inline int
hml_vsl_rng_gamma(const int method, hml_vsl_stream_t stream, const int n,
                   float* r, const float alpha, const float a, const float beta)
{
    return hvslRngGamma(method, (VSLStreamStatePtr)stream, n, r, alpha, a, beta);
}

/// @brief Gamma 分布，双精度
static inline int
hml_vsl_rng_gamma_d(const int method, hml_vsl_stream_t stream, const int n,
                     double* r, const double alpha, const double a, const double beta)
{
    return hvslRngGammaD(method, (VSLStreamStatePtr)stream, n, r, alpha, a, beta);
}

/// @brief Weibull 分布，单精度
static inline int
hml_vsl_rng_weibull(const int method, hml_vsl_stream_t stream, const int n,
                     float* r, const float alpha, const float a, const float beta)
{
    return hvslRngWeibull(method, (VSLStreamStatePtr)stream, n, r, alpha, a, beta);
}

/// @brief Weibull 分布，双精度
static inline int
hml_vsl_rng_weibull_d(const int method, hml_vsl_stream_t stream, const int n,
                       double* r, const double alpha, const double a, const double beta)
{
    return hvslRngWeibullD(method, (VSLStreamStatePtr)stream, n, r, alpha, a, beta);
}

/// @brief Beta 分布，单精度
static inline int
hml_vsl_rng_beta(const int method, hml_vsl_stream_t stream, const int n,
                  float* r, const float p, const float q,
                  const float a, const float beta)
{
    return hvslRngBeta(method, (VSLStreamStatePtr)stream, n, r, p, q, a, beta);
}

/// @brief Beta 分布，双精度
static inline int
hml_vsl_rng_beta_d(const int method, hml_vsl_stream_t stream, const int n,
                    double* r, const double p, const double q,
                    const double a, const double beta)
{
    return hvslRngBetaD(method, (VSLStreamStatePtr)stream, n, r, p, q, a, beta);
}
/// @}

/// @name RNG 分布 — 多元分布
/// @{

/// @brief 多元高斯分布，单精度
static inline int
hml_vsl_rng_gaussian_mv(const int method, hml_vsl_stream_t stream, const int n,
                         float* r, const int dimen, const int mstorage,
                         const float* a, const float* t)
{
    return hvslRngGaussianMV(method, (VSLStreamStatePtr)stream, n, r, dimen, mstorage, a, t);
}

/// @brief 多元高斯分布，双精度
static inline int
hml_vsl_rng_gaussian_mv_d(const int method, hml_vsl_stream_t stream, const int n,
                           double* r, const int dimen, const int mstorage,
                           const double* a, const double* t)
{
    return hvslRngGaussianMVD(method, (VSLStreamStatePtr)stream, n, r, dimen, mstorage, a, t);
}

/// @brief 多项分布
static inline int
hml_vsl_rng_multinomial(const int method, hml_vsl_stream_t stream, const int n,
                         int* r, const int k, const int m, const double* p)
{
    return hvslRngMultinomial(method, (VSLStreamStatePtr)stream, n, r, k, m, p);
}
/// @}

/// @name Statistics 任务生命周期
/// @{

/// @brief 创建统计任务
static inline hml_vsl_status_t
hml_vsl_stats_new_task(hml_vsl_stats_task_t* task, int dtype)
{
    return static_cast<hml_vsl_status_t>(hvslStatsNewTask(task, dtype));
}

/// @brief 编辑统计任务参数
static inline hml_vsl_status_t
hml_vsl_stats_edit_task(hml_vsl_stats_task_t task, int param_id,
                        const void* value)
{
    return static_cast<hml_vsl_status_t>(hvslStatsEditTask(task, param_id, value));
}

/// @brief 提交统计任务配置
static inline hml_vsl_status_t
hml_vsl_stats_commit(hml_vsl_stats_task_t task)
{
    return static_cast<hml_vsl_status_t>(hvslStatsCommit(task));
}

/// @brief 执行统计计算
static inline hml_vsl_status_t
hml_vsl_stats_compute(hml_vsl_stats_task_t task, uint64_t estimates,
                      int method, const HvslStatsParams* params)
{
    return static_cast<hml_vsl_status_t>(hvslStatsCompute(task, estimates, method, params));
}

/// @brief 删除统计任务
static inline hml_vsl_status_t
hml_vsl_stats_delete_task(hml_vsl_stats_task_t* task)
{
    return static_cast<hml_vsl_status_t>(hvslStatsDeleteTask(task));
}

/// @brief 复制统计任务
static inline hml_vsl_status_t
hml_vsl_stats_copy_task(hml_vsl_stats_task_t* dest, hml_vsl_stats_task_t src)
{
    return static_cast<hml_vsl_status_t>(hvslStatsCopyTask(dest, src));
}
/// @}

/// @name Convolution 任务生命周期
/// @{

/// @brief 创建卷积任务
static inline hml_vsl_status_t
hml_vsl_conv_new_task(hml_vsl_conv_task_t* task, const HvslConvParams* params)
{
    return static_cast<hml_vsl_status_t>(hvslConvNewTask(task, params));
}

/// @brief 编辑卷积任务参数
static inline hml_vsl_status_t
hml_vsl_conv_edit_task(hml_vsl_conv_task_t task, int param_id,
                       const void* value)
{
    return static_cast<hml_vsl_status_t>(hvslConvEditTask(task, param_id, value));
}

/// @brief 提交卷积任务配置
static inline hml_vsl_status_t
hml_vsl_conv_commit(hml_vsl_conv_task_t task)
{
    return static_cast<hml_vsl_status_t>(hvslConvCommit(task));
}

/// @brief 执行卷积计算
static inline hml_vsl_status_t
hml_vsl_conv_exec(hml_vsl_conv_task_t task, const HvslConvParams* params)
{
    return static_cast<hml_vsl_status_t>(hvslConvExec(task, params));
}

/// @brief 删除卷积任务
static inline hml_vsl_status_t
hml_vsl_conv_delete_task(hml_vsl_conv_task_t* task)
{
    return static_cast<hml_vsl_status_t>(hvslConvDeleteTask(task));
}

/// @brief 复制卷积任务
static inline hml_vsl_status_t
hml_vsl_conv_copy_task(hml_vsl_conv_task_t* dest, hml_vsl_conv_task_t src)
{
    return static_cast<hml_vsl_status_t>(hvslConvCopyTask(dest, src));
}
/// @}

#ifdef __cplusplus
}
#endif


