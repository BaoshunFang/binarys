/*
 * Copyright (c) 2026 Hygon, Inc.
 *
 * All rights reserved.
 */

/// @file   hvsl_rng.h
/// @brief  HVSL 随机数生成（RNG）公共 API — 流式随机数生成与分布采样。

#pragma once

#include <hml/hvsl_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/// @name 流生命周期
/// @{

/// @brief 创建新的随机数流
/// @param[out] stream  输出流句柄
/// @param[in]  brng    基础生成器类型（见 `HvslBrng`）
/// @param[in]  seed    初始种子
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslNewStream(VSLStreamStatePtr* stream, int brng, int seed);

/// @brief 使用扩展参数创建随机数流
/// @param[out] stream  输出流句柄
/// @param[in]  brng    基础生成器类型
/// @param[in]  nparams 参数个数
/// @param[in]  params  参数数组
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslNewStreamEx(VSLStreamStatePtr* stream, int brng,
                             int nparams, const unsigned int* params);

/// @brief 删除随机数流并释放资源
/// @param[in,out] stream  流句柄指针（函数将置 NULL）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslDeleteStream(VSLStreamStatePtr* stream);

/// @brief 复制一个随机数流（深拷贝）
/// @param[out] newstream  新流句柄
/// @param[in]  srcstream  源流句柄
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslCopyStream(VSLStreamStatePtr* newstream,
                            VSLStreamStatePtr srcstream);

/// @brief 复制随机数流状态（浅拷贝）
/// @param[out] newstate  新状态指针
/// @param[in]  srcstream 源流句柄
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslCopyStreamState(VSLStreamStatePtr* newstate,
                                 VSLStreamStatePtr srcstream);

/// @brief 跳过指定数量的随机数
/// @param[in]  stream  流句柄
/// @param[in]  nskip   跳过的样本数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslSkipAheadStream(VSLStreamStatePtr stream, long long int nskip);

/// @brief 跳过随机数（扩展版，多段跳跃量）
/// @param[in]  stream  流句柄
/// @param[in]  n       跳跃量数组长度
/// @param[in]  nskip   跳跃量数组（推进量为 sum(nskip[i] * 2^(64*i))）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslSkipAheadStreamEx(VSLStreamStatePtr stream, int n,
                                    const unsigned long long nskip[]);

/// @brief 跳蛙法将流分裂为多个并行子流
/// @param[in]  stream   流句柄
/// @param[in]  k        子流索引（0-based）
/// @param[in]  nstreams 子流总数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslLeapfrogStream(VSLStreamStatePtr stream, int k, int nstreams);

/// @brief 将流状态保存到文件
/// @param[in] stream  流句柄
/// @param[in] fname   文件名
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslSaveStreamF(VSLStreamStatePtr stream, const char* fname);

/// @brief 将流状态保存到内存缓冲区
/// @param[in] stream  流句柄
/// @param[in] memptr  目标内存缓冲区
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslSaveStreamM(VSLStreamStatePtr stream, char* memptr);

/// @brief 从文件加载流状态
/// @param[out] stream  输出流句柄
/// @param[in]  fname   文件名
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslLoadStreamF(VSLStreamStatePtr* stream, const char* fname);

/// @brief 从内存缓冲区加载流状态
/// @param[out] stream  输出流句柄
/// @param[in]  memptr  源内存缓冲区
/// @note 缓冲区必须由 hvslSaveStreamM 写出且长度不小于
///       hvslGetStreamSize 报告的字节数；本接口无长度入参，无法校验
///       缓冲区实际大小，损坏/截断数据可能导致读取失败并返回错误码。
///       文件加载请使用 hvslLoadStreamF（会校验文件长度）。
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslLoadStreamM(VSLStreamStatePtr* stream, const char* memptr);

/// @brief 获取指定 BRNG 的属性信息
/// @param[in]  brng        基础生成器类型
/// @param[out] properties  输出属性结构体
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslGetBrngProperties(int brng, VSLBRngProperties* properties);

/// @brief 获取流的 BRNG 类型
/// @param[in]  stream  流句柄
/// @param[out] brng    输出 BRNG 类型
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslGetStreamStateBrng(VSLStreamStatePtr stream, int* brng);

/// @brief 获取将流保存到内存所需的内存大小（字节）。
///        该大小取决于实际实例化的生成器变体（generic / AVX2），
///        与 hvslSaveStreamM 写入的字节数一致。
/// @param[in]  stream  流句柄
/// @param[out] size    输出所需字节数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslGetStreamSize(VSLStreamStatePtr stream, int* size);

/// @brief 获取已注册的 BRNG 数量
/// @return 已注册的 BRNG 总数
HML_EXPORT int hvslGetNumRegBrngs(void);
/// @}

/// @name 连续分布（float）
/// @{

/// @brief 均匀分布 U(a, b)，单精度
/// @param[in]  method  生成方法（见 `HvslRngMethod`）
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       下限
/// @param[in]  b       上限
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngUniform(const int method, VSLStreamStatePtr stream,
                            const int n, float* r, const float a, const float b);

/// @brief 高斯分布 N(a, sigma^2)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       均值
/// @param[in]  sigma   标准差
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngGaussian(const int method, VSLStreamStatePtr stream,
                             const int n, float* r, const float a,
                             const float sigma);

/// @brief 多元高斯分布 N(a, T*T^T)，单精度
/// @param[in]  method   生成方法
/// @param[in]  stream   流句柄
/// @param[in]  n        生成向量数
/// @param[out] r        输出浮点数组（长度 n*dimen）
/// @param[in]  dimen    向量维度
/// @param[in]  mstorage 矩阵存储格式
/// @param[in]  a        均值向量（长度 dimen）
/// @param[in]  t        协方差因子矩阵
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngGaussianMV(const int method, VSLStreamStatePtr stream,
                               const int n, float* r, const int dimen,
                               const int mstorage, const float* a,
                               const float* t);

/// @brief 指数分布 Exp(a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       位移参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngExponential(const int method, VSLStreamStatePtr stream,
                                const int n, float* r, const float a,
                                const float beta);

/// @brief 拉普拉斯分布 Laplace(a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       位置参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngLaplace(const int method, VSLStreamStatePtr stream,
                            const int n, float* r, const float a,
                            const float beta);

/// @brief Weibull 分布 Weibull(alpha, a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  alpha   形状参数
/// @param[in]  a       位移参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngWeibull(const int method, VSLStreamStatePtr stream,
                            const int n, float* r, const float alpha,
                            const float a, const float beta);

/// @brief Cauchy 分布 Cauchy(a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       位置参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngCauchy(const int method, VSLStreamStatePtr stream,
                           const int n, float* r, const float a,
                           const float beta);

/// @brief Rayleigh 分布 Rayleigh(a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       位移参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngRayleigh(const int method, VSLStreamStatePtr stream,
                             const int n, float* r, const float a,
                             const float beta);

/// @brief 对数正态分布 Lognormal(a, sigma, b, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       形状参数
/// @param[in]  sigma   对数标准差
/// @param[in]  b       位移参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngLognormal(const int method, VSLStreamStatePtr stream,
                              const int n, float* r, const float a,
                              const float sigma, const float b,
                              const float beta);

/// @brief Gumbel 分布 Gumbel(a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  a       位置参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngGumbel(const int method, VSLStreamStatePtr stream,
                           const int n, float* r, const float a,
                           const float beta);

/// @brief Gamma 分布 Gamma(alpha, a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  alpha   形状参数
/// @param[in]  a       位移参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngGamma(const int method, VSLStreamStatePtr stream,
                          const int n, float* r, const float alpha,
                          const float a, const float beta);

/// @brief Beta 分布 Beta(p, q, a, beta)，单精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  p       形状参数 p
/// @param[in]  q       形状参数 q
/// @param[in]  a       位移参数
/// @param[in]  beta    尺度参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngBeta(const int method, VSLStreamStatePtr stream,
                         const int n, float* r, const float p, const float q,
                         const float a, const float beta);
/// @}

/// @name 连续分布（double）
/// @{

/// @brief 均匀分布 U(a, b)，双精度
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出双精度数组（长度 n）
/// @param[in]  a       下限
/// @param[in]  b       上限
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngUniformD(const int method, VSLStreamStatePtr stream,
                             const int n, double* r, const double a,
                             const double b);

/// @brief 高斯分布 N(a, sigma^2)，双精度
HML_EXPORT int hvslRngGaussianD(const int method, VSLStreamStatePtr stream,
                              const int n, double* r, const double a,
                              const double sigma);

/// @brief 多元高斯分布 N(a, T*T^T)，双精度
HML_EXPORT int hvslRngGaussianMVD(const int method, VSLStreamStatePtr stream,
                                const int n, double* r, const int dimen,
                                const int mstorage, const double* a,
                                const double* t);

/// @brief 指数分布 Exp(a, beta)，双精度
HML_EXPORT int hvslRngExponentialD(const int method, VSLStreamStatePtr stream,
                                 const int n, double* r, const double a,
                                 const double beta);

/// @brief 拉普拉斯分布 Laplace(a, beta)，双精度
HML_EXPORT int hvslRngLaplaceD(const int method, VSLStreamStatePtr stream,
                             const int n, double* r, const double a,
                             const double beta);

/// @brief Weibull 分布 Weibull(alpha, a, beta)，双精度
HML_EXPORT int hvslRngWeibullD(const int method, VSLStreamStatePtr stream,
                             const int n, double* r, const double alpha,
                             const double a, const double beta);

/// @brief Cauchy 分布 Cauchy(a, beta)，双精度
HML_EXPORT int hvslRngCauchyD(const int method, VSLStreamStatePtr stream,
                            const int n, double* r, const double a,
                            const double beta);

/// @brief Rayleigh 分布 Rayleigh(a, beta)，双精度
HML_EXPORT int hvslRngRayleighD(const int method, VSLStreamStatePtr stream,
                              const int n, double* r, const double a,
                              const double beta);

/// @brief 对数正态分布 Lognormal(a, sigma, b, beta)，双精度
HML_EXPORT int hvslRngLognormalD(const int method, VSLStreamStatePtr stream,
                               const int n, double* r, const double a,
                               const double sigma, const double b,
                               const double beta);

/// @brief Gumbel 分布 Gumbel(a, beta)，双精度
HML_EXPORT int hvslRngGumbelD(const int method, VSLStreamStatePtr stream,
                            const int n, double* r, const double a,
                            const double beta);

/// @brief Gamma 分布 Gamma(alpha, a, beta)，双精度
HML_EXPORT int hvslRngGammaD(const int method, VSLStreamStatePtr stream,
                           const int n, double* r, const double alpha,
                           const double a, const double beta);

/// @brief Beta 分布 Beta(p, q, a, beta)，双精度
HML_EXPORT int hvslRngBetaD(const int method, VSLStreamStatePtr stream,
                          const int n, double* r, const double p,
                          const double q, const double a, const double beta);
/// @}

/// @name 离散分布
/// @{

/// @brief 离散均匀分布 U(a, b)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n）
/// @param[in]  a       下限（含）
/// @param[in]  b       上限（含）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngUniformI(const int method, VSLStreamStatePtr stream,
                             const int n, int* r, const int a, const int b);

/// @brief 均匀随机比特位
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出无符号整型数组（长度 n）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngUniformBits(const int method, VSLStreamStatePtr stream,
                                const int n, unsigned int* r);

/// @brief 均匀随机 32 位比特位（MKL viRngUniformBits32；部分 BRNG 不支持，
///        返回 HvslStatusBrngNotSupportedErr）
HML_EXPORT int hvslRngUniformBits32(const int method, VSLStreamStatePtr stream,
                                  const int n, unsigned int* r);

/// @brief 均匀随机 64 位比特位
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出 64 位无符号整型数组（长度 n）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngUniformBits64(const int method, VSLStreamStatePtr stream,
                                  const int n, unsigned long long* r);

/// @brief Bernoulli 分布 Bernoulli(p)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n），0 或 1
/// @param[in]  p       成功概率
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngBernoulli(const int method, VSLStreamStatePtr stream,
                              const int n, int* r, const double p);

/// @brief 几何分布 Geometric(p)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n）
/// @param[in]  p       成功概率
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngGeometric(const int method, VSLStreamStatePtr stream,
                              const int n, int* r, const double p);

/// @brief 二项分布 Binomial(ntrial, p)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n）
/// @param[in]  ntrial  试验次数
/// @param[in]  p       单次成功概率
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngBinomial(const int method, VSLStreamStatePtr stream,
                             const int n, int* r, const int ntrial,
                             const double p);

/// @brief 超几何分布 Hypergeometric(l, s, m)
///
/// 参数语义与 MKL `viRngHypergeometric` 完全一致：
/// @param[in]  l       总体数量（population size）
/// @param[in]  s       抽取样本数（sample size）
/// @param[in]  m       总体中成功数量（number of successes in population）
/// @param[out] r       输出整型数组（长度 n）
/// @param[in]  n       生成样本数
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngHypergeometric(const int method, VSLStreamStatePtr stream,
                                   const int n, int* r, const int l,
                                   const int s, const int m);

/// @brief Poisson 分布 Poisson(lambda)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n）
/// @param[in]  lambda  均值/率参数
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngPoisson(const int method, VSLStreamStatePtr stream,
                            const int n, int* r, const double lambda);

/// @brief Poisson 分布 — 每个样本独立 lambda
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n）
/// @param[in]  lambda  均值/率数组（长度 n）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngPoissonV(const int method, VSLStreamStatePtr stream,
                             const int n, int* r, const double* lambda);

/// @brief 负二项分布 NegBinomial(a, p)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n）
/// @param[in]  a       成功次数阈值
/// @param[in]  p       成功概率
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngNegBinomial(const int method, VSLStreamStatePtr stream,
                                const int n, int* r, const double a,
                                const double p);

/// @brief 卡方分布 ChiSquare(v)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出浮点数组（长度 n）
/// @param[in]  v       自由度
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngChiSquare(const int method, VSLStreamStatePtr stream,
                              const int n, float* r, const int v);

/// @brief 卡方分布 ChiSquare(v)，双精度
HML_EXPORT int hvslRngChiSquareD(const int method, VSLStreamStatePtr stream,
                               const int n, double* r, const int v);

/// @brief 多项分布 Multinomial(k, m, p)
/// @param[in]  method  生成方法
/// @param[in]  stream  流句柄
/// @param[in]  n       生成样本数
/// @param[out] r       输出整型数组（长度 n*k）
/// @param[in]  k       类别数
/// @param[in]  m       试验总次数
/// @param[in]  p       各类别概率数组（长度 k）
/// @return 成功返回 0，失败返回错误码
HML_EXPORT int hvslRngMultinomial(const int method, VSLStreamStatePtr stream,
                                const int n, int* r, const int k, const int m,
                                const double* p);
/// @}

/// @name 后端控制
/// @{

/// @brief 设置当前后端（AVX2 / AVX512 / Auto）
/// @param[in] backend  目标后端（见 `HvslBackend`）
/// @return 状态码 `HvslStatusNoErr` 或 `HvslStatusBackendUnsupportedErr`
HML_EXPORT HvslStatus hvslSetBackend(HvslBackend backend);

/// @brief 获取当前后端
/// @return 当前后端枚举值
HML_EXPORT HvslBackend hvslGetBackend(void);

/// @brief 获取 CPU 特性信息
/// @param[out] features  输出 CPU 特性结构体
HML_EXPORT void hvslGetCpuFeatures(HvslCpuFeatures* features);
/// @}

#ifdef __cplusplus
} // extern "C"
#endif
