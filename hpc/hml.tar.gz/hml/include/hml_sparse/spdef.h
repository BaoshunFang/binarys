#pragma once

/**
 * @brief header for basic types and constants for hml_sparse API
 */

/* status of the routines */
typedef enum
{
  HML_SPARSE_STATUS_SUCCESS = 0,          /* the operation was successful */
  HML_SPARSE_STATUS_NOT_INITIALIZED = 1,  /* empty handle or matrix arrays */
  HML_SPARSE_STATUS_ALLOC_FAILED = 2,     /* internal error: memory allocation failed */
  HML_SPARSE_STATUS_INVALID_VALUE = 3,    /* invalid input value */
  HML_SPARSE_STATUS_EXECUTION_FAILED = 4, /* e.g. 0-diagonal element for triangular solver, etc. */
  HML_SPARSE_STATUS_INTERNAL_ERROR = 5,   /* internal error */
  HML_SPARSE_STATUS_NOT_SUPPORTED = 6,    /* e.g. operation for double precision doesn't support other types */
} hml_sparse_status_t;

/* sparse matrix operations */
typedef enum
{
  HML_SPARSE_OPERATION_NON_TRANSPOSE = 0,
  HML_SPARSE_OPERATION_TRANSPOSE = 1,
  HML_SPARSE_OPERATION_CONJUGATE_TRANSPOSE = 2
} hml_sparse_operation_t;

#define HML_SPARSE_OPERATION_NUM 3

/* supported matrix types */
typedef enum
{
  HML_SPARSE_MATRIX_TYPE_GENERAL = 0,   /*    General case                    */
  HML_SPARSE_MATRIX_TYPE_SYMMETRIC = 1, /*    Triangular part of              */
  HML_SPARSE_MATRIX_TYPE_HERMITIAN = 2, /*    the matrix is to be processed   */
  HML_SPARSE_MATRIX_TYPE_TRIANGULAR = 3,
  HML_SPARSE_MATRIX_TYPE_DIAGONAL = 4, /* diagonal matrix; only diagonal elements will be processed */
  HML_SPARSE_MATRIX_TYPE_BLOCK_TRIANGULAR = 5,
  HML_SPARSE_MATRIX_TYPE_BLOCK_DIAGONAL = 6 /* block-diagonal matrix; only diagonal blocks will be processed */
} hml_sparse_matrix_type_t;

#define HML_SPARSE_MATRIX_TYPE_NUM 2

/* sparse matrix indexing: C-style or Fortran-style */
typedef enum
{
  HML_SPARSE_INDEX_BASE_ZERO = 0, /* C-style */
  HML_SPARSE_INDEX_BASE_ONE = 1   /* Fortran-style */
} hml_sparse_index_base_t;

#define HML_SPARSE_INDEX_NUM 2

/* applies to triangular matrices only ( HML_SPARSE_MATRIX_TYPE_SYMMETRIC, HML_SPARSE_MATRIX_TYPE_HERMITIAN, HML_SPARSE_MATRIX_TYPE_TRIANGULAR ) */
typedef enum
{
  HML_SPARSE_FILL_MODE_LOWER = 0, /* lower triangular part of the matrix is stored */
  HML_SPARSE_FILL_MODE_UPPER = 1, /* upper triangular part of the matrix is stored */
} hml_sparse_fill_mode_t;

#define HML_SPARSE_FILL_MODE_NUM 2

/* applies to triangular matrices only ( HML_SPARSE_MATRIX_TYPE_SYMMETRIC, HML_SPARSE_MATRIX_TYPE_HERMITIAN, HML_SPARSE_MATRIX_TYPE_TRIANGULAR ) */
typedef enum
{
  HML_SPARSE_DIAG_NON_UNIT = 0, /* triangular matrix with non-unit diagonal */
  HML_SPARSE_DIAG_UNIT = 1      /* triangular matrix with unit diagonal */
} hml_sparse_diag_type_t;

#define HML_SPARSE_DIAG_TYPE_NUM 2

/* applicable for Level 3 operations with dense matrices; describes storage scheme for dense matrix (row major or column major) */
typedef enum
{
  HML_SPARSE_LAYOUT_ROW_MAJOR = 0,   /* C-style */
  HML_SPARSE_LAYOUT_COLUMN_MAJOR = 1 /* Fortran-style */
} hml_sparse_layout_t;

#define HML_SPARSE_LAYOUT_NUM 2

/* verbose mode; if verbose mode activated, handle should collect and report profiling / optimization info */
typedef enum
{
  HML_SPARSE_VERBOSE_OFF = 0,
  HML_SPARSE_VERBOSE_BASIC = 1,   /* output contains high-level information about optimization algorithms, issues, etc. */
  HML_SPARSE_VERBOSE_EXTENDED = 2 /* provide detailed output information */
} hml_verbose_mode_t;

/* memory optimization hints from user: describe how much memory could be used on optimization stage */
typedef enum
{
  HML_SPARSE_MEMORY_NONE = 0,      /* no memory should be allocated for matrix values and structures; auxiliary structures could be created only for workload balancing, parallelization, etc. */
  HML_SPARSE_MEMORY_AGGRESSIVE = 1 /* matrix could be converted to any internal format */
} hml_sparse_memory_usage_t;

typedef enum
{
  HML_SPARSE_STAGE_FULL_MULT = 0,
  HML_SPARSE_STAGE_NNZ_COUNT = 1,
  HML_SPARSE_STAGE_FINALIZE_MULT = 2,
  HML_SPARSE_STAGE_FULL_MULT_NO_VAL = 3,
  HML_SPARSE_STAGE_FINALIZE_MULT_NO_VAL = 4
} hml_sparse_request_t;

/*************************************************************************************************/
/*** Opaque structure for sparse matrix in internal format, further D - means double precision ***/
/*************************************************************************************************/

/*
 * hml_sparse sparse_matrix implement
 */
// struct  sparse_matrix;
// typedef struct sparse_matrix *hml_sparse_matrix_t;

/*
 * hml_sparse sparse matirx implement;
 * ----------------------------------------------------------------------------------------------------------------------
 */

typedef enum
{
  HML_SPARSE_FORMAT_COO = 0,
  HML_SPARSE_FORMAT_CSR = 1,
  HML_SPARSE_FORMAT_CSC = 2,
  HML_SPARSE_FORMAT_BSR = 3,
  HML_SPARSE_FORMAT_SKY = 4,
  HML_SPARSE_FORMAT_DIA = 5,
  HML_SPARSE_FORMAT_ELL = 6,
  HML_SPARSE_FORMAT_GEBSR = 7,
  HML_SPARSE_FORMAT_HYB = 8,
  HML_SPARSE_FORMAT_COO_AOS = 9,
  HML_SPARSE_FORMAT_CSR5 = 10
} hml_sparse_format_t;

#define HML_SPARSE_FORMAT_NUM 6

typedef enum
{
  HML_SPARSE_DATATYPE_FLOAT = 0,
  HML_SPARSE_DATATYPE_DOUBLE = 1,
  HML_SPARSE_DATATYPE_FLOAT_COMPLEX = 2,
  HML_SPARSE_DATATYPE_DOUBLE_COMPLEX = 3
} hml_sparse_datatype_t;

#define HML_SPARSE_DATATYPE_NUM 4

#ifndef COMPLEX
#ifndef DOUBLE
#define HML_SPARSE_DATATYPE HML_SPARSE_DATATYPE_FLOAT
#else
#define HML_SPARSE_DATATYPE HML_SPARSE_DATATYPE_DOUBLE
#endif
#else
#ifndef DOUBLE
#define HML_SPARSE_DATATYPE HML_SPARSE_DATATYPE_FLOAT_COMPLEX
#else
#define HML_SPARSE_DATATYPE HML_SPARSE_DATATYPE_DOUBLE_COMPLEX
#endif

#endif

typedef void *hml_internal_spmat;

typedef struct
{
  hml_internal_spmat mat;
  hml_sparse_format_t format;     // csr,coo,csc,bsr,ell,dia,sky...
  hml_sparse_datatype_t datatype; // s,d,c,z
  void *inspector;                // for autotuning
} hml_sparse_matrix;

typedef hml_sparse_matrix *hml_sparse_matrix_t;
/*
 * ----------------------------------------------------------------------------------------------------------------------
 */

/* descriptor of main sparse matrix properties */
struct hml_matrix_descr
{
  hml_sparse_matrix_type_t type; /* matrix type: general, diagonal or triangular / symmetric / hermitian */
  hml_sparse_fill_mode_t mode;   /* upper or lower triangular part of the matrix ( for triangular / symmetric / hermitian case) */
  hml_sparse_diag_type_t diag;   /* unit or non-unit diagonal ( for triangular / symmetric / hermitian case) */
};
