
#pragma once

/**
 * @brief header for all hml_sparse user interfaces
 */

#include "spdef.h"
#include "types.h"

/**
 * ----------------------------------------------------------------------------
 */

hml_sparse_status_t hml_sparse_transpose(const hml_sparse_matrix_t source, hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_csc(const hml_sparse_matrix_t source,
                                           const hml_sparse_operation_t operation,
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_bsr(const hml_sparse_matrix_t source, /* convert original matrix to BSR representation */
                                           const HML_INT block_size,
                                           const hml_sparse_layout_t block_layout, /* block storage: row-major or column-major */
                                           const hml_sparse_operation_t operation, /* as is, transposed or conjugate transposed */
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_sky(const hml_sparse_matrix_t source,
                                           const hml_sparse_operation_t operation,
                                           const hml_sparse_fill_mode_t fill,
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_dia(const hml_sparse_matrix_t source,
                                           const hml_sparse_operation_t operation,
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_ell(const hml_sparse_matrix_t source,
                                           const hml_sparse_operation_t operation,
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_hyb(const hml_sparse_matrix_t source,
                                           const hml_sparse_operation_t operation,
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_csr5(const hml_sparse_matrix_t source,
                                            const hml_sparse_operation_t operation,
                                            hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_hints_bsr(const hml_sparse_matrix_t source, /* convert original matrix to BSR representation */
                                                 const HML_INT block_size,
                                                 const hml_sparse_layout_t block_layout, /* block storage: row-major or column-major */
                                                 const hml_sparse_operation_t operation, /* as is, transposed or conjugate transposed */
                                                 hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_hints_dia(const hml_sparse_matrix_t source,
                                                 const hml_sparse_operation_t operation,
                                                 hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_hints_ell(const hml_sparse_matrix_t source,
                                                 const hml_sparse_operation_t operation,
                                                 hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_gebsr(const hml_sparse_matrix_t source, /* convert original matrix to GEBSR representation */
                                             const HML_INT block_row_dim,
                                             const HML_INT block_col_dim,
                                             const hml_sparse_layout_t block_layout, /* block storage: row-major or column-major */
                                             const hml_sparse_operation_t operation, /* as is, transposed or conjugate transposed */
                                             hml_sparse_matrix_t *dest);

/**
 * --------------------------------------------------------------------------------------
 */

/*****************************************************************************************/
/*************************************** Creation routines *******************************/
/*****************************************************************************************/

/*
    Matrix handle is used for storing information about the matrix and matrix values

    Create matrix from one of the existing sparse formats by creating the handle with matrix info and copy matrix values if requested.
    Collect high-level info about the matrix. Need to use this interface for the case with several calls in program for performance reasons,
    where optimizations are not required.

    coordinate format,
    HML_SPARSE_MATRIX_TYPE_GENERAL by default, pointers to input arrays are stored in the handle

    *** User data is not marked const since the hml_sparse_order() or hml_sparse_?_set_values()
    functionality could change user data.  However, this is only done by a user call.
    Internally const-ness of user data is maintained other than through explicit
    use of these interfaces.

*/
hml_sparse_status_t hml_sparse_s_create_coo(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT nnz,
                                            HML_INT *row_indx,
                                            HML_INT *col_indx,
                                            float *values);

hml_sparse_status_t hml_sparse_d_create_coo(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT nnz,
                                            HML_INT *row_indx,
                                            HML_INT *col_indx,
                                            double *values);

hml_sparse_status_t hml_sparse_c_create_coo(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT nnz,
                                            HML_INT *row_indx,
                                            HML_INT *col_indx,
                                            HML_Complex8 *values);

hml_sparse_status_t hml_sparse_z_create_coo(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT nnz,
                                            HML_INT *row_indx,
                                            HML_INT *col_indx,
                                            HML_Complex16 *values);

/*
    compressed sparse row format (4-arrays version),
    HML_SPARSE_MATRIX_TYPE_GENERAL by default, pointers to input arrays are stored in the handle

    *** User data is not marked const since the hml_sparse_order() or hml_sparse_?_set_values()
    functionality could change user data.  However, this is only done by a user call.
    Internally const-ness of user data is maintained other than through explicit
    use of these interfaces.


*/
hml_sparse_status_t hml_sparse_s_create_csr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            float *values);

hml_sparse_status_t hml_sparse_d_create_csr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            double *values);

hml_sparse_status_t hml_sparse_c_create_csr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            HML_Complex8 *values);

hml_sparse_status_t hml_sparse_z_create_csr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            HML_Complex16 *values);

/*
    compressed sparse column format (4-arrays version),
    HML_SPARSE_MATRIX_TYPE_GENERAL by default, pointers to input arrays are stored in the handle

    *** User data is not marked const since the hml_sparse_order() or hml_sparse_?_set_values()
    functionality could change user data.  However, this is only done by a user call.
    Internally const-ness of user data is maintained other than through explicit
    use of these interfaces.

*/
hml_sparse_status_t hml_sparse_s_create_csc(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *cols_start,
                                            HML_INT *cols_end,
                                            HML_INT *row_indx,
                                            float *values);

hml_sparse_status_t hml_sparse_d_create_csc(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *cols_start,
                                            HML_INT *cols_end,
                                            HML_INT *row_indx,
                                            double *values);

hml_sparse_status_t hml_sparse_c_create_csc(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *cols_start,
                                            HML_INT *cols_end,
                                            HML_INT *row_indx,
                                            HML_Complex8 *values);

hml_sparse_status_t hml_sparse_z_create_csc(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            HML_INT *cols_start,
                                            HML_INT *cols_end,
                                            HML_INT *row_indx,
                                            HML_Complex16 *values);

/*
    compressed block sparse row format (4-arrays version, square blocks),
    HML_SPARSE_MATRIX_TYPE_GENERAL by default, pointers to input arrays are stored in the handle

    *** User data is not marked const since the hml_sparse_order() or hml_sparse_?_set_values()
    functionality could change user data.  However, this is only done by a user call.
    Internally const-ness of user data is maintained other than through explicit
    use of these interfaces.

*/
hml_sparse_status_t hml_sparse_s_create_bsr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const hml_sparse_layout_t block_layout, /* block storage: row-major or column-major */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT block_size,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            float *values);

hml_sparse_status_t hml_sparse_d_create_bsr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const hml_sparse_layout_t block_layout, /* block storage: row-major or column-major */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT block_size,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            double *values);

hml_sparse_status_t hml_sparse_c_create_bsr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const hml_sparse_layout_t block_layout, /* block storage: row-major or column-major */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT block_size,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            HML_Complex8 *values);

hml_sparse_status_t hml_sparse_z_create_bsr(hml_sparse_matrix_t *A,
                                            const hml_sparse_index_base_t indexing, /* indexing: C-style or Fortran-style */
                                            const hml_sparse_layout_t block_layout, /* block storage: row-major or column-major */
                                            const HML_INT rows,
                                            const HML_INT cols,
                                            const HML_INT block_size,
                                            HML_INT *rows_start,
                                            HML_INT *rows_end,
                                            HML_INT *col_indx,
                                            HML_Complex16 *values);

/*
    Create copy of the existing handle; matrix properties could be changed.
    For example it could be used for extracting triangular or diagonal parts from existing matrix.
*/
hml_sparse_status_t hml_sparse_copy(const hml_sparse_matrix_t source,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    hml_sparse_matrix_t *dest);

/*
    destroy matrix handle; if sparse matrix was stored inside the handle it also deallocates the matrix
    It is user's responsibility not to delete the handle with the matrix, if this matrix is shared with other handles
*/
hml_sparse_status_t hml_sparse_destroy(hml_sparse_matrix_t A);
/*
    return extended error information from last operation;
    e.g. info about wrong input parameter, memory sizes that couldn't be allocated
*/
hml_sparse_status_t hml_sparse_get_error_info(hml_sparse_matrix_t A, HML_INT *info); /* unsupported currently */

/*****************************************************************************************/
/************************ Converters of internal representation  *************************/
/*****************************************************************************************/

/* converters from current format to another */
hml_sparse_status_t hml_sparse_convert_csr(const hml_sparse_matrix_t source,       /* convert original matrix to CSR representation */
                                           const hml_sparse_operation_t operation, /* as is, transposed or conjugate transposed */
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_convert_coo(const hml_sparse_matrix_t source,       /* convert original matrix to CSR representation */
                                           const hml_sparse_operation_t operation, /* as is, transposed or conjugate transposed */
                                           hml_sparse_matrix_t *dest);

hml_sparse_status_t hml_sparse_s_export_bsr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *block_size,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            float **values);

hml_sparse_status_t hml_sparse_d_export_bsr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *block_size,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            double **values);

hml_sparse_status_t hml_sparse_c_export_bsr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *block_size,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            HML_Complex8 **values);

hml_sparse_status_t hml_sparse_z_export_bsr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *block_size,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            HML_Complex16 **values);

hml_sparse_status_t hml_sparse_s_export_csr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            float **values);

hml_sparse_status_t hml_sparse_d_export_csr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            double **values);

hml_sparse_status_t hml_sparse_c_export_csr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            HML_Complex8 **values);

hml_sparse_status_t hml_sparse_z_export_csr(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **rows_start,
                                            HML_INT **rows_end,
                                            HML_INT **col_indx,
                                            HML_Complex16 **values);

hml_sparse_status_t hml_sparse_s_export_csc(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **cols_start,
                                            HML_INT **cols_end,
                                            HML_INT **row_indx,
                                            float **values);

hml_sparse_status_t hml_sparse_d_export_csc(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **cols_start,
                                            HML_INT **cols_end,
                                            HML_INT **row_indx,
                                            double **values);

hml_sparse_status_t hml_sparse_c_export_csc(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **cols_start,
                                            HML_INT **cols_end,
                                            HML_INT **row_indx,
                                            HML_Complex8 **values);

hml_sparse_status_t hml_sparse_z_export_csc(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT **cols_start,
                                            HML_INT **cols_end,
                                            HML_INT **row_indx,
                                            HML_Complex16 **values);

hml_sparse_status_t hml_sparse_s_export_ell(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *width,
                                            HML_INT **col_indx,
                                            float **values);

hml_sparse_status_t hml_sparse_d_export_ell(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *width,
                                            HML_INT **col_indx,
                                            double **values);

hml_sparse_status_t hml_sparse_c_export_ell(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *width,
                                            HML_INT **col_indx,
                                            HML_Complex8 **values);

hml_sparse_status_t hml_sparse_z_export_ell(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *width,
                                            HML_INT **col_indx,
                                            HML_Complex16 **values);

hml_sparse_status_t hml_sparse_s_export_gebsr(const hml_sparse_matrix_t source,
                                              hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                              hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                              HML_INT *rows,
                                              HML_INT *cols,
                                              HML_INT *block_row_dim,
                                              HML_INT *block_col_dim,
                                              HML_INT **rows_start,
                                              HML_INT **rows_end,
                                              HML_INT **col_indx,
                                              float **values);

hml_sparse_status_t hml_sparse_d_export_gebsr(const hml_sparse_matrix_t source,
                                              hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                              hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                              HML_INT *rows,
                                              HML_INT *cols,
                                              HML_INT *block_row_dim,
                                              HML_INT *block_col_dim,
                                              HML_INT **rows_start,
                                              HML_INT **rows_end,
                                              HML_INT **col_indx,
                                              double **values);

hml_sparse_status_t hml_sparse_c_export_gebsr(const hml_sparse_matrix_t source,
                                              hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                              hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                              HML_INT *rows,
                                              HML_INT *cols,
                                              HML_INT *block_row_dim,
                                              HML_INT *block_col_dim,
                                              HML_INT **rows_start,
                                              HML_INT **rows_end,
                                              HML_INT **col_indx,
                                              HML_Complex8 **values);

hml_sparse_status_t hml_sparse_z_export_gebsr(const hml_sparse_matrix_t source,
                                              hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                              hml_sparse_layout_t *block_layout, /* block storage: row-major or column-major */
                                              HML_INT *rows,
                                              HML_INT *cols,
                                              HML_INT *block_row_dim,
                                              HML_INT *block_col_dim,
                                              HML_INT **rows_start,
                                              HML_INT **rows_end,
                                              HML_INT **col_indx,
                                              HML_Complex16 **values);

hml_sparse_status_t hml_sparse_s_export_hyb(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *nnz,
                                            HML_INT *ell_width,
                                            float **ell_val,
                                            HML_INT **ell_col_ind,
                                            float **coo_val,
                                            HML_INT **coo_row_val,
                                            HML_INT **coo_col_val);

hml_sparse_status_t hml_sparse_d_export_hyb(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *nnz,
                                            HML_INT *ell_width,
                                            double **ell_val,
                                            HML_INT **ell_col_ind,
                                            double **coo_val,
                                            HML_INT **coo_row_val,
                                            HML_INT **coo_col_val);

hml_sparse_status_t hml_sparse_c_export_hyb(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *nnz,
                                            HML_INT *ell_width,
                                            HML_Complex8 **ell_val,
                                            HML_INT **ell_col_ind,
                                            HML_Complex8 **coo_val,
                                            HML_INT **coo_row_val,
                                            HML_INT **coo_col_val);

hml_sparse_status_t hml_sparse_z_export_hyb(const hml_sparse_matrix_t source,
                                            hml_sparse_index_base_t *indexing, /* indexing: C-style or Fortran-style */
                                            HML_INT *rows,
                                            HML_INT *cols,
                                            HML_INT *nnz,
                                            HML_INT *ell_width,
                                            HML_Complex16 **ell_val,
                                            HML_INT **ell_col_ind,
                                            HML_Complex16 **coo_val,
                                            HML_INT **coo_row_val,
                                            HML_INT **coo_col_val);

/*****************************************************************************************/
/************************** Step-by-step modification routines ***************************/
/*****************************************************************************************/

/* update existing value in the matrix ( for internal storage only, should not work with user-allocated matrices) */
hml_sparse_status_t hml_sparse_s_set_value(hml_sparse_matrix_t A,
                                           const HML_INT row,
                                           const HML_INT col,
                                           const float value);

hml_sparse_status_t hml_sparse_d_set_value(hml_sparse_matrix_t A,
                                           const HML_INT row,
                                           const HML_INT col,
                                           const double value);

hml_sparse_status_t hml_sparse_c_set_value(hml_sparse_matrix_t A,
                                           const HML_INT row,
                                           const HML_INT col,
                                           const HML_Complex8 value);

hml_sparse_status_t hml_sparse_z_set_value(hml_sparse_matrix_t A,
                                           const HML_INT row,
                                           const HML_INT col,
                                           const HML_Complex16 value);

/* update existing values in the matrix for internal storage only
       can be used to either update all or selected values */
hml_sparse_status_t hml_sparse_s_update_values(hml_sparse_matrix_t A,
                                               const HML_INT nvalues,
                                               const HML_INT *indx,
                                               const HML_INT *indy,
                                               float *values);

hml_sparse_status_t hml_sparse_d_update_values(hml_sparse_matrix_t A,
                                               const HML_INT nvalues,
                                               const HML_INT *indx,
                                               const HML_INT *indy,
                                               double *values);

hml_sparse_status_t hml_sparse_c_update_values(hml_sparse_matrix_t A,
                                               const HML_INT nvalues,
                                               const HML_INT *indx,
                                               const HML_INT *indy,
                                               HML_Complex8 *values);

hml_sparse_status_t hml_sparse_z_update_values(hml_sparse_matrix_t A,
                                               const HML_INT nvalues,
                                               const HML_INT *indx,
                                               const HML_INT *indy,
                                               HML_Complex16 *values);

/*****************************************************************************************/
/****************************** Verbose mode routine *************************************/
/*****************************************************************************************/

/* allow to switch on/off verbose mode */
hml_sparse_status_t hml_sparse_set_verbose_mode(hml_verbose_mode_t verbose); /* unsupported currently */

/*****************************************************************************************/
/****************************** Optimization routines ************************************/
/*****************************************************************************************/

/* Describe expected operations with amount of iterations */
hml_sparse_status_t hml_sparse_set_mv_hint(const hml_sparse_matrix_t A,
                                           const hml_sparse_operation_t operation, /* HML_SPARSE_OPERATION_NON_TRANSPOSE is default value for infinite amount of calls */
                                           const struct hml_matrix_descr descr,    /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                           const HML_INT expected_calls);

hml_sparse_status_t hml_sparse_set_dotmv_hint(const hml_sparse_matrix_t A,
                                              const hml_sparse_operation_t operation, /* HML_SPARSE_OPERATION_NON_TRANSPOSE is default value for infinite amount of calls */
                                              const struct hml_matrix_descr descr,    /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                              const HML_INT expectedCalls);

hml_sparse_status_t hml_sparse_set_mmd_hint(const hml_sparse_matrix_t A,
                                            const hml_sparse_operation_t operation,
                                            const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                            const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                            const HML_INT dense_matrix_size,     /* amount of columns in dense matrix */
                                            const HML_INT expected_calls);

hml_sparse_status_t hml_sparse_set_sv_hint(const hml_sparse_matrix_t A,
                                           const hml_sparse_operation_t operation, /* HML_SPARSE_OPERATION_NON_TRANSPOSE is default value for infinite amount of calls */
                                           const struct hml_matrix_descr descr,    /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                           const HML_INT expected_calls);

hml_sparse_status_t hml_sparse_set_sm_hint(const hml_sparse_matrix_t A,
                                           const hml_sparse_operation_t operation,
                                           const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                           const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                           const HML_INT dense_matrix_size,     /* amount of columns in dense matrix */
                                           const HML_INT expected_calls);

hml_sparse_status_t hml_sparse_set_mm_hint(const hml_sparse_matrix_t A,
                                           const hml_sparse_operation_t transA,
                                           const struct hml_matrix_descr descrA, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                           const hml_sparse_matrix_t B,
                                           const hml_sparse_operation_t transB,
                                           const struct hml_matrix_descr descrB,
                                           const HML_INT expected_calls);

hml_sparse_status_t hml_sparse_set_symgs_hint(const hml_sparse_matrix_t A,
                                              const hml_sparse_operation_t operation, /* HML_SPARSE_OPERATION_NON_TRANSPOSE is default value for infinite amount of calls */
                                              const struct hml_matrix_descr descr,    /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                              const HML_INT expected_calls);

hml_sparse_status_t hml_sparse_set_lu_smoother_hint(const hml_sparse_matrix_t A,
                                                    const hml_sparse_operation_t operation,
                                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                                    const HML_INT expectedCalls);

/* Describe memory usage model */
hml_sparse_status_t hml_sparse_set_memory_hint(const hml_sparse_matrix_t A,
                                               const hml_sparse_memory_usage_t policy); /* HML_SPARSE_MEMORY_AGGRESSIVE is default value */

/*
    Optimize matrix described by the handle. It uses hints (optimization and memory) that should be set up before this call.
    If hints were not explicitly defined, default vales are:
    HML_SPARSE_OPERATION_NON_TRANSPOSE for matrix-vector multiply with infinite number of expected iterations.
*/
hml_sparse_status_t hml_sparse_optimize(hml_sparse_matrix_t A);

/*****************************************************************************************/
/****************************** Computational routines ***********************************/
/*****************************************************************************************/

hml_sparse_status_t hml_sparse_order(const hml_sparse_matrix_t csrA);

/*
    Perform computations based on created matrix handle

    Level 2
*/
/*   Computes y = alpha * A * x + beta * y   */
hml_sparse_status_t hml_sparse_s_mv(const hml_sparse_operation_t operation,
                                    const float alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const float *x,
                                    const float beta,
                                    float *y);

hml_sparse_status_t hml_sparse_d_mv(const hml_sparse_operation_t operation,
                                    const double alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const double *x,
                                    const double beta,
                                    double *y);

hml_sparse_status_t hml_sparse_c_mv(const hml_sparse_operation_t operation,
                                    const HML_Complex8 alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const HML_Complex8 *x,
                                    const HML_Complex8 beta,
                                    HML_Complex8 *y);

hml_sparse_status_t hml_sparse_z_mv(const hml_sparse_operation_t operation,
                                    const HML_Complex16 alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const HML_Complex16 *x,
                                    const HML_Complex16 beta,
                                    HML_Complex16 *y);

/*    Computes y = alpha * A * x + beta * y  and d = <x, y> , the l2 inner product */
hml_sparse_status_t hml_sparse_s_dotmv(const hml_sparse_operation_t transA,
                                       const float alpha,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                       const float *x,
                                       const float beta,
                                       float *y,
                                       float *d);

hml_sparse_status_t hml_sparse_d_dotmv(const hml_sparse_operation_t transA,
                                       const double alpha,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                       const double *x,
                                       const double beta,
                                       double *y,
                                       double *d);

hml_sparse_status_t hml_sparse_c_dotmv(const hml_sparse_operation_t transA,
                                       const HML_Complex8 alpha,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                       const HML_Complex8 *x,
                                       const HML_Complex8 beta,
                                       HML_Complex8 *y,
                                       HML_Complex8 *d);

hml_sparse_status_t hml_sparse_z_dotmv(const hml_sparse_operation_t transA,
                                       const HML_Complex16 alpha,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                       const HML_Complex16 *x,
                                       const HML_Complex16 beta,
                                       HML_Complex16 *y,
                                       HML_Complex16 *d);

/*   Solves triangular system y = alpha * A^{-1} * x   */
hml_sparse_status_t hml_sparse_s_trsv(const hml_sparse_operation_t operation,
                                      const float alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const float *x,
                                      float *y);

hml_sparse_status_t hml_sparse_d_trsv(const hml_sparse_operation_t operation,
                                      const double alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const double *x,
                                      double *y);

hml_sparse_status_t hml_sparse_c_trsv(const hml_sparse_operation_t operation,
                                      const HML_Complex8 alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const HML_Complex8 *x,
                                      HML_Complex8 *y);

hml_sparse_status_t hml_sparse_z_trsv(const hml_sparse_operation_t operation,
                                      const HML_Complex16 alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const HML_Complex16 *x,
                                      HML_Complex16 *y);

/*   Applies symmetric Gauss-Seidel preconditioner to symmetric system A * x = b, */
/*   that is, it solves:                                                          */
/*      x0       = alpha*x                                                        */
/*      (L+D)*x1 = b - U*x0                                                       */
/*      (D+U)*x  = b - L*x1                                                       */
/*                                                                                */
/*   SYMGS_MV also returns y = A*x                                                */
hml_sparse_status_t hml_sparse_s_symgs(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr,
                                       const float alpha,
                                       const float *b,
                                       float *x);

hml_sparse_status_t hml_sparse_d_symgs(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr,
                                       const double alpha,
                                       const double *b,
                                       double *x);

hml_sparse_status_t hml_sparse_c_symgs(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr,
                                       const HML_Complex8 alpha,
                                       const HML_Complex8 *b,
                                       HML_Complex8 *x);

hml_sparse_status_t hml_sparse_z_symgs(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const struct hml_matrix_descr descr,
                                       const HML_Complex16 alpha,
                                       const HML_Complex16 *b,
                                       HML_Complex16 *x);

hml_sparse_status_t hml_sparse_s_symgs_mv(const hml_sparse_operation_t op,
                                          const hml_sparse_matrix_t A,
                                          const struct hml_matrix_descr descr,
                                          const float alpha,
                                          const float *b,
                                          float *x,
                                          float *y);

hml_sparse_status_t hml_sparse_d_symgs_mv(const hml_sparse_operation_t op,
                                          const hml_sparse_matrix_t A,
                                          const struct hml_matrix_descr descr,
                                          const double alpha,
                                          const double *b,
                                          double *x,
                                          double *y);

hml_sparse_status_t hml_sparse_c_symgs_mv(const hml_sparse_operation_t op,
                                          const hml_sparse_matrix_t A,
                                          const struct hml_matrix_descr descr,
                                          const HML_Complex8 alpha,
                                          const HML_Complex8 *b,
                                          HML_Complex8 *x,
                                          HML_Complex8 *y);

hml_sparse_status_t hml_sparse_z_symgs_mv(const hml_sparse_operation_t op,
                                          const hml_sparse_matrix_t A,
                                          const struct hml_matrix_descr descr,
                                          const HML_Complex16 alpha,
                                          const HML_Complex16 *b,
                                          HML_Complex16 *x,
                                          HML_Complex16 *y);

/*   Computes an action of a preconditioner
         which corresponds to the approximate matrix decomposition A ≈ (L+D)*E*(U+D)
         for the system Ax = b.

         L is lower triangular part of A
         U is upper triangular part of A
         D is diagonal values of A
         E is approximate diagonal inverse

         That is, it solves:
             r = rhs - A*x0
             (L + D)*E*(U + D)*dx = r
             x1 = x0 + dx                                        */

hml_sparse_status_t hml_sparse_s_lu_smoother(const hml_sparse_operation_t op,
                                             const hml_sparse_matrix_t A,
                                             const struct hml_matrix_descr descr,
                                             const float *diag,
                                             const float *approx_diag_inverse,
                                             float *x,
                                             const float *rhs);

hml_sparse_status_t hml_sparse_d_lu_smoother(const hml_sparse_operation_t op,
                                             const hml_sparse_matrix_t A,
                                             const struct hml_matrix_descr descr,
                                             const double *diag,
                                             const double *approx_diag_inverse,
                                             double *x,
                                             const double *rhs);

hml_sparse_status_t hml_sparse_c_lu_smoother(const hml_sparse_operation_t op,
                                             const hml_sparse_matrix_t A,
                                             const struct hml_matrix_descr descr,
                                             const HML_Complex8 *diag,
                                             const HML_Complex8 *approx_diag_inverse,
                                             HML_Complex8 *x,
                                             const HML_Complex8 *rhs);

hml_sparse_status_t hml_sparse_z_lu_smoother(const hml_sparse_operation_t op,
                                             const hml_sparse_matrix_t A,
                                             const struct hml_matrix_descr descr,
                                             const HML_Complex16 *diag,
                                             const HML_Complex16 *approx_diag_inverse,
                                             HML_Complex16 *x,
                                             const HML_Complex16 *rhs);

/* Level 3 */

/*   Computes C = alpha * A * B + beta * C   */
hml_sparse_status_t hml_sparse_s_mm(const hml_sparse_operation_t operation,
                                    const float alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                    const float *B,
                                    const HML_INT columns,
                                    const HML_INT ldb,
                                    const float beta,
                                    float *C,
                                    const HML_INT ldc);

hml_sparse_status_t hml_sparse_d_mm(const hml_sparse_operation_t operation,
                                    const double alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                    const double *B,
                                    const HML_INT columns,
                                    const HML_INT ldb,
                                    const double beta,
                                    double *C,
                                    const HML_INT ldc);

hml_sparse_status_t hml_sparse_c_mm(const hml_sparse_operation_t operation,
                                    const HML_Complex8 alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                    const HML_Complex8 *B,
                                    const HML_INT columns,
                                    const HML_INT ldb,
                                    const HML_Complex8 beta,
                                    HML_Complex8 *C,
                                    const HML_INT ldc);

hml_sparse_status_t hml_sparse_z_mm(const hml_sparse_operation_t operation,
                                    const HML_Complex16 alpha,
                                    const hml_sparse_matrix_t A,
                                    const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                    const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                    const HML_Complex16 *B,
                                    const HML_INT columns,
                                    const HML_INT ldb,
                                    const HML_Complex16 beta,
                                    HML_Complex16 *C,
                                    const HML_INT ldc);

/*   Solves triangular system y = alpha * A^{-1} * x   */
hml_sparse_status_t hml_sparse_s_trsm(const hml_sparse_operation_t operation,
                                      const float alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                      const float *x,
                                      const HML_INT columns,
                                      const HML_INT ldx,
                                      float *y,
                                      const HML_INT ldy);

hml_sparse_status_t hml_sparse_d_trsm(const hml_sparse_operation_t operation,
                                      const double alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                      const double *x,
                                      const HML_INT columns,
                                      const HML_INT ldx,
                                      double *y,
                                      const HML_INT ldy);

hml_sparse_status_t hml_sparse_c_trsm(const hml_sparse_operation_t operation,
                                      const HML_Complex8 alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                      const HML_Complex8 *x,
                                      const HML_INT columns,
                                      const HML_INT ldx,
                                      HML_Complex8 *y,
                                      const HML_INT ldy);

hml_sparse_status_t hml_sparse_z_trsm(const hml_sparse_operation_t operation,
                                      const HML_Complex16 alpha,
                                      const hml_sparse_matrix_t A,
                                      const struct hml_matrix_descr descr, /* hml_sparse_matrix_type_t + hml_sparse_fill_mode_t + hml_sparse_diag_type_t */
                                      const hml_sparse_layout_t layout,    /* storage scheme for the dense matrix: C-style or Fortran-style */
                                      const HML_Complex16 *x,
                                      const HML_INT columns,
                                      const HML_INT ldx,
                                      HML_Complex16 *y,
                                      const HML_INT ldy);

/* Sparse-sparse functionality */

/*   Computes sum of sparse matrices: C = alpha * op(A) + B, result is sparse   */
hml_sparse_status_t hml_sparse_s_add(const hml_sparse_operation_t operation,
                                     const hml_sparse_matrix_t A,
                                     const float alpha,
                                     const hml_sparse_matrix_t B,
                                     hml_sparse_matrix_t *C);

hml_sparse_status_t hml_sparse_d_add(const hml_sparse_operation_t operation,
                                     const hml_sparse_matrix_t A,
                                     const double alpha,
                                     const hml_sparse_matrix_t B,
                                     hml_sparse_matrix_t *C);

hml_sparse_status_t hml_sparse_c_add(const hml_sparse_operation_t operation,
                                     const hml_sparse_matrix_t A,
                                     const HML_Complex8 alpha,
                                     const hml_sparse_matrix_t B,
                                     hml_sparse_matrix_t *C);

hml_sparse_status_t hml_sparse_z_add(const hml_sparse_operation_t operation,
                                     const hml_sparse_matrix_t A,
                                     const HML_Complex16 alpha,
                                     const hml_sparse_matrix_t B,
                                     hml_sparse_matrix_t *C);

/*   Computes product of sparse matrices: C = op(A) * B, result is sparse   */
hml_sparse_status_t hml_sparse_spmm(const hml_sparse_operation_t operation,
                                    const hml_sparse_matrix_t A,
                                    const hml_sparse_matrix_t B,
                                    hml_sparse_matrix_t *C);

/*   Computes product of sparse matrices: C = opA(A) * opB(B), result is sparse   */
hml_sparse_status_t hml_sparse_sp2m(const hml_sparse_operation_t transA,
                                    const struct hml_matrix_descr descrA,
                                    const hml_sparse_matrix_t A,
                                    const hml_sparse_operation_t transB,
                                    const struct hml_matrix_descr descrB,
                                    const hml_sparse_matrix_t B,
                                    const hml_sparse_request_t request,
                                    hml_sparse_matrix_t *C);

/*   Computes product of sparse matrices: C = op(A) * (op(A))^{T for real or H for complex}, result is sparse   */
hml_sparse_status_t hml_sparse_syrk(const hml_sparse_operation_t operation,
                                    const hml_sparse_matrix_t A,
                                    hml_sparse_matrix_t *C);

/*   Computes product of sparse matrices: C = op(A) * B * (op(A))^{T for real or H for complex}, result is sparse   */
hml_sparse_status_t hml_sparse_sypr(const hml_sparse_operation_t transA,
                                    const hml_sparse_matrix_t A,
                                    const hml_sparse_matrix_t B,
                                    const struct hml_matrix_descr descrB,
                                    hml_sparse_matrix_t *C,
                                    const hml_sparse_request_t request);

/*   Computes product of sparse matrices: C = op(A) * B * (op(A))^{T for real or H for complex}, result is dense */
hml_sparse_status_t hml_sparse_s_syprd(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const float *B,
                                       const hml_sparse_layout_t layoutB,
                                       const HML_INT ldb,
                                       const float alpha,
                                       const float beta,
                                       float *C,
                                       const hml_sparse_layout_t layoutC,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_d_syprd(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const double *B,
                                       const hml_sparse_layout_t layoutB,
                                       const HML_INT ldb,
                                       const double alpha,
                                       const double beta,
                                       double *C,
                                       const hml_sparse_layout_t layoutC,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_c_syprd(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const HML_Complex8 *B,
                                       const hml_sparse_layout_t layoutB,
                                       const HML_INT ldb,
                                       const HML_Complex8 alpha,
                                       const HML_Complex8 beta,
                                       HML_Complex8 *C,
                                       const hml_sparse_layout_t layoutC,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_z_syprd(const hml_sparse_operation_t op,
                                       const hml_sparse_matrix_t A,
                                       const HML_Complex16 *B,
                                       const hml_sparse_layout_t layoutB,
                                       const HML_INT ldb,
                                       const HML_Complex16 alpha,
                                       const HML_Complex16 beta,
                                       HML_Complex16 *C,
                                       const hml_sparse_layout_t layoutC,
                                       const HML_INT ldc);

/*   Computes product of sparse matrices: C = op(A) * B, result is dense   */
hml_sparse_status_t hml_sparse_s_spmmd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_matrix_t B,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       float *C,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_d_spmmd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_matrix_t B,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       double *C,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_c_spmmd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_matrix_t B,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       HML_Complex8 *C,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_z_spmmd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_matrix_t B,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       HML_Complex16 *C,
                                       const HML_INT ldc);

/*   Computes product of sparse matrices: C = opA(A) * opB(B), result is dense*/
hml_sparse_status_t hml_sparse_s_sp2md(const hml_sparse_operation_t transA,
                                       const struct hml_matrix_descr descrA,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_operation_t transB,
                                       const struct hml_matrix_descr descrB,
                                       const hml_sparse_matrix_t B,
                                       const float alpha,
                                       const float beta,
                                       float *C,
                                       const hml_sparse_layout_t layout,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_d_sp2md(const hml_sparse_operation_t transA,
                                       const struct hml_matrix_descr descrA,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_operation_t transB,
                                       const struct hml_matrix_descr descrB,
                                       const hml_sparse_matrix_t B,
                                       const double alpha,
                                       const double beta,
                                       double *C,
                                       const hml_sparse_layout_t layout,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_c_sp2md(const hml_sparse_operation_t transA,
                                       const struct hml_matrix_descr descrA,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_operation_t transB,
                                       const struct hml_matrix_descr descrB,
                                       const hml_sparse_matrix_t B,
                                       const HML_Complex8 alpha,
                                       const HML_Complex8 beta,
                                       HML_Complex8 *C,
                                       const hml_sparse_layout_t layout,
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_z_sp2md(const hml_sparse_operation_t transA,
                                       const struct hml_matrix_descr descrA,
                                       const hml_sparse_matrix_t A,
                                       const hml_sparse_operation_t transB,
                                       const struct hml_matrix_descr descrB,
                                       const hml_sparse_matrix_t B,
                                       const HML_Complex16 alpha,
                                       const HML_Complex16 beta,
                                       HML_Complex16 *C,
                                       const hml_sparse_layout_t layout,
                                       const HML_INT ldc);

/*   Computes product of sparse matrices: C = op(A) * (op(A))^{T for real or H for complex}, result is dense */
hml_sparse_status_t hml_sparse_s_syrkd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const float alpha,
                                       const float beta,
                                       float *C,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_d_syrkd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const double alpha,
                                       const double beta,
                                       double *C,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_c_syrkd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const HML_Complex8 alpha,
                                       const HML_Complex8 beta,
                                       HML_Complex8 *C,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_z_syrkd(const hml_sparse_operation_t operation,
                                       const hml_sparse_matrix_t A,
                                       const HML_Complex16 alpha,
                                       const HML_Complex16 beta,
                                       HML_Complex16 *C,
                                       const hml_sparse_layout_t layout, /* storage scheme for the output dense matrix: C-style or Fortran-style */
                                       const HML_INT ldc);

hml_sparse_status_t hml_sparse_s_axpy(const HML_INT nz,
                                      const float a,
                                      const float *x,
                                      const HML_INT *indx,
                                      float *y);

hml_sparse_status_t hml_sparse_d_axpy(const HML_INT nz,
                                      const double a,
                                      const double *x,
                                      const HML_INT *indx,
                                      double *y);

hml_sparse_status_t hml_sparse_c_axpy(const HML_INT nz,
                                      const HML_Complex8 a,
                                      const HML_Complex8 *x,
                                      const HML_INT *indx,
                                      HML_Complex8 *y);

hml_sparse_status_t hml_sparse_z_axpy(const HML_INT nz,
                                      const HML_Complex16 a,
                                      const HML_Complex16 *x,
                                      const HML_INT *indx,
                                      HML_Complex16 *y);

hml_sparse_status_t hml_sparse_s_gthr(const HML_INT nz,
                                      const float *y,
                                      float *x,
                                      const HML_INT *indx);

hml_sparse_status_t hml_sparse_d_gthr(const HML_INT nz,
                                      const double *y,
                                      double *x,
                                      const HML_INT *indx);

hml_sparse_status_t hml_sparse_c_gthr(const HML_INT nz,
                                      const HML_Complex8 *y,
                                      HML_Complex8 *x,
                                      const HML_INT *indx);

hml_sparse_status_t hml_sparse_z_gthr(const HML_INT nz,
                                      const HML_Complex16 *y,
                                      HML_Complex16 *x,
                                      const HML_INT *indx);

hml_sparse_status_t hml_sparse_s_gthrz(const HML_INT nz,
                                       float *y,
                                       float *x,
                                       const HML_INT *indx);

hml_sparse_status_t hml_sparse_d_gthrz(const HML_INT nz,
                                       double *y,
                                       double *x,
                                       const HML_INT *indx);

hml_sparse_status_t hml_sparse_c_gthrz(const HML_INT nz,
                                       HML_Complex8 *y,
                                       HML_Complex8 *x,
                                       const HML_INT *indx);

hml_sparse_status_t hml_sparse_z_gthrz(const HML_INT nz,
                                       HML_Complex16 *y,
                                       HML_Complex16 *x,
                                       const HML_INT *indx);

hml_sparse_status_t hml_sparse_s_rot(const HML_INT nz,
                                     float *x,
                                     const HML_INT *indx,
                                     float *y,
                                     const float c,
                                     const float s);

hml_sparse_status_t hml_sparse_d_rot(const HML_INT nz,
                                     double *x,
                                     const HML_INT *indx,
                                     double *y,
                                     const double c,
                                     const double s);

hml_sparse_status_t hml_sparse_s_sctr(const HML_INT nz,
                                      const float *x,
                                      const HML_INT *indx,
                                      float *y);

hml_sparse_status_t hml_sparse_d_sctr(const HML_INT nz,
                                      const double *x,
                                      const HML_INT *indx,
                                      double *y);

hml_sparse_status_t hml_sparse_c_sctr(const HML_INT nz,
                                      const HML_Complex8 *x,
                                      const HML_INT *indx,
                                      HML_Complex8 *y);

hml_sparse_status_t hml_sparse_z_sctr(const HML_INT nz,
                                      const HML_Complex16 *x,
                                      const HML_INT *indx,
                                      HML_Complex16 *y);

float hml_sparse_s_doti(const HML_INT nz,
                        const float *x,
                        const HML_INT *indx,
                        const float *y);

double hml_sparse_d_doti(const HML_INT nz,
                         const double *x,
                         const HML_INT *indx,
                         const double *y);

void hml_sparse_c_dotci_sub(const HML_INT nz,
                            const HML_Complex8 *x,
                            const HML_INT *indx,
                            const HML_Complex8 *y,
                            HML_Complex8 *dotci);

void hml_sparse_z_dotci_sub(const HML_INT nz,
                            const HML_Complex16 *x,
                            const HML_INT *indx,
                            const HML_Complex16 *y,
                            HML_Complex16 *dotci);

void hml_sparse_c_dotui_sub(const HML_INT nz,
                            const HML_Complex8 *x,
                            const HML_INT *indx,
                            const HML_Complex8 *y,
                            HML_Complex8 *dotui);

void hml_sparse_z_dotui_sub(const HML_INT nz,
                            const HML_Complex16 *x,
                            const HML_INT *indx,
                            const HML_Complex16 *y,
                            HML_Complex16 *dotui);
