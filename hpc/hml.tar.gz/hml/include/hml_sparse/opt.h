#pragma once

/**
 * @brief header for optimizetion related parameter definitions
 */

#include "hml_sparse/util/thread.h"
