#pragma once

#include "types.h"
#include "complex_compute.h"
#include "real_compute.h"

#ifndef COMPLEX

#define hml_setone real_setone
#define hml_setzero real_setzero
#define hml_iszero real_iszero
#define hml_isone real_isone
#define hml_add real_add
#define hml_sub real_sub
#define hml_mul real_mul
#define hml_div real_div
#define hml_madd real_madd
#define hml_msub real_msub

#define hml_adde real_adde
#define hml_sube real_sube
#define hml_mule real_mule
#define hml_dive real_dive
#define hml_madde real_madde
#define hml_msube real_msube

#define hml_copy real_copy
#define hml_cross_entropy real_cross_entropy

#else

#define hml_setone cmp_setone
#define hml_setzero cmp_setzero
#define hml_iszero cmp_iszero
#define hml_isone cmp_isone
#define hml_add cmp_add
#define hml_sub cmp_sub
#define hml_mul cmp_mul
#define hml_mul_2c cmp_mul_2c
#define hml_mul_3c cmp_mul_3c
#define hml_div cmp_div
#define hml_div_3c cmp_div_3c
#define hml_madd cmp_madd
#define hml_madd_2c cmp_madd_2c
#define hml_madd_3c cmp_madd_3c
#define hml_msub cmp_msub

#define hml_adde cmp_adde
#define hml_sube cmp_sube
#define hml_mule cmp_mule
#define hml_mule_2c cmp_mule_2c
#define hml_mule_3c cmp_mule_3c
#define hml_dive cmp_dive
#define hml_madde cmp_madde
#define hml_madde_2c cmp_madde_2c
#define hml_madde_3c cmp_madde_3c
#define hml_msube cmp_msube
#define hml_msube_2c cmp_msube_2c
#define hml_conj cmp_conj

#define hml_copy cmp_copy
#define hml_cross_entropy cmp_cross_entropy

#endif


#if defined(__AVX2__)
#include <immintrin.h>

#if defined(DOUBLE)
    #define __ymm               __m256d
    #define __zero()            _mm256_setzero_pd()
    #define __set1(x)           _mm256_set1_pd(x)
    #define __broad(x)          _mm256_broadcast_sd((const void*)(x))
    #define __load(x)           _mm256_loadu_pd((const void*)(x))
    #define __store(x, y)       _mm256_storeu_pd((void*)(x), y)
    #define __fmadd(a, b, c)    _mm256_fmadd_pd(a, b, c)
    #define __addsub(x, y)      _mm256_addsub_pd(x, y)
    #define __swap_re_im(x)     _mm256_permute_pd(x, 0x5)
#else
    #define __ymm               __m256
    #define __zero()            _mm256_setzero_ps()
    #define __set1(x)           _mm256_set1_ps(x)
    #define __broad(x)          _mm256_broadcast_ss((const void*)(x))
    #define __load(x)           _mm256_loadu_ps((const void*)(x))
    #define __store(x, y)       _mm256_storeu_ps((void*)(x), y)
    #define __fmadd(a, b, c)    _mm256_fmadd_ps(a, b, c)
    #define __addsub(x, y)      _mm256_addsub_ps(x, y)
    #define __swap_re_im(x)     _mm256_permute_ps(x, 0xb1)
#endif
#endif


// y[i] = a * x[i]
static inline void _broad_mul(int n, HML_Number a, const HML_Number *x, HML_Number *y)
{
#if defined(__AVX2__) && defined(COMPLEX)
    const int step = sizeof(__ymm) / sizeof(HML_Number);
    const __ymm AR = __set1(a.real);
    const __ymm AI = __addsub(__zero(), __set1(a.imag));

    while (n >= step) {
        __ymm X = __load(x);
        __ymm Y = AR * X + AI * __swap_re_im(X);
        __store(y, Y);
        x += step;
        y += step;
        n -= step;
    }
#endif

    for (int i=0; i<n; i++) {
        hml_mul(y[i], a, x[i]);
    }
}


// y[i] = a * x[i] + y[i]
static inline void _axpy(int n, HML_Number a, const HML_Number *x, HML_Number *y)
{
#if defined(__AVX2__) && defined(COMPLEX)
    const int step = sizeof(__ymm) / sizeof(HML_Number);
    const __ymm AR = __set1(a.real);
    const __ymm AI = __addsub(__zero(), __set1(a.imag));

    while (n >= step) {
        __ymm X = __load(x);
        __ymm Y = __load(y);
        Y += AR * X + AI * __swap_re_im(X);
        __store(y, Y);
        x += step;
        y += step;
        n -= step;
    }
#endif

    for (int i=0; i<n; i++) {
        hml_madde(y[i], a, x[i]);
    }
}


// y[i] = a * x[i] + b * y[i]
static inline void _axpby(int n, HML_Number a, HML_Number b,
                          const HML_Number *x, HML_Number *y)
{
#if defined(__AVX2__) && defined(COMPLEX)
    const int step = sizeof(__ymm) / sizeof(HML_Number);
    const __ymm AR = __set1(a.real), AI = __addsub(__zero(), __set1(a.imag));
    const __ymm BR = __set1(b.real), BI = __addsub(__zero(), __set1(b.imag));

    while (n >= step) {
        __ymm X = __load(x);
        __ymm Y = __load(y);
        __ymm AX = AR * X + AI * __swap_re_im(X);
        __ymm BY = BR * Y + BI * __swap_re_im(Y);
        __store(y, AX + BY);
        x += step;
        y += step;
        n -= step;
    }
#endif

    for (int i=0; i<n; i++) {
        HML_Number s;
        hml_mul(s, b, y[i]);
        hml_madde(s, a, x[i]);
        y[i] = s;
    }
}

