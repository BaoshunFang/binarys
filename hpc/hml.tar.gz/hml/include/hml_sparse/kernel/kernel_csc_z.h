#pragma once

#include "../spmat.h"

hml_sparse_status_t add_z_csc(const spmat_csc_z_t *A, const HML_Complex16 alpha, const spmat_csc_z_t *B, spmat_csc_z_t **C);
hml_sparse_status_t add_z_csc_trans(const spmat_csc_z_t *A, const HML_Complex16 alpha, const spmat_csc_z_t *B, spmat_csc_z_t **C);
hml_sparse_status_t add_z_csc_conj(const spmat_csc_z_t *A, const HML_Complex16 alpha, const spmat_csc_z_t *B, spmat_csc_z_t **C);

// --------------------------------------------------------------------------------------------------------------------------------

// mv
// alpha*A*x + beta*y
hml_sparse_status_t gemv_z_csc(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_z_csc_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_z_csc_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_z_csc_n_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_z_csc_u_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_z_csc_n_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_z_csc_u_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_z_csc_n_lo_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_z_csc_u_lo_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_z_csc_n_hi_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_z_csc_u_hi_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t hermv_z_csc_n_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t hermv_z_csc_u_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t hermv_z_csc_n_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t hermv_z_csc_u_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D+L')^T*x + beta*y
hml_sparse_status_t hermv_z_csc_n_lo_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')^T*x + beta*y
hml_sparse_status_t hermv_z_csc_u_lo_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)^T*x + beta*y
hml_sparse_status_t hermv_z_csc_n_hi_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)^T*x + beta*y
hml_sparse_status_t hermv_z_csc_u_hi_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t trmv_z_csc_n_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t trmv_z_csc_u_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t trmv_z_csc_n_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t trmv_z_csc_u_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_n_lo_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_u_lo_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_n_hi_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_u_hi_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_n_lo_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_u_lo_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_n_hi_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_z_csc_u_hi_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*D*x + beta*y
hml_sparse_status_t diagmv_z_csc_n(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*x + beta*y
hml_sparse_status_t diagmv_z_csc_u(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// --------------------------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------------

// alpha*A*B + beta*C
hml_sparse_status_t gemm_z_csc_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_csc_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_z_csc_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_csc_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_z_csc_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_csc_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_csc_n_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_csc_u_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_csc_n_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_csc_u_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_csc_n_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_csc_u_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_csc_n_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_csc_u_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_csc_n_lo_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_csc_u_lo_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_csc_n_hi_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_csc_u_hi_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_csc_n_lo_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_csc_u_lo_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_csc_n_hi_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_csc_u_hi_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t hermm_z_csc_n_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t hermm_z_csc_u_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t hermm_z_csc_n_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t hermm_z_csc_u_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t hermm_z_csc_n_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t hermm_z_csc_u_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t hermm_z_csc_n_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t hermm_z_csc_u_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T^T*B + beta*C
hml_sparse_status_t hermm_z_csc_n_lo_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')^T*B + beta*C
hml_sparse_status_t hermm_z_csc_u_lo_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)^T*B + beta*C
hml_sparse_status_t hermm_z_csc_n_hi_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)^T*B + beta*C
hml_sparse_status_t hermm_z_csc_u_hi_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T^T*B + beta*C
hml_sparse_status_t hermm_z_csc_n_lo_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')^T*B + beta*C
hml_sparse_status_t hermm_z_csc_u_lo_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)^T*B + beta*C
hml_sparse_status_t hermm_z_csc_n_hi_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)^T*B + beta*C
hml_sparse_status_t hermm_z_csc_u_hi_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_z_csc_n_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_z_csc_u_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t trmm_z_csc_n_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t trmm_z_csc_u_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_z_csc_n_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_z_csc_u_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t trmm_z_csc_n_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t trmm_z_csc_u_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_lo_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_lo_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_hi_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_hi_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_lo_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_lo_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_hi_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_hi_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_lo_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_lo_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_hi_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_hi_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_lo_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_lo_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_n_hi_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_csc_u_hi_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*D*B + beta*C
hml_sparse_status_t diagmm_z_csc_n_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_z_csc_u_row(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*D*B + beta*C
hml_sparse_status_t diagmm_z_csc_n_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_z_csc_u_col(const HML_Complex16 alpha, const spmat_csc_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// ---------------------------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------

// A*B
hml_sparse_status_t spmmd_z_csc_row(const spmat_csc_z_t *matA, const spmat_csc_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A*B
hml_sparse_status_t spmmd_z_csc_col(const spmat_csc_z_t *matA, const spmat_csc_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_csc_row_trans(const spmat_csc_z_t *matA, const spmat_csc_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_csc_col_trans(const spmat_csc_z_t *matA, const spmat_csc_z_t *matB, HML_Complex16 *C, const HML_INT ldc);

// A^T*B
hml_sparse_status_t spmmd_z_csc_row_conj(const spmat_csc_z_t *matA, const spmat_csc_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_csc_col_conj(const spmat_csc_z_t *matA, const spmat_csc_z_t *matB, HML_Complex16 *C, const HML_INT ldc);

hml_sparse_status_t spmm_z_csc(const spmat_csc_z_t *A, const spmat_csc_z_t *B, spmat_csc_z_t **C);
hml_sparse_status_t spmm_z_csc_trans(const spmat_csc_z_t *A, const spmat_csc_z_t *B, spmat_csc_z_t **C);
hml_sparse_status_t spmm_z_csc_conj(const spmat_csc_z_t *A, const spmat_csc_z_t *B, spmat_csc_z_t **C);

// -----------------------------------------------------------------------------------------------------

// alpha*inv(L)*x
hml_sparse_status_t trsv_z_csc_n_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L)*x
hml_sparse_status_t trsv_z_csc_u_lo(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_z_csc_n_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_z_csc_u_hi(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_csc_n_lo_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_csc_u_lo_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_csc_n_hi_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_csc_u_hi_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_csc_n_lo_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_csc_u_lo_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_csc_n_hi_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_csc_u_hi_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);

// alpha*inv(D)*x
hml_sparse_status_t diagsv_z_csc_n(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*x
hml_sparse_status_t diagsv_z_csc_u(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_n_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_u_lo_row(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_n_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_u_hi_row(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_n_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_u_lo_col(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_n_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_u_hi_col(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_n_lo_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_u_lo_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_n_hi_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_u_hi_row_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_n_lo_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_u_lo_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_n_hi_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_u_hi_col_trans(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_n_lo_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_u_lo_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_n_hi_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_u_hi_row_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_n_lo_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_csc_u_lo_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_n_hi_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_csc_u_hi_col_conj(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(D)*x
hml_sparse_status_t diagsm_z_csc_n_row(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_z_csc_u_row(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(D)*x
hml_sparse_status_t diagsm_z_csc_n_col(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_z_csc_u_col(const HML_Complex16 alpha, const spmat_csc_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

hml_sparse_status_t set_value_z_csc(spmat_csc_z_t *A, const HML_INT row, const HML_INT col, const HML_Complex16 value);
