#pragma once

#include "../spmat.h"

hml_sparse_status_t add_z_bsr(const spmat_bsr_z_t *A, const HML_Complex16 alpha, const spmat_bsr_z_t *B, spmat_bsr_z_t **C);
hml_sparse_status_t add_z_bsr_trans(const spmat_bsr_z_t *A, const HML_Complex16 alpha, const spmat_bsr_z_t *B, spmat_bsr_z_t **C);

// --------------------------------------------------------------------------------------------------------------------------------

// mv
// alpha*A*x + beta*y
hml_sparse_status_t gemv_z_bsr(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_z_bsr_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_z_bsr_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_z_bsr_n_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_z_bsr_u_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_z_bsr_n_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_z_bsr_u_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_z_bsr_n_lo_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_z_bsr_u_lo_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_z_bsr_n_hi_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_z_bsr_u_hi_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t hermv_z_bsr_n_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t hermv_z_bsr_u_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t hermv_z_bsr_n_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t hermv_z_bsr_u_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t hermv_z_bsr_n_lo_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t hermv_z_bsr_u_lo_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t hermv_z_bsr_n_hi_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t hermv_z_bsr_u_hi_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t trmv_z_bsr_n_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t trmv_z_bsr_u_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t trmv_z_bsr_n_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t trmv_z_bsr_u_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_z_bsr_n_lo_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_z_bsr_u_lo_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_z_bsr_n_hi_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_z_bsr_u_hi_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

hml_sparse_status_t trmv_z_bsr_n_lo_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t trmv_z_bsr_u_lo_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t trmv_z_bsr_n_hi_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t trmv_z_bsr_u_hi_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*D*x + beta*y
hml_sparse_status_t diagmv_z_bsr_n(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*x + beta*y
hml_sparse_status_t diagmv_z_bsr_u(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// --------------------------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------------

// alpha*A*B + beta*C
hml_sparse_status_t gemm_z_bsr_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_bsr_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_z_bsr_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_bsr_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

hml_sparse_status_t gemm_z_bsr_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_bsr_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_bsr_n_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_bsr_u_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_n_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_u_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_bsr_n_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_bsr_u_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_n_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_u_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_bsr_n_lo_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_bsr_u_lo_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_n_hi_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_u_hi_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_bsr_n_lo_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_bsr_u_lo_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_n_hi_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_bsr_u_hi_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_lo_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_lo_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_hi_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_hi_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_lo_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_lo_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_n_hi_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t hermm_z_bsr_u_hi_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_lo_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_lo_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_hi_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_hi_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_lo_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_lo_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_hi_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_hi_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_lo_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_lo_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_hi_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_hi_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_lo_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_lo_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_n_hi_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_bsr_u_hi_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*D*B + beta*C
hml_sparse_status_t diagmm_z_bsr_n_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_z_bsr_u_row(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*D*B + beta*C
hml_sparse_status_t diagmm_z_bsr_n_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_z_bsr_u_col(const HML_Complex16 alpha, const spmat_bsr_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// ---------------------------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------

// A*B
hml_sparse_status_t spmmd_z_bsr_row(const spmat_bsr_z_t *matA, const spmat_bsr_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A*B
hml_sparse_status_t spmmd_z_bsr_col(const spmat_bsr_z_t *matA, const spmat_bsr_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_bsr_row_trans(const spmat_bsr_z_t *matA, const spmat_bsr_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_bsr_col_trans(const spmat_bsr_z_t *matA, const spmat_bsr_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_bsr_row_conj(const spmat_bsr_z_t *matA, const spmat_bsr_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_bsr_col_conj(const spmat_bsr_z_t *matA, const spmat_bsr_z_t *matB, HML_Complex16 *C, const HML_INT ldc);

hml_sparse_status_t spmm_z_bsr(const spmat_bsr_z_t *A, const spmat_bsr_z_t *B, spmat_bsr_z_t **C);
hml_sparse_status_t spmm_z_bsr_trans(const spmat_bsr_z_t *A, const spmat_bsr_z_t *B, spmat_bsr_z_t **C);
hml_sparse_status_t spmm_z_bsr_conj(const spmat_bsr_z_t *A, const spmat_bsr_z_t *B, spmat_bsr_z_t **C);

// -----------------------------------------------------------------------------------------------------

// alpha*inv(L)*x
hml_sparse_status_t trsv_z_bsr_n_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L)*x
hml_sparse_status_t trsv_z_bsr_u_lo(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_z_bsr_n_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_z_bsr_u_hi(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_bsr_n_lo_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_bsr_u_lo_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_bsr_n_hi_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_bsr_u_hi_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_bsr_n_lo_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_bsr_u_lo_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_bsr_n_hi_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_bsr_u_hi_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);

// alpha*inv(D)*x
hml_sparse_status_t diagsv_z_bsr_n(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*x
hml_sparse_status_t diagsv_z_bsr_u(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_n_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_u_lo_row(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_n_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_u_hi_row(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_n_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_u_lo_col(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_n_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_u_hi_col(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_n_lo_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_u_lo_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_n_hi_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_u_hi_row_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_n_lo_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_u_lo_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_n_hi_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_u_hi_col_trans(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_n_lo_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_u_lo_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_n_hi_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_u_hi_row_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_n_lo_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_bsr_u_lo_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_n_hi_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_bsr_u_hi_col_conj(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(D)*x
hml_sparse_status_t diagsm_z_bsr_n_row(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_z_bsr_u_row(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(D)*x
hml_sparse_status_t diagsm_z_bsr_n_col(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_z_bsr_u_col(const HML_Complex16 alpha, const spmat_bsr_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

hml_sparse_status_t axpy_z(const HML_INT nz, const HML_Complex16 a, const HML_Complex16 *x, const HML_INT *indx, HML_Complex16 *y);

hml_sparse_status_t gthr_z(const HML_INT nz, const HML_Complex16 *y, HML_Complex16 *x, const HML_INT *indx);

hml_sparse_status_t rot_z(const HML_INT nz, HML_Complex16 *x, const HML_INT *indx, HML_Complex16 *y, const HML_Complex16 c, const HML_Complex16 s);

hml_sparse_status_t sctr_z(const HML_INT nz, const HML_Complex16 *x, const HML_INT *indx, HML_Complex16 *y);

HML_Complex16 doti_z(const HML_INT nz, const HML_Complex16 *x, const HML_INT *indx, const HML_Complex16 *y);

hml_sparse_status_t set_value_z_bsr(spmat_bsr_z_t *A, const HML_INT row, const HML_INT col, const HML_Complex16 value);
hml_sparse_status_t update_values_z_bsr(spmat_bsr_z_t *A, const HML_INT nvalues, const HML_INT *indx, const HML_INT *indy, HML_Complex16 *values);
