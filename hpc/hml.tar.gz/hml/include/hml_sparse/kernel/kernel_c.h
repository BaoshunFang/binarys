#pragma once

#include "../spdef.h"
#include "../types.h"

hml_sparse_status_t axpy_c_(const HML_INT nz, const HML_Complex8 a, const HML_Complex8 *x, const HML_INT *indx, HML_Complex8 *y);
hml_sparse_status_t gthr_c_(const HML_INT nz, const HML_Complex8 *y, HML_Complex8 *x, const HML_INT *indx);
hml_sparse_status_t gthrz_c_(const HML_INT nz, HML_Complex8 *y, HML_Complex8 *x, const HML_INT *indx);
hml_sparse_status_t sctr_c_(const HML_INT nz, const HML_Complex8 *x, const HML_INT *indx, HML_Complex8 *y);
void dotui_c_sub(const HML_INT nz, const HML_Complex8 *x, const HML_INT *indx, const HML_Complex8 *y, HML_Complex8 *dutui);
void dotci_c_sub(const HML_INT nz, const HML_Complex8 *x, const HML_INT *indx, const HML_Complex8 *y, HML_Complex8 *dutci);
