#pragma once

#include "../spdef.h"
#include "../types.h"

hml_sparse_status_t axpy_z_(const HML_INT nz, const HML_Complex16 a, const HML_Complex16 *x, const HML_INT *indx, HML_Complex16 *y);
hml_sparse_status_t gthr_z_(const HML_INT nz, const HML_Complex16 *y, HML_Complex16 *x, const HML_INT *indx);
hml_sparse_status_t gthrz_z_(const HML_INT nz, HML_Complex16 *y, HML_Complex16 *x, const HML_INT *indx);
hml_sparse_status_t sctr_z_(const HML_INT nz, const HML_Complex16 *x, const HML_INT *indx, HML_Complex16 *y);
void dotci_z_sub(const HML_INT nz, const HML_Complex16 *x, const HML_INT *indx, const HML_Complex16 *y, HML_Complex16 *dutci);
void dotui_z_sub(const HML_INT nz, const HML_Complex16 *x, const HML_INT *indx, const HML_Complex16 *y, HML_Complex16 *dutui);
