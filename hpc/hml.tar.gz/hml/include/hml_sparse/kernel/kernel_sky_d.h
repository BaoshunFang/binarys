#pragma once

#include "../spmat.h"

hml_sparse_status_t add_d_sky(const spmat_sky_d_t *A, const double alpha, const spmat_sky_d_t *B, spmat_sky_d_t **C);
hml_sparse_status_t add_d_sky_trans(const spmat_sky_d_t *A, const double alpha, const spmat_sky_d_t *B, spmat_sky_d_t **C);

// --------------------------------------------------------------------------------------------------------------------------------

// mv
// alpha*A*x + beta*y
hml_sparse_status_t gemv_d_sky(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_d_sky_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_d_sky_n_lo(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_d_sky_u_lo(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_d_sky_n_hi(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_d_sky_u_hi(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t trmv_d_sky_n_lo(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t trmv_d_sky_u_lo(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t trmv_d_sky_n_hi(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t trmv_d_sky_u_hi(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_d_sky_n_lo_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_d_sky_u_lo_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_d_sky_n_hi_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_d_sky_u_hi_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);

// alpha*D*x + beta*y
hml_sparse_status_t diagmv_d_sky_n(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);
// alpha*x + beta*y
hml_sparse_status_t diagmv_d_sky_u(const double alpha, const spmat_sky_d_t *A, const double *x, const double beta, double *y);

// --------------------------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------------

// alpha*A*B + beta*C
hml_sparse_status_t gemm_d_sky_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
hml_sparse_status_t gemm_d_sky_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_d_sky_row_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
hml_sparse_status_t gemm_d_sky_col_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_d_sky_n_lo_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_d_sky_u_lo_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_d_sky_n_hi_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_d_sky_u_hi_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_d_sky_n_lo_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_d_sky_u_lo_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_d_sky_n_hi_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_d_sky_u_hi_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_d_sky_n_lo_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_d_sky_u_lo_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t trmm_d_sky_n_hi_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t trmm_d_sky_u_hi_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_d_sky_n_lo_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_d_sky_u_lo_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t trmm_d_sky_n_hi_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t trmm_d_sky_u_hi_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_n_lo_row_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_u_lo_row_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_n_hi_row_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_u_hi_row_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_n_lo_col_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_u_lo_col_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_n_hi_col_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_d_sky_u_hi_col_trans(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);

// alpha*D*B + beta*C
hml_sparse_status_t diagmm_d_sky_n_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_d_sky_u_row(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*D*B + beta*C
hml_sparse_status_t diagmm_d_sky_n_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_d_sky_u_col(const double alpha, const spmat_sky_d_t *mat, const double *x, const HML_INT columns, const HML_INT ldx, const double beta, double *y, const HML_INT ldy);

// ---------------------------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------

// A*B
hml_sparse_status_t spmmd_d_sky_row(const spmat_sky_d_t *matA, const spmat_sky_d_t *matB, double *C, const HML_INT ldc);
// A*B
hml_sparse_status_t spmmd_d_sky_col(const spmat_sky_d_t *matA, const spmat_sky_d_t *matB, double *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_d_sky_row_trans(const spmat_sky_d_t *matA, const spmat_sky_d_t *matB, double *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_d_sky_col_trans(const spmat_sky_d_t *matA, const spmat_sky_d_t *matB, double *C, const HML_INT ldc);

hml_sparse_status_t spmm_d_sky(const spmat_sky_d_t *A, const spmat_sky_d_t *B, spmat_sky_d_t **C);
hml_sparse_status_t spmm_d_sky_trans(const spmat_sky_d_t *A, const spmat_sky_d_t *B, spmat_sky_d_t **C);

// -----------------------------------------------------------------------------------------------------

// alpha*inv(L)*x
hml_sparse_status_t trsv_d_sky_n_lo(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*inv(L)*x
hml_sparse_status_t trsv_d_sky_u_lo(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_d_sky_n_hi(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_d_sky_u_hi(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_d_sky_n_lo_trans(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_d_sky_u_lo_trans(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_d_sky_n_hi_trans(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_d_sky_u_hi_trans(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);

// alpha*inv(D)*x
hml_sparse_status_t diagsv_d_sky_n(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);
// alpha*x
hml_sparse_status_t diagsv_d_sky_u(const double alpha, const spmat_sky_d_t *A, const double *x, double *y);

// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_n_lo_row(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_u_lo_row(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_n_hi_row(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_u_hi_row(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_n_lo_col(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_u_lo_col(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_n_hi_col(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_u_hi_col(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_n_lo_row_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_u_lo_row_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_n_hi_row_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_u_hi_row_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_n_lo_col_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_d_sky_u_lo_col_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_n_hi_col_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_d_sky_u_hi_col_trans(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);

// alpha*inv(D)*x
hml_sparse_status_t diagsm_d_sky_n_row(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_d_sky_u_row(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*inv(D)*x
hml_sparse_status_t diagsm_d_sky_n_col(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_d_sky_u_col(const double alpha, const spmat_sky_d_t *A, const double *x, const HML_INT columns, const HML_INT ldx, double *y, const HML_INT ldy);

hml_sparse_status_t set_value_d_sky(spmat_sky_d_t *A, const HML_INT row, const HML_INT col, const double value);