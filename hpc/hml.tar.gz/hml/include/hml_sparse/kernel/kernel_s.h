#pragma once

#include "../spdef.h"
#include "../types.h"

hml_sparse_status_t axpy_s_(const HML_INT nz, const float a, const float *x, const HML_INT *indx, float *y);
hml_sparse_status_t gthr_s_(const HML_INT nz, const float *y, float *x, const HML_INT *indx);
hml_sparse_status_t gthrz_s_(const HML_INT nz, float *y, float *x, const HML_INT *indx);
hml_sparse_status_t rot_s_(const HML_INT nz, float *x, const HML_INT *indx, float *y, const float c, const float s);
hml_sparse_status_t sctr_s_(const HML_INT nz, const float *x, const HML_INT *indx, float *y);
float doti_s_(const HML_INT nz, const float *x, const HML_INT *indx, const float *y);
