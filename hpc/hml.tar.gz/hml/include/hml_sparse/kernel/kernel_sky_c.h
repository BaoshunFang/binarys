#pragma once

#include "../spmat.h"

hml_sparse_status_t add_c_sky(const spmat_sky_c_t *A, const HML_Complex8 alpha, const spmat_sky_c_t *B, spmat_sky_c_t **C);
hml_sparse_status_t add_c_sky_trans(const spmat_sky_c_t *A, const HML_Complex8 alpha, const spmat_sky_c_t *B, spmat_sky_c_t **C);

// --------------------------------------------------------------------------------------------------------------------------------

// mv
// alpha*A*x + beta*y
hml_sparse_status_t gemv_c_sky(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_c_sky_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_c_sky_n_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_c_sky_u_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_c_sky_n_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_c_sky_u_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_c_sky_n_lo_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_c_sky_u_lo_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_c_sky_n_hi_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_c_sky_u_hi_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t hermv_c_sky_n_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t hermv_c_sky_u_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t hermv_c_sky_n_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t hermv_c_sky_u_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t hermv_c_sky_n_lo_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t hermv_c_sky_u_lo_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t hermv_c_sky_n_hi_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t hermv_c_sky_u_hi_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t trmv_c_sky_n_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t trmv_c_sky_u_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t trmv_c_sky_n_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t trmv_c_sky_u_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_n_lo_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_u_lo_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_n_hi_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_u_hi_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_n_lo_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_u_lo_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_n_hi_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_c_sky_u_hi_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// alpha*D*x + beta*y
hml_sparse_status_t diagmv_c_sky_n(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);
// alpha*x + beta*y
hml_sparse_status_t diagmv_c_sky_u(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_Complex8 beta, HML_Complex8 *y);

// --------------------------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------------

// alpha*A*B + beta*C
hml_sparse_status_t gemm_c_sky_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
hml_sparse_status_t gemm_c_sky_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_c_sky_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
hml_sparse_status_t gemm_c_sky_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_c_sky_n_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_c_sky_u_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_c_sky_n_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_c_sky_u_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_c_sky_n_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_c_sky_u_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_c_sky_n_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_c_sky_u_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_c_sky_n_lo_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_c_sky_u_lo_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_c_sky_n_hi_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_c_sky_u_hi_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_c_sky_n_lo_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_c_sky_u_lo_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_c_sky_n_hi_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_c_sky_u_hi_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t hermm_c_sky_n_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t hermm_c_sky_u_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t hermm_c_sky_n_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t hermm_c_sky_u_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t hermm_c_sky_n_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t hermm_c_sky_u_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t hermm_c_sky_n_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t hermm_c_sky_u_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_n_lo_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_u_lo_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_n_hi_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_u_hi_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_n_lo_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_u_lo_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_n_hi_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t hermm_c_sky_u_hi_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_c_sky_n_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_c_sky_u_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t trmm_c_sky_n_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t trmm_c_sky_u_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_c_sky_n_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_c_sky_u_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t trmm_c_sky_n_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t trmm_c_sky_u_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_lo_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_lo_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_hi_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_hi_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_lo_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_lo_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_hi_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_hi_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_lo_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_lo_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_hi_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_hi_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_lo_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_lo_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_n_hi_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_c_sky_u_hi_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// alpha*D*B + beta*C
hml_sparse_status_t diagmm_c_sky_n_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_c_sky_u_row(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*D*B + beta*C
hml_sparse_status_t diagmm_c_sky_n_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_c_sky_u_col(const HML_Complex8 alpha, const spmat_sky_c_t *mat, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex8 beta, HML_Complex8 *y, const HML_INT ldy);

// ---------------------------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------

// A*B
hml_sparse_status_t spmmd_c_sky_row(const spmat_sky_c_t *matA, const spmat_sky_c_t *matB, HML_Complex8 *C, const HML_INT ldc);
// A*B
hml_sparse_status_t spmmd_c_sky_col(const spmat_sky_c_t *matA, const spmat_sky_c_t *matB, HML_Complex8 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_c_sky_row_trans(const spmat_sky_c_t *matA, const spmat_sky_c_t *matB, HML_Complex8 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_c_sky_col_trans(const spmat_sky_c_t *matA, const spmat_sky_c_t *matB, HML_Complex8 *C, const HML_INT ldc);

hml_sparse_status_t spmm_c_sky(const spmat_sky_c_t *A, const spmat_sky_c_t *B, spmat_sky_c_t **C);
hml_sparse_status_t spmm_c_sky_trans(const spmat_sky_c_t *A, const spmat_sky_c_t *B, spmat_sky_c_t **C);

// -----------------------------------------------------------------------------------------------------

// alpha*inv(L)*x
hml_sparse_status_t trsv_c_sky_n_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(L)*x
hml_sparse_status_t trsv_c_sky_u_lo(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_c_sky_n_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_c_sky_u_hi(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_c_sky_n_lo_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_c_sky_u_lo_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_c_sky_n_hi_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_c_sky_u_hi_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);

// alpha*inv(L^T)*x
hml_sparse_status_t trsv_c_sky_n_lo_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_c_sky_u_lo_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_c_sky_n_hi_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_c_sky_u_hi_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);

// alpha*inv(D)*x
hml_sparse_status_t diagsv_c_sky_n(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);
// alpha*x
hml_sparse_status_t diagsv_c_sky_u(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, HML_Complex8 *y);

// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_n_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_u_lo_row(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_n_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_u_hi_row(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_n_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_u_lo_col(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_n_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_u_hi_col(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_n_lo_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_u_lo_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_n_hi_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_u_hi_row_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_n_lo_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_u_lo_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_n_hi_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_u_hi_col_trans(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_n_lo_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_u_lo_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_n_hi_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_u_hi_row_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_n_lo_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_c_sky_u_lo_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_n_hi_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_c_sky_u_hi_col_conj(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);

// alpha*inv(D)*x
hml_sparse_status_t diagsm_c_sky_n_row(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_c_sky_u_row(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*inv(D)*x
hml_sparse_status_t diagsm_c_sky_n_col(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_c_sky_u_col(const HML_Complex8 alpha, const spmat_sky_c_t *A, const HML_Complex8 *x, const HML_INT columns, const HML_INT ldx, HML_Complex8 *y, const HML_INT ldy);

hml_sparse_status_t set_value_c_sky(spmat_sky_c_t *A, const HML_INT row, const HML_INT col, const HML_Complex8 value);
