#pragma once

#include "../spmat.h"

hml_sparse_status_t add_s_csr(const spmat_csr_s_t *A, const float alpha, const spmat_csr_s_t *B, spmat_csr_s_t **C);
hml_sparse_status_t add_s_csr_trans(const spmat_csr_s_t *A, const float alpha, const spmat_csr_s_t *B, spmat_csr_s_t **C);
hml_sparse_status_t add_s_csr_conj(const spmat_csr_s_t *A, const float alpha, const spmat_csr_s_t *B, spmat_csr_s_t **C);

// --------------------------------------------------------------------------------------------------------------------------------

// mv
// alpha*A*x + beta*y
hml_sparse_status_t gemv_s_csr(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_s_csr_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_s_csr_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_s_csr_n_lo(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_s_csr_u_lo(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_s_csr_n_hi(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_s_csr_u_hi(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t trmv_s_csr_n_lo(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t trmv_s_csr_u_lo(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t trmv_s_csr_n_hi(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t trmv_s_csr_u_hi(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_n_lo_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_u_lo_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_n_hi_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_u_hi_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_n_lo_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_u_lo_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_n_hi_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_s_csr_u_hi_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);

// alpha*D*x + beta*y
hml_sparse_status_t diagmv_s_csr_n(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);
// alpha*x + beta*y
hml_sparse_status_t diagmv_s_csr_u(const float alpha, const spmat_csr_s_t *A, const float *x, const float beta, float *y);

// --------------------------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------------

// alpha*A*B + beta*C
hml_sparse_status_t gemm_s_csr_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
hml_sparse_status_t gemm_s_csr_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_s_csr_row_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
hml_sparse_status_t gemm_s_csr_col_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_s_csr_row_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
hml_sparse_status_t gemm_s_csr_col_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_s_csr_n_lo_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_s_csr_u_lo_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_s_csr_n_hi_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_s_csr_u_hi_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_s_csr_n_lo_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_s_csr_u_lo_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_s_csr_n_hi_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_s_csr_u_hi_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

/*
common symm/hermm kernel:
    D = unit_diag ? eye(mat.shape) : mat.diagonal
    T = upper ? mat.upper_triangle : mat.lower_triangle
    A = conj0(T) + D + conj1(T')
    Y = alpha * A * X + beta * Y
*/
hml_sparse_status_t symmetric_mm_s_csr(const HML_Number alpha, const HML_SPMAT_CSR *mat, const HML_Number *x, const HML_INT columns, const HML_INT ldx,
                                       const HML_Number beta, HML_Number *y, const HML_INT ldy, int unit_diag, int upper, int conj0, int conj1, int row_major);


/*
common trmm kernel:
    T = upper ? mat.upper_triangle : mat.lower_triangle
    D = unit_diag ? eye(mat.shape) : mat.diagonal
    T1 = op(T + D, trans, conj)
    Y = alpha * T1 * X + beta * Y
*/
hml_sparse_status_t trmm_s_csr(const HML_Number alpha, const HML_SPMAT_CSR *mat, const HML_Number *x, const HML_INT columns, const HML_INT ldx,
                               const HML_Number beta, HML_Number *y, const HML_INT ldy, int unit_diag, int upper, int trans, int conj, int row_major);


// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_s_csr_n_lo_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_s_csr_u_lo_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t trmm_s_csr_n_hi_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t trmm_s_csr_u_hi_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_s_csr_n_lo_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_s_csr_u_lo_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t trmm_s_csr_n_hi_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t trmm_s_csr_u_hi_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_lo_row_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_lo_row_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_hi_row_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_hi_row_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_lo_col_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_lo_col_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_hi_col_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_hi_col_trans(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_lo_row_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_lo_row_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_hi_row_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_hi_row_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_lo_col_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_lo_col_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_n_hi_col_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_s_csr_u_hi_col_conj(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

// alpha*D*B + beta*C
hml_sparse_status_t diagmm_s_csr_n_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_s_csr_u_row(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*D*B + beta*C
hml_sparse_status_t diagmm_s_csr_n_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_s_csr_u_col(const float alpha, const spmat_csr_s_t *mat, const float *x, const HML_INT columns, const HML_INT ldx, const float beta, float *y, const HML_INT ldy);

// ---------------------------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------

// A*B
hml_sparse_status_t spmmd_s_csr_row(const spmat_csr_s_t *matA, const spmat_csr_s_t *matB, float *C, const HML_INT ldc);
// A*B
hml_sparse_status_t spmmd_s_csr_col(const spmat_csr_s_t *matA, const spmat_csr_s_t *matB, float *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_s_csr_row_trans(const spmat_csr_s_t *matA, const spmat_csr_s_t *matB, float *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_s_csr_col_trans(const spmat_csr_s_t *matA, const spmat_csr_s_t *matB, float *C, const HML_INT ldc);

// A^T*B
hml_sparse_status_t spmmd_s_csr_row_conj(const spmat_csr_s_t *matA, const spmat_csr_s_t *matB, float *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_s_csr_col_conj(const spmat_csr_s_t *matA, const spmat_csr_s_t *matB, float *C, const HML_INT ldc);

hml_sparse_status_t spmm_s_csr(const spmat_csr_s_t *A, const spmat_csr_s_t *B, spmat_csr_s_t **C);
hml_sparse_status_t spmm_s_csr_trans(const spmat_csr_s_t *A, const spmat_csr_s_t *B, spmat_csr_s_t **C);
hml_sparse_status_t spmm_s_csr_conj(const spmat_csr_s_t *A, const spmat_csr_s_t *B, spmat_csr_s_t **C);

// -----------------------------------------------------------------------------------------------------

// alpha*inv(L)*x
hml_sparse_status_t trsv_s_csr_n_lo(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(L)*x
hml_sparse_status_t trsv_s_csr_u_lo(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_s_csr_n_hi(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_s_csr_u_hi(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_s_csr_n_lo_trans(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_s_csr_u_lo_trans(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_s_csr_n_hi_trans(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_s_csr_u_hi_trans(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_s_csr_n_lo_conj(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_s_csr_u_lo_conj(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_s_csr_n_hi_conj(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_s_csr_u_hi_conj(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);

// alpha*inv(D)*x
hml_sparse_status_t diagsv_s_csr_n(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);
// alpha*x
hml_sparse_status_t diagsv_s_csr_u(const float alpha, const spmat_csr_s_t *A, const float *x, float *y);

// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_n_lo_row(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_u_lo_row(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_n_hi_row(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_u_hi_row(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_n_lo_col(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_u_lo_col(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_n_hi_col(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_u_hi_col(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_n_lo_row_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_u_lo_row_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_n_hi_row_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_u_hi_row_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_n_lo_col_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_u_lo_col_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_n_hi_col_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_u_hi_col_trans(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_n_lo_row_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_u_lo_row_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_n_hi_row_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_u_hi_row_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_n_lo_col_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_s_csr_u_lo_col_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_n_hi_col_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_s_csr_u_hi_col_conj(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);

// alpha*inv(D)*x
hml_sparse_status_t diagsm_s_csr_n_row(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_s_csr_u_row(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*inv(D)*x
hml_sparse_status_t diagsm_s_csr_n_col(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_s_csr_u_col(const float alpha, const spmat_csr_s_t *A, const float *x, const HML_INT columns, const HML_INT ldx, float *y, const HML_INT ldy);

hml_sparse_status_t set_value_s_csr(spmat_csr_s_t *A, const HML_INT row, const HML_INT col, const float value);
