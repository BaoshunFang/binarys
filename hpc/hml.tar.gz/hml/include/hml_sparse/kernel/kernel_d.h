#pragma once

#include "../spdef.h"
#include "../types.h"

hml_sparse_status_t axpy_d_(const HML_INT nz, const double a, const double *x, const HML_INT *indx, double *y);
hml_sparse_status_t gthr_d_(const HML_INT nz, const double *y, double *x, const HML_INT *indx);
hml_sparse_status_t gthrz_d_(const HML_INT nz, double *y, double *x, const HML_INT *indx);
hml_sparse_status_t rot_d_(const HML_INT nz, double *x, const HML_INT *indx, double *y, const double c, const double s);
hml_sparse_status_t sctr_d_(const HML_INT nz, const double *x, const HML_INT *indx, double *y);
double doti_d_(const HML_INT nz, const double *x, const HML_INT *indx, const double *y);
