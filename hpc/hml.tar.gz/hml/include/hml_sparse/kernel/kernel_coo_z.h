#pragma once

#include "../spmat.h"

hml_sparse_status_t add_z_coo(const spmat_coo_z_t *A, const HML_Complex16 alpha, const spmat_coo_z_t *B, spmat_coo_z_t **C);
hml_sparse_status_t add_z_coo_trans(const spmat_coo_z_t *A, const HML_Complex16 alpha, const spmat_coo_z_t *B, spmat_coo_z_t **C);
hml_sparse_status_t add_z_coo_conj(const spmat_coo_z_t *A, const HML_Complex16 alpha, const spmat_coo_z_t *B, spmat_coo_z_t **C);

// --------------------------------------------------------------------------------------------------------------------------------

// mv
// alpha*A*x + beta*y
hml_sparse_status_t gemv_z_coo(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*A^T*x + beta*y
hml_sparse_status_t gemv_z_coo_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*A^H*x + beta*y
hml_sparse_status_t gemv_z_coo_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_z_coo_n_lo(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_z_coo_u_lo(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_z_coo_n_hi(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_z_coo_u_hi(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+D+L')*x + beta*y
hml_sparse_status_t symv_z_coo_n_lo_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I+L')*x + beta*y
hml_sparse_status_t symv_z_coo_u_lo_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+D+U)*x + beta*y
hml_sparse_status_t symv_z_coo_n_hi_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U'+I+U)*x + beta*y
hml_sparse_status_t symv_z_coo_u_hi_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)*x + beta*y
hml_sparse_status_t trmv_z_coo_n_lo(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)*x + beta*y
hml_sparse_status_t trmv_z_coo_u_lo(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)*x + beta*y
hml_sparse_status_t trmv_z_coo_n_hi(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)*x + beta*y
hml_sparse_status_t trmv_z_coo_u_hi(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)^T*x + beta*y
hml_sparse_status_t trmv_z_coo_n_lo_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)^T*x + beta*y
hml_sparse_status_t trmv_z_coo_u_lo_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)^T*x + beta*y
hml_sparse_status_t trmv_z_coo_n_hi_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)^T*x + beta*y
hml_sparse_status_t trmv_z_coo_u_hi_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*(L+D)^H*x + beta*y
hml_sparse_status_t trmv_z_coo_n_lo_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(L+I)^H*x + beta*y
hml_sparse_status_t trmv_z_coo_u_lo_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+D)^H*x + beta*y
hml_sparse_status_t trmv_z_coo_n_hi_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*(U+I)^H*x + beta*y
hml_sparse_status_t trmv_z_coo_u_hi_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// alpha*D*x + beta*y
hml_sparse_status_t diagmv_z_coo_n(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);
// alpha*x + beta*y
hml_sparse_status_t diagmv_z_coo_u(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_Complex16 beta, HML_Complex16 *y);

// --------------------------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------------

// alpha*A*B + beta*C
hml_sparse_status_t gemm_z_coo_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_coo_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*A^T*B + beta*C
hml_sparse_status_t gemm_z_coo_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_coo_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*A^H*B + beta*C
hml_sparse_status_t gemm_z_coo_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
hml_sparse_status_t gemm_z_coo_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_coo_n_lo_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_coo_u_lo_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_coo_n_hi_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_coo_u_hi_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_coo_n_lo_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_coo_u_lo_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_coo_n_hi_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_coo_u_hi_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_coo_n_lo_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_coo_u_lo_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_coo_n_hi_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_coo_u_hi_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*（L+D+L')^T*B + beta*C
hml_sparse_status_t symm_z_coo_n_lo_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I+L')*B + beta*C
hml_sparse_status_t symm_z_coo_u_lo_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+D+U)*B + beta*C
hml_sparse_status_t symm_z_coo_n_hi_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U'+I+U)*B + beta*C
hml_sparse_status_t symm_z_coo_u_hi_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_z_coo_n_lo_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_z_coo_u_lo_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+D)*B + beta*C
hml_sparse_status_t trmm_z_coo_n_hi_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*op(U+I)*B + beta*C
hml_sparse_status_t trmm_z_coo_u_hi_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)*B + beta*C
hml_sparse_status_t trmm_z_coo_n_lo_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)*B + beta*C
hml_sparse_status_t trmm_z_coo_u_lo_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)*B + beta*C
hml_sparse_status_t trmm_z_coo_n_hi_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)*B + beta*C
hml_sparse_status_t trmm_z_coo_u_hi_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_lo_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_lo_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_hi_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_hi_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_lo_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_lo_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_hi_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_hi_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_lo_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_lo_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_hi_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_hi_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_lo_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(L+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_lo_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+D)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_n_hi_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*(U+I)^T*B + beta*C
hml_sparse_status_t trmm_z_coo_u_hi_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// alpha*D*B + beta*C
hml_sparse_status_t diagmm_z_coo_n_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_z_coo_u_row(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*D*B + beta*C
hml_sparse_status_t diagmm_z_coo_n_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);
// alpha*B + beta*C
hml_sparse_status_t diagmm_z_coo_u_col(const HML_Complex16 alpha, const spmat_coo_z_t *mat, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, const HML_Complex16 beta, HML_Complex16 *y, const HML_INT ldy);

// ---------------------------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------

// A*B
hml_sparse_status_t spmmd_z_coo_row(const spmat_coo_z_t *matA, const spmat_coo_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A*B
hml_sparse_status_t spmmd_z_coo_col(const spmat_coo_z_t *matA, const spmat_coo_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_coo_row_trans(const spmat_coo_z_t *matA, const spmat_coo_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_coo_col_trans(const spmat_coo_z_t *matA, const spmat_coo_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_coo_row_conj(const spmat_coo_z_t *matA, const spmat_coo_z_t *matB, HML_Complex16 *C, const HML_INT ldc);
// A^T*B
hml_sparse_status_t spmmd_z_coo_col_conj(const spmat_coo_z_t *matA, const spmat_coo_z_t *matB, HML_Complex16 *C, const HML_INT ldc);

hml_sparse_status_t spmm_z_coo(const spmat_coo_z_t *A, const spmat_coo_z_t *B, spmat_coo_z_t **C);
hml_sparse_status_t spmm_z_coo_trans(const spmat_coo_z_t *A, const spmat_coo_z_t *B, spmat_coo_z_t **C);
hml_sparse_status_t spmm_z_coo_conj(const spmat_coo_z_t *A, const spmat_coo_z_t *B, spmat_coo_z_t **C);

// -----------------------------------------------------------------------------------------------------

// alpha*inv(L)*x
hml_sparse_status_t trsv_z_coo_n_lo(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L)*x
hml_sparse_status_t trsv_z_coo_u_lo(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_z_coo_n_hi(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U)*x
hml_sparse_status_t trsv_z_coo_u_hi(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_coo_n_lo_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_coo_u_lo_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_coo_n_hi_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_coo_u_hi_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_coo_n_lo_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(L^T)*x
hml_sparse_status_t trsv_z_coo_u_lo_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_coo_n_hi_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*inv(U^T)*x
hml_sparse_status_t trsv_z_coo_u_hi_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);

// alpha*inv(D)*x
hml_sparse_status_t diagsv_z_coo_n(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);
// alpha*x
hml_sparse_status_t diagsv_z_coo_u(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, HML_Complex16 *y);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_n_lo_row(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_u_lo_row(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_n_hi_row(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_u_hi_row(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_n_lo_col(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_u_lo_col(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_n_hi_col(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_u_hi_col(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_n_lo_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_u_lo_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_n_hi_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_u_hi_row_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_n_lo_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_u_lo_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_n_hi_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_u_hi_col_trans(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_n_lo_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_u_lo_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_n_hi_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_u_hi_row_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_n_lo_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(L)*B
hml_sparse_status_t trsm_z_coo_u_lo_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_n_hi_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(U)*B
hml_sparse_status_t trsm_z_coo_u_hi_col_conj(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

// alpha*inv(D)*x
hml_sparse_status_t diagsm_z_coo_n_row(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_z_coo_u_row(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*inv(D)*x
hml_sparse_status_t diagsm_z_coo_n_col(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);
// alpha*x
hml_sparse_status_t diagsm_z_coo_u_col(const HML_Complex16 alpha, const spmat_coo_z_t *A, const HML_Complex16 *x, const HML_INT columns, const HML_INT ldx, HML_Complex16 *y, const HML_INT ldy);

hml_sparse_status_t set_value_z_coo(spmat_coo_z_t *A, const HML_INT row, const HML_INT col, const HML_Complex16 value);

hml_sparse_status_t
hermv_z_coo_u_hi(const HML_Complex16 alpha,
				 const spmat_coo_z_t *A,
				 const HML_Complex16 *x,
				 const HML_Complex16 beta,
				 HML_Complex16 *y);
hml_sparse_status_t
hermv_z_coo_u_lo(const HML_Complex16 alpha,
				 const spmat_coo_z_t *A,
				 const HML_Complex16 *x,
				 const HML_Complex16 beta,
				 HML_Complex16 *y);
hml_sparse_status_t
hermv_z_coo_n_hi(const HML_Complex16 alpha,
				 const spmat_coo_z_t *A,
				 const HML_Complex16 *x,
				 const HML_Complex16 beta,
				 HML_Complex16 *y);
hml_sparse_status_t
hermv_z_coo_n_lo(const HML_Complex16 alpha,
				 const spmat_coo_z_t *A,
				 const HML_Complex16 *x,
				 const HML_Complex16 beta,
				 HML_Complex16 *y);
hml_sparse_status_t
hermv_z_coo_u_hi_trans(const HML_Complex16 alpha,
					   const spmat_coo_z_t *A,
					   const HML_Complex16 *x,
					   const HML_Complex16 beta,
					   HML_Complex16 *y);
hml_sparse_status_t
hermv_z_coo_u_lo_trans(const HML_Complex16 alpha,
					   const spmat_coo_z_t *A,
					   const HML_Complex16 *x,
					   const HML_Complex16 beta,
					   HML_Complex16 *y);
hml_sparse_status_t
hermv_z_coo_n_hi_trans(const HML_Complex16 alpha,
					   const spmat_coo_z_t *A,
					   const HML_Complex16 *x,
					   const HML_Complex16 beta,
					   HML_Complex16 *y);
hml_sparse_status_t
hermv_z_coo_n_lo_trans(const HML_Complex16 alpha,
					   const spmat_coo_z_t *A,
					   const HML_Complex16 *x,
					   const HML_Complex16 beta,
					   HML_Complex16 *y);

hml_sparse_status_t hermm_z_coo_n_hi_col(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_n_lo_col(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_hi_col(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_lo_col(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_n_hi_col_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_n_lo_col_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_hi_col_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_lo_col_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_n_hi_row(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_n_lo_row(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_hi_row(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_lo_row(const HML_Complex16 alpha,
										 const spmat_coo_z_t *mat,
										 const HML_Complex16 *x,
										 const HML_INT columns,
										 const HML_INT ldx,
										 const HML_Complex16 beta,
										 HML_Complex16 *y,
										 const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_n_hi_row_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_n_lo_row_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_hi_row_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);

hml_sparse_status_t hermm_z_coo_u_lo_row_trans(const HML_Complex16 alpha,
											   const spmat_coo_z_t *mat,
											   const HML_Complex16 *x,
											   const HML_INT columns,
											   const HML_INT ldx,
											   const HML_Complex16 beta,
											   HML_Complex16 *y,
											   const HML_INT ldy);