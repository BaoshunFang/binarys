#pragma once

#include "../types.h"
#define BLOCK_DGEMM_RR_SQUARE BLOCK_Z_DGEMM_RR_SQUARE
#define BLOCK_DGEMM_RR_GENERAL BLOCK_Z_DGEMM_RR_GENERAL
#define BLOCK_DGEMM_CR_GENERAL BLOCK_Z_DGEMM_CR_GENERAL
#define BLOCK_DGEMM_RR_SQUARE_CONJ2 BLOCK_Z_DGEMM_RR_SQUARE_CONJ2
#define BLOCK_DGEMM_RR_GENERAL_CONJ2 BLOCK_Z_DGEMM_RR_GENERAL_CONJ2
#define BLOCK_DGEMM_CR_GENERAL_CONJ2 BLOCK_Z_DGEMM_CR_GENERAL_CONJ2
#define iszero(num) ((num).imag * (num).imag + (num).real * (num).real < 1e-20)
// gemm square
#ifdef CMLA
#define BLOCK_Z_DGEMM_RR_SQUARE(C, A, B, bs, ldc, lda, ldb)                   \
    {                                                                         \
        float64x2_t z_v_0 = vdupq_n_f64(0);                                   \
        float64x2_t z_v_1 = vdupq_n_f64(0);                                   \
        float64x2_t z_v_2 = vdupq_n_f64(0);                                   \
        float64x2_t z_v_3 = vdupq_n_f64(0);                                   \
        float64x2_t y_v_00, y_v_01, y_v_10, y_v_11;                           \
        float64x2_t y_v_02, y_v_03, y_v_12, y_v_13;                           \
        float64x2_t x_v_0, x_v_1;                                             \
        for (HML_INT __i = 0; __i < (bs); __i++)                              \
        {                                                                     \
            for (HML_INT j = 0; j < (bs); j += 4)                             \
            {                                                                 \
                z_v_0 = vld1q_f64((void *)((C) + __i * (ldc) + j));           \
                z_v_1 = vld1q_f64((void *)((C) + __i * (ldc) + j + 1));       \
                z_v_2 = vld1q_f64((void *)((C) + __i * (ldc) + j + 2));       \
                z_v_3 = vld1q_f64((void *)((C) + __i * (ldc) + j + 3));       \
                for (HML_INT k = 0; k < (bs); k += 2)                         \
                {                                                             \
                    const HML_Complex16 *X = (A) + __i * (lda) + k;           \
                    const HML_Complex16 *Y00 = (B) + k * (ldb) + j;           \
                    const HML_Complex16 *Y01 = (B) + k * (ldb) + j + 1;       \
                    const HML_Complex16 *Y10 = (B) + (k + 1) * (ldb) + j;     \
                    const HML_Complex16 *Y11 = (B) + (k + 1) * (ldb) + j + 1; \
                    const HML_Complex16 *Y02 = (B) + k * (ldb) + j + 2;       \
                    const HML_Complex16 *Y03 = (B) + k * (ldb) + j + 3;       \
                    const HML_Complex16 *Y12 = (B) + (k + 1) * (ldb) + j + 2; \
                    const HML_Complex16 *Y13 = (B) + (k + 1) * (ldb) + j + 3; \
                    x_v_0 = (vld1q_f64((void *)X));                           \
                    x_v_1 = (vld1q_f64((void *)(X + 1)));                     \
                    y_v_00 = vld1q_f64((void *)Y00);                          \
                    y_v_01 = vld1q_f64((void *)Y01);                          \
                    y_v_10 = vld1q_f64((void *)Y10);                          \
                    y_v_11 = vld1q_f64((void *)Y11);                          \
                    y_v_02 = vld1q_f64((void *)Y02);                          \
                    y_v_03 = vld1q_f64((void *)Y03);                          \
                    y_v_12 = vld1q_f64((void *)Y12);                          \
                    y_v_13 = vld1q_f64((void *)Y13);                          \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_0, y_v_00);                 \
                    z_v_1 = vcmlaq_f64(z_v_1, x_v_0, y_v_01);                 \
                    z_v_2 = vcmlaq_f64(z_v_2, x_v_0, y_v_02);                 \
                    z_v_3 = vcmlaq_f64(z_v_3, x_v_0, y_v_03);                 \
                    z_v_0 = vcmlaq_rot90_f64(z_v_0, x_v_0, y_v_00);           \
                    z_v_1 = vcmlaq_rot90_f64(z_v_1, x_v_0, y_v_01);           \
                    z_v_2 = vcmlaq_rot90_f64(z_v_2, x_v_0, y_v_02);           \
                    z_v_3 = vcmlaq_rot90_f64(z_v_3, x_v_0, y_v_03);           \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_1, y_v_10);                 \
                    z_v_1 = vcmlaq_f64(z_v_1, x_v_1, y_v_11);                 \
                    z_v_2 = vcmlaq_f64(z_v_2, x_v_1, y_v_12);                 \
                    z_v_3 = vcmlaq_f64(z_v_3, x_v_1, y_v_13);                 \
                    z_v_0 = vcmlaq_rot90_f64(z_v_0, x_v_1, y_v_10);           \
                    z_v_1 = vcmlaq_rot90_f64(z_v_1, x_v_1, y_v_11);           \
                    z_v_2 = vcmlaq_rot90_f64(z_v_2, x_v_1, y_v_12);           \
                    z_v_3 = vcmlaq_rot90_f64(z_v_3, x_v_1, y_v_13);           \
                }                                                             \
                vst1q_f64((void *)((C) + __i * (ldc) + j), z_v_0);            \
                vst1q_f64((void *)((C) + __i * (ldc) + j + 1), z_v_1);        \
                vst1q_f64((void *)((C) + __i * (ldc) + j + 2), z_v_2);        \
                vst1q_f64((void *)((C) + __i * (ldc) + j + 3), z_v_3);        \
            }                                                                 \
        }                                                                     \
    }
#else
#define BLOCK_Z_DGEMM_RR_SQUARE(C, A, B, bs, ldc, lda, ldb)                                                                                         \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT j = 0; j < bs; j++)                                                                                                            \
        {                                                                                                                                           \
            for (HML_INT m = 0; m < bs - 3; m += 4)                                                                                                 \
            {                                                                                                                                       \
                HML_Complex16 *tmp = C + __i * ldc + j;                                                                                             \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real - (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].real - (A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].real + (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].real - (A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].real + (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].real - (A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].real + (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif
// gemm rr
#ifdef CMLA
#define BLOCK_Z_DGEMM_RR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)     \
    {                                                               \
        float64x2_t z_v_0, z_v_1, z_v_2, z_v_3;                     \
        float64x2_t x_v_0;                                          \
        float64x2_t y_v_0, y_v_1, y_v_2, y_v_3;                     \
        for (HML_INT __i = 0; __i < (bs); __i++)                    \
        {                                                           \
            for (HML_INT k = 0; k < (bs); k++)                      \
            {                                                       \
                const HML_Complex16 *__A = (A) + __i * (lda) + k;   \
                x_v_0 = vld1q_f64((void *)__A);                     \
                HML_INT j = 0;                                      \
                if (iszero(__A[0]))                                 \
                    continue;                                       \
                for (; j < (N)-3; j += 4)                           \
                {                                                   \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;     \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j; \
                    z_v_0 = vld1q_f64((void *)(__C + 0));           \
                    z_v_1 = vld1q_f64((void *)(__C + 1));           \
                    z_v_2 = vld1q_f64((void *)(__C + 2));           \
                    z_v_3 = vld1q_f64((void *)(__C + 3));           \
                    y_v_0 = vld1q_f64((void *)(__B + 0));           \
                    y_v_1 = vld1q_f64((void *)(__B + 1));           \
                    y_v_2 = vld1q_f64((void *)(__B + 2));           \
                    y_v_3 = vld1q_f64((void *)(__B + 3));           \
                    z_v_0 = vcmlaq_f64(z_v_0, y_v_0, x_v_0);        \
                    z_v_1 = vcmlaq_f64(z_v_1, y_v_1, x_v_0);        \
                    z_v_2 = vcmlaq_f64(z_v_2, y_v_2, x_v_0);        \
                    z_v_3 = vcmlaq_f64(z_v_3, y_v_3, x_v_0);        \
                    z_v_0 = vcmlaq_rot90_f64(z_v_0, y_v_0, x_v_0);  \
                    z_v_1 = vcmlaq_rot90_f64(z_v_1, y_v_1, x_v_0);  \
                    z_v_2 = vcmlaq_rot90_f64(z_v_2, y_v_2, x_v_0);  \
                    z_v_3 = vcmlaq_rot90_f64(z_v_3, y_v_3, x_v_0);  \
                    vst1q_f64((void *)(__C + 0), z_v_0);            \
                    vst1q_f64((void *)(__C + 1), z_v_1);            \
                    vst1q_f64((void *)(__C + 2), z_v_2);            \
                    vst1q_f64((void *)(__C + 3), z_v_3);            \
                }                                                   \
                for (; j < (N); j++)                                \
                {                                                   \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;     \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j; \
                    z_v_0 = vld1q_f64((void *)__C);                 \
                    y_v_0 = vld1q_f64((void *)__B);                 \
                    z_v_0 = vcmlaq_f64(z_v_0, y_v_0, x_v_0);        \
                    z_v_0 = vcmlaq_rot90_f64(z_v_0, y_v_0, x_v_0);  \
                    vst1q_f64((void *)__C, z_v_0);                  \
                }                                                   \
            }                                                       \
        }                                                           \
    }
#else
#define BLOCK_Z_DGEMM_RR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)                                                                                     \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT j = 0; j < N; j++)                                                                                                             \
        {                                                                                                                                           \
            for (HML_INT m = 0; m < bs; m++)                                                                                                        \
            {                                                                                                                                       \
                HML_Complex16 *tmp = C + __i * ldc + j;                                                                                             \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real - (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif
// gemm cr
#ifdef CMLA
#define BLOCK_Z_DGEMM_CR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)     \
    {                                                               \
        float64x2_t z_v_0, z_v_1, z_v_2, z_v_3;                     \
        float64x2_t x_v_0;                                          \
        float64x2_t y_v_0, y_v_1, y_v_2, y_v_3;                     \
        for (HML_INT __i = 0; __i < (bs); __i++)                    \
        {                                                           \
            for (HML_INT k = 0; k < (bs); k++)                      \
            {                                                       \
                const HML_Complex16 *__A = (A) + k * (lda) + __i;   \
                x_v_0 = vld1q_f64((void *)__A);                     \
                HML_INT j = 0;                                      \
                if (iszero(__A[0]))                                 \
                    continue;                                       \
                for (; j < (N)-3; j += 4)                           \
                {                                                   \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;     \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j; \
                    z_v_0 = vld1q_f64((void *)(__C + 0));           \
                    z_v_1 = vld1q_f64((void *)(__C + 1));           \
                    z_v_2 = vld1q_f64((void *)(__C + 2));           \
                    z_v_3 = vld1q_f64((void *)(__C + 3));           \
                    y_v_0 = vld1q_f64((void *)(__B + 0));           \
                    y_v_1 = vld1q_f64((void *)(__B + 1));           \
                    y_v_2 = vld1q_f64((void *)(__B + 2));           \
                    y_v_3 = vld1q_f64((void *)(__B + 3));           \
                    z_v_0 = vcmlaq_f64(z_v_0, y_v_0, x_v_0);        \
                    z_v_1 = vcmlaq_f64(z_v_1, y_v_1, x_v_0);        \
                    z_v_2 = vcmlaq_f64(z_v_2, y_v_2, x_v_0);        \
                    z_v_3 = vcmlaq_f64(z_v_3, y_v_3, x_v_0);        \
                    z_v_0 = vcmlaq_rot90_f64(z_v_0, y_v_0, x_v_0);  \
                    z_v_1 = vcmlaq_rot90_f64(z_v_1, y_v_1, x_v_0);  \
                    z_v_2 = vcmlaq_rot90_f64(z_v_2, y_v_2, x_v_0);  \
                    z_v_3 = vcmlaq_rot90_f64(z_v_3, y_v_3, x_v_0);  \
                    vst1q_f64((void *)(__C + 0), z_v_0);            \
                    vst1q_f64((void *)(__C + 1), z_v_1);            \
                    vst1q_f64((void *)(__C + 2), z_v_2);            \
                    vst1q_f64((void *)(__C + 3), z_v_3);            \
                }                                                   \
                for (; j < (N); j++)                                \
                {                                                   \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;     \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j; \
                    z_v_0 = vld1q_f64((void *)__C);                 \
                    y_v_0 = vld1q_f64((void *)__B);                 \
                    z_v_0 = vcmlaq_f64(z_v_0, y_v_0, x_v_0);        \
                    z_v_0 = vcmlaq_rot90_f64(z_v_0, y_v_0, x_v_0);  \
                    vst1q_f64((void *)__C, z_v_0);                  \
                }                                                   \
            }                                                       \
        }                                                           \
    }
#else
#define BLOCK_Z_DGEMM_CR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)                                                                                     \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT j = 0; j < N; j++)                                                                                                             \
        {                                                                                                                                           \
            for (HML_INT m = 0; m < bs; m++)                                                                                                        \
            {                                                                                                                                       \
                HML_Complex16 *tmp = C + __i * ldc + j;                                                                                             \
                tmp->real += (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].real - (A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif

#ifdef CMLA
#define BLOCK_Z_DGEMM_RR_SQUARE_CONJ2(C, A, B, bs, ldc, lda, ldb)             \
    {                                                                         \
        float64x2_t z_v_0 = vdupq_n_f64(0);                                   \
        float64x2_t z_v_1 = vdupq_n_f64(0);                                   \
        float64x2_t z_v_2 = vdupq_n_f64(0);                                   \
        float64x2_t z_v_3 = vdupq_n_f64(0);                                   \
        float64x2_t y_v_00, y_v_01, y_v_10, y_v_11;                           \
        float64x2_t y_v_02, y_v_03, y_v_12, y_v_13;                           \
        float64x2_t x_v_0, x_v_1;                                             \
        for (HML_INT __i = 0; __i < (bs); __i++)                              \
        {                                                                     \
            for (HML_INT j = 0; j < (bs); j += 4)                             \
            {                                                                 \
                z_v_0 = vld1q_f64((void *)((C) + __i * (ldc) + j));           \
                z_v_1 = vld1q_f64((void *)((C) + __i * (ldc) + j + 1));       \
                z_v_2 = vld1q_f64((void *)((C) + __i * (ldc) + j + 2));       \
                z_v_3 = vld1q_f64((void *)((C) + __i * (ldc) + j + 3));       \
                for (HML_INT k = 0; k < (bs); k += 2)                         \
                {                                                             \
                    const HML_Complex16 *X = (A) + __i * (lda) + k;           \
                    const HML_Complex16 *Y00 = (B) + k * (ldb) + j;           \
                    const HML_Complex16 *Y01 = (B) + k * (ldb) + j + 1;       \
                    const HML_Complex16 *Y10 = (B) + (k + 1) * (ldb) + j;     \
                    const HML_Complex16 *Y11 = (B) + (k + 1) * (ldb) + j + 1; \
                    const HML_Complex16 *Y02 = (B) + k * (ldb) + j + 2;       \
                    const HML_Complex16 *Y03 = (B) + k * (ldb) + j + 3;       \
                    const HML_Complex16 *Y12 = (B) + (k + 1) * (ldb) + j + 2; \
                    const HML_Complex16 *Y13 = (B) + (k + 1) * (ldb) + j + 3; \
                    x_v_0 = (vld1q_f64((void *)X));                           \
                    x_v_1 = (vld1q_f64((void *)(X + 1)));                     \
                    y_v_00 = vld1q_f64((void *)Y00);                          \
                    y_v_01 = vld1q_f64((void *)Y01);                          \
                    y_v_10 = vld1q_f64((void *)Y10);                          \
                    y_v_11 = vld1q_f64((void *)Y11);                          \
                    y_v_02 = vld1q_f64((void *)Y02);                          \
                    y_v_03 = vld1q_f64((void *)Y03);                          \
                    y_v_12 = vld1q_f64((void *)Y12);                          \
                    y_v_13 = vld1q_f64((void *)Y13);                          \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_0, y_v_00);                 \
                    z_v_1 = vcmlaq_f64(z_v_1, x_v_0, y_v_01);                 \
                    z_v_2 = vcmlaq_f64(z_v_2, x_v_0, y_v_02);                 \
                    z_v_3 = vcmlaq_f64(z_v_3, x_v_0, y_v_03);                 \
                    z_v_0 = vcmlaq_rot270_f64(z_v_0, x_v_0, y_v_00);          \
                    z_v_1 = vcmlaq_rot270_f64(z_v_1, x_v_0, y_v_01);          \
                    z_v_2 = vcmlaq_rot270_f64(z_v_2, x_v_0, y_v_02);          \
                    z_v_3 = vcmlaq_rot270_f64(z_v_3, x_v_0, y_v_03);          \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_1, y_v_10);                 \
                    z_v_1 = vcmlaq_f64(z_v_1, x_v_1, y_v_11);                 \
                    z_v_2 = vcmlaq_f64(z_v_2, x_v_1, y_v_12);                 \
                    z_v_3 = vcmlaq_f64(z_v_3, x_v_1, y_v_13);                 \
                    z_v_0 = vcmlaq_rot270_f64(z_v_0, x_v_1, y_v_10);          \
                    z_v_1 = vcmlaq_rot270_f64(z_v_1, x_v_1, y_v_11);          \
                    z_v_2 = vcmlaq_rot270_f64(z_v_2, x_v_1, y_v_12);          \
                    z_v_3 = vcmlaq_rot270_f64(z_v_3, x_v_1, y_v_13);          \
                }                                                             \
                vst1q_f64((void *)((C) + __i * (ldc) + j), z_v_0);            \
                vst1q_f64((void *)((C) + __i * (ldc) + j + 1), z_v_1);        \
                vst1q_f64((void *)((C) + __i * (ldc) + j + 2), z_v_2);        \
                vst1q_f64((void *)((C) + __i * (ldc) + j + 3), z_v_3);        \
            }                                                                 \
        }                                                                     \
    }
#else
#define BLOCK_Z_DGEMM_RR_SQUARE_CONJ2(C, A, B, bs, ldc, lda, ldb)                                                                                   \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT j = 0; j < bs; j++)                                                                                                            \
        {                                                                                                                                           \
            for (HML_INT m = 0; m < bs - 3; m += 4)                                                                                                 \
            {                                                                                                                                       \
                HML_Complex16 *tmp = C + __i * ldc + j;                                                                                             \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real - (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].real - (A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].real + (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].real - (A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].real + (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].real - (A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].real + (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif
#ifdef CMLA
#define BLOCK_Z_DGEMM_RR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb) \
    {                                                                 \
        float64x2_t z_v_0, z_v_1, z_v_2, z_v_3;                       \
        float64x2_t x_v_0;                                            \
        float64x2_t y_v_0, y_v_1, y_v_2, y_v_3;                       \
        for (HML_INT __i = 0; __i < (bs); __i++)                      \
        {                                                             \
            for (HML_INT k = 0; k < (bs); k++)                        \
            {                                                         \
                const HML_Complex16 *__A = (A) + __i * (lda) + k;     \
                x_v_0 = vld1q_f64((void *)__A);                       \
                HML_INT j = 0;                                        \
                if (iszero(__A[0]))                                   \
                    continue;                                         \
                for (; j < (N)-3; j += 4)                             \
                {                                                     \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;       \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j;   \
                    z_v_0 = vld1q_f64((void *)(__C + 0));             \
                    z_v_1 = vld1q_f64((void *)(__C + 1));             \
                    z_v_2 = vld1q_f64((void *)(__C + 2));             \
                    z_v_3 = vld1q_f64((void *)(__C + 3));             \
                    y_v_0 = vld1q_f64((void *)(__B + 0));             \
                    y_v_1 = vld1q_f64((void *)(__B + 1));             \
                    y_v_2 = vld1q_f64((void *)(__B + 2));             \
                    y_v_3 = vld1q_f64((void *)(__B + 3));             \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_0, y_v_0);          \
                    z_v_1 = vcmlaq_f64(z_v_1, x_v_0, y_v_1);          \
                    z_v_2 = vcmlaq_f64(z_v_2, x_v_0, y_v_2);          \
                    z_v_3 = vcmlaq_f64(z_v_3, x_v_0, y_v_3);          \
                    z_v_0 = vcmlaq_rot270_f64(z_v_0, x_v_0, y_v_0);   \
                    z_v_1 = vcmlaq_rot270_f64(z_v_1, x_v_0, y_v_1);   \
                    z_v_2 = vcmlaq_rot270_f64(z_v_2, x_v_0, y_v_2);   \
                    z_v_3 = vcmlaq_rot270_f64(z_v_3, x_v_0, y_v_3);   \
                    vst1q_f64((void *)(__C + 0), z_v_0);              \
                    vst1q_f64((void *)(__C + 1), z_v_1);              \
                    vst1q_f64((void *)(__C + 2), z_v_2);              \
                    vst1q_f64((void *)(__C + 3), z_v_3);              \
                }                                                     \
                for (; j < (N); j++)                                  \
                {                                                     \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;       \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j;   \
                    z_v_0 = vld1q_f64((void *)__C);                   \
                    y_v_0 = vld1q_f64((void *)__B);                   \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_0, y_v_0);          \
                    z_v_0 = vcmlaq_rot270_f64(z_v_0, x_v_0, y_v_0);   \
                    vst1q_f64((void *)__C, z_v_0);                    \
                }                                                     \
            }                                                         \
        }                                                             \
    }
#else
#define BLOCK_Z_DGEMM_RR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb)                                                                               \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT j = 0; j < N; j++)                                                                                                             \
        {                                                                                                                                           \
            for (HML_INT m = 0; m < bs; m++)                                                                                                        \
            {                                                                                                                                       \
                HML_Complex16 *tmp = C + __i * ldc + j;                                                                                             \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real - (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif
#ifdef CMLA
#define BLOCK_Z_DGEMM_CR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb) \
    {                                                                 \
        float64x2_t z_v_0, z_v_1, z_v_2, z_v_3;                       \
        float64x2_t x_v_0;                                            \
        float64x2_t y_v_0, y_v_1, y_v_2, y_v_3;                       \
        for (HML_INT __i = 0; __i < (bs); __i++)                      \
        {                                                             \
            for (HML_INT k = 0; k < (bs); k++)                        \
            {                                                         \
                const HML_Complex16 *__A = (A) + k * (lda) + __i;     \
                x_v_0 = vld1q_f64((void *)__A);                       \
                HML_INT j = 0;                                        \
                if (iszero(__A[0]))                                   \
                    continue;                                         \
                for (; j < (N)-3; j += 4)                             \
                {                                                     \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;       \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j;   \
                    z_v_0 = vld1q_f64((void *)(__C + 0));             \
                    z_v_1 = vld1q_f64((void *)(__C + 1));             \
                    z_v_2 = vld1q_f64((void *)(__C + 2));             \
                    z_v_3 = vld1q_f64((void *)(__C + 3));             \
                    y_v_0 = vld1q_f64((void *)(__B + 0));             \
                    y_v_1 = vld1q_f64((void *)(__B + 1));             \
                    y_v_2 = vld1q_f64((void *)(__B + 2));             \
                    y_v_3 = vld1q_f64((void *)(__B + 3));             \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_0, y_v_0);          \
                    z_v_1 = vcmlaq_f64(z_v_1, x_v_0, y_v_1);          \
                    z_v_2 = vcmlaq_f64(z_v_2, x_v_0, y_v_2);          \
                    z_v_3 = vcmlaq_f64(z_v_3, x_v_0, y_v_3);          \
                    z_v_0 = vcmlaq_rot270_f64(z_v_0, x_v_0, y_v_0);   \
                    z_v_1 = vcmlaq_rot270_f64(z_v_1, x_v_0, y_v_1);   \
                    z_v_2 = vcmlaq_rot270_f64(z_v_2, x_v_0, y_v_2);   \
                    z_v_3 = vcmlaq_rot270_f64(z_v_3, x_v_0, y_v_3);   \
                    vst1q_f64((void *)(__C + 0), z_v_0);              \
                    vst1q_f64((void *)(__C + 1), z_v_1);              \
                    vst1q_f64((void *)(__C + 2), z_v_2);              \
                    vst1q_f64((void *)(__C + 3), z_v_3);              \
                }                                                     \
                for (; j < (N); j++)                                  \
                {                                                     \
                    HML_Complex16 *__C = (C) + __i * (ldc) + j;       \
                    const HML_Complex16 *__B = (B) + k * (ldb) + j;   \
                    z_v_0 = vld1q_f64((void *)__C);                   \
                    y_v_0 = vld1q_f64((void *)__B);                   \
                    z_v_0 = vcmlaq_f64(z_v_0, x_v_0, y_v_0);          \
                    z_v_0 = vcmlaq_rot270_f64(z_v_0, , x_v_0 y_v_0);  \
                    vst1q_f64((void *)__C, z_v_0);                    \
                }                                                     \
            }                                                         \
        }                                                             \
    }
#else
#define BLOCK_Z_DGEMM_CR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb)                                                                                \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                           \
    {                                                                                                                                                \
        for (HML_INT j = 0; j < N; j++)                                                                                                              \
        {                                                                                                                                            \
            for (HML_INT m = 0; m < bs; m++)                                                                                                         \
            {                                                                                                                                        \
                HML_Complex16 *tmp = C + __i * ldc + j;                                                                                              \
                tmp->real += (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].real + (A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].imag;  \
                tmp->imag += -(A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                        \
        }                                                                                                                                            \
    }
#endif