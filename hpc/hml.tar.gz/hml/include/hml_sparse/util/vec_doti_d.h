#pragma once

#include "../types.h"
#include "../compute.h"
#define vec_doti vec_doti_d
#define VEC_DOTADD_4 VEC_DOTADD_D4
#define VEC_DOTSUB_4 VEC_DOTSUB_D4

#define VEC_DOTADD_D4(a, b, sum)  \
    do                            \
    {                             \
        (sum) += (a)[0] * (b)[0]; \
        (sum) += (a)[1] * (b)[1]; \
        (sum) += (a)[2] * (b)[2]; \
        (sum) += (a)[3] * (b)[3]; \
    } while (0)

#define VEC_DOTSUB_D4(a, b, sum)  \
    do                            \
    {                             \
        (sum) -= (a)[0] * (b)[0]; \
        (sum) -= (a)[1] * (b)[1]; \
        (sum) -= (a)[2] * (b)[2]; \
        (sum) -= (a)[3] * (b)[3]; \
    } while (0)

static inline double vec_doti_d(const HML_INT ns, const double *x, const HML_INT *indx, const double *y)
{
    HML_INT ns4 = ((ns >> 2) << 2);
    HML_INT i = 0;
    double tmp[4] = {
        0.,
        0.,
        0.,
        0.,
    };
    __asm__ volatile(
        "prfm pldl3strm, [%[x]]\n\t"
        "prfm pldl3strm, [%[indx]]\n\t"
        :
        : [x] "r"(x), [indx] "r"(indx));
    for (i = 0; i < ns4; i += 4)
    {
        __asm__ volatile(
            "prfm pldl3strm, [%[x]]\n\t"
            "prfm pldl3strm, [%[indx]]\n\t"
            :
            : [x] "r"(x + i + 4), [indx] "r"(indx + i + 4));
        real_madde(tmp[0], x[i], y[indx[i]]);
        real_madde(tmp[1], x[i + 1], y[indx[i + 1]]);
        real_madde(tmp[2], x[i + 2], y[indx[i + 2]]);
        real_madde(tmp[3], x[i + 3], y[indx[i + 3]]);
    }
    for (; i < ns; ++i)
    {
        real_madde(tmp[0], x[i], y[indx[i]]);
    }
    return (tmp[0] + tmp[1]) + (tmp[2] + tmp[3]);
}