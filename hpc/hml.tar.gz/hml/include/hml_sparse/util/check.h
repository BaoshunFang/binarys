#pragma once

/**
 * @brief header for parameter check utils
 */

#include <stdlib.h>
#include "../spdef.h"
#include "../types.h"
#include "../spmat.h"
#include <stdbool.h>

#define check_null_return(pointer, error) \
    if (((void *)pointer) == NULL)        \
    {                                     \
        return error;                     \
    }

#define check_return(expr, error) \
    if (expr)                     \
    {                             \
        return error;             \
    }

// [min max)
#define check_between_return(num, min, max, error) \
    if ((num) >= (max) || (num) < (min))           \
    {                                              \
        return error;                              \
    }

#define check_error_return(func)                  \
    {                                             \
        hml_sparse_status_t _status = func;       \
        if (_status != HML_SPARSE_STATUS_SUCCESS) \
            return _status;                       \
    }

#define THRESH 50.0f

bool check_equal_row_col(const hml_sparse_matrix_t A);
bool check_equal_colA_rowB(const hml_sparse_matrix_t A, const hml_sparse_matrix_t B, const hml_sparse_operation_t transA);

// success 0 error -1
int check_s(const float *answer_data, size_t answer_size, const float *result_data, size_t result_size);
int check_d(const double *answer_data, size_t answer_size, const double *result_data, size_t result_size);
int check_c(const HML_Complex8 *answer_data, size_t answer_size, const HML_Complex8 *result_data, size_t result_size);
int check_z(const HML_Complex16 *answer_data, size_t answer_size, const HML_Complex16 *result_data, size_t result_size);

int check_s_l2(const float *answer_data, size_t answer_size, const float *result_data, size_t result_size, const float *x, const float *y, const float alpha, const float beta, int argc, const char *argv[]);
int check_s_l3(const float *answer_data, const HML_INT ldans, size_t answer_size, const float *result_data, const HML_INT ldres, size_t result_size, const HML_INT *res_col_indx, const float *x, const HML_INT ldx, const float *y, const HML_INT ldy, const float alpha, const float beta, int argc, const char *argv[]);
int check_d_l2(const double *answer_data, size_t answer_size, const double *result_data, size_t result_size, const double *x, const double *y, const double alpha, const double beta, int argc, const char *argv[]);
int check_d_l3(const double *answer_data, const HML_INT ldans, size_t answer_size, const double *result_data, const HML_INT ldres, size_t result_size, const HML_INT *res_col_indx, const double *x, const HML_INT ldx, const double *y, const HML_INT ldy, const double alpha, const double beta, int argc, const char *argv[]);
int check_c_l2(const HML_Complex8 *answer_data, size_t answer_size, const HML_Complex8 *result_data, size_t result_size, const HML_Complex8 *x, const HML_Complex8 *y, const HML_Complex8 alpha, const HML_Complex8 beta, int argc, const char *argv[]);
int check_c_l3(const HML_Complex8 *answer_data, const HML_INT ldans, size_t answer_size, const HML_Complex8 *result_data, const HML_INT ldres, size_t result_size, const HML_INT *res_col_indx, const HML_Complex8 *x, const HML_INT ldx, const HML_Complex8 *y, const HML_INT ldy, const HML_Complex8 alpha, const HML_Complex8 beta, int argc, const char *argv[]);
int check_z_l2(const HML_Complex16 *answer_data, size_t answer_size, const HML_Complex16 *result_data, size_t result_size, const HML_Complex16 *x, const HML_Complex16 *y, const HML_Complex16 alpha, const HML_Complex16 beta, int argc, const char *argv[]);
int check_z_l3(const HML_Complex16 *answer_data, const HML_INT ldans, size_t answer_size, const HML_Complex16 *result_data, const HML_INT ldres, size_t result_size, const HML_INT *res_col_indx, const HML_Complex16 *x, const HML_INT ldx, const HML_Complex16 *y, const HML_INT ldy, const HML_Complex16 alpha, const HML_Complex16 beta, int argc, const char *argv[]);
