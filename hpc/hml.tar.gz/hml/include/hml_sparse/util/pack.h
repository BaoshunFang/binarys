#pragma once

#include "../types.h"
#include "thread.h"

void pack_matrix_col2row_s(const HML_INT rowX, const HML_INT colX, const float *X, const HML_INT ldX, float *Y, HML_INT ldY);
void pack_matrix_col2row_d(const HML_INT rowX, const HML_INT colX, const double *X, const HML_INT ldX, double *Y, HML_INT ldY);
void pack_matrix_col2row_c(const HML_INT rowX, const HML_INT colX, const HML_Complex8 *X, const HML_INT ldX, HML_Complex8 *Y, HML_INT ldY);
void pack_matrix_col2row_z(const HML_INT rowX, const HML_INT colX, const HML_Complex16 *X, const HML_INT ldX, HML_Complex16 *Y, HML_INT ldY);

void pack_matrix_row2col_s(const HML_INT rowX, const HML_INT colX, const float *X, const HML_INT ldX, float *Y, HML_INT ldY);
void pack_matrix_row2col_d(const HML_INT rowX, const HML_INT colX, const double *X, const HML_INT ldX, double *Y, HML_INT ldY);
void pack_matrix_row2col_c(const HML_INT rowX, const HML_INT colX, const HML_Complex8 *X, const HML_INT ldX, HML_Complex8 *Y, HML_INT ldY);
void pack_matrix_row2col_z(const HML_INT rowX, const HML_INT colX, const HML_Complex16 *X, const HML_INT ldX, HML_Complex16 *Y, HML_INT ldY);

#ifdef S
#define pack_matrix_col2row pack_matrix_col2row_s
#define pack_matrix_row2col pack_matrix_row2col_s
#endif
#ifdef D
#define pack_matrix_col2row pack_matrix_col2row_d
#define pack_matrix_row2col pack_matrix_row2col_d
#endif
#ifdef C
#define pack_matrix_col2row pack_matrix_col2row_c
#define pack_matrix_row2col pack_matrix_row2col_c
#endif
#ifdef Z
#define pack_matrix_col2row pack_matrix_col2row_z
#define pack_matrix_row2col pack_matrix_row2col_z
#endif
