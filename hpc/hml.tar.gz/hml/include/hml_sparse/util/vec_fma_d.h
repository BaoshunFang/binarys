#pragma once
#include "../types.h"
#include "../compute.h"

#define vec_fma2 vec_fma2_d
#define vec_fmai vec_fmai_d
#define VEC_FMA2 VEC_FMA2_D
#define VEC_FMS2 VEC_FMS2_D
#define VEC_MUL2 VEC_MUL2_D
#define VEC_MUL2_4 VEC_MUL2_D4
#define vec_fma2_tr vec_fma2_tr_d

#define VEC_MUL2_D(y, x, __val, len)         \
    do                                       \
    {                                        \
        {                                    \
            int32_t __i = 0;                 \
            for (; __i < len; __i += 1)      \
            {                                \
                (y)[__i] = __val * (x)[__i]; \
            }                                \
        }                                    \
    } while (0)

#define VEC_MUL2_D4(y, x, __val) VEC_MUL2_D(y, x, __val, 4)

#define VEC_FMS2_D(y, x, __val, len)          \
    do                                        \
    {                                         \
        {                                     \
            int32_t __i = 0;                  \
            for (; __i < len; __i += 1)       \
            {                                 \
                (y)[__i] -= __val * (x)[__i]; \
            }                                 \
        }                                     \
    } while (0)

// y[] += x[] * val
#define VEC_FMA2_D(y, x, __val, len)          \
    do                                        \
    {                                         \
        {                                     \
            int32_t __i = 0;                  \
            for (; __i < len; __i += 1)       \
            {                                 \
                (y)[__i] += __val * (x)[__i]; \
            }                                 \
        }                                     \
    } while (0)

static inline void vec_fmai_d(double *y, const HML_INT *indx, const double *x, const HML_INT ns, const double val)
{
    HML_INT ns4 = ((ns >> 2) << 2);
    HML_INT i = 0;

    __asm__ volatile(
        "prfm pldl3strm, [%[x]]\n\t"
        "prfm pldl3strm, [%[indx]]\n\t"
        :
        : [x] "r"(x), [indx] "r"(indx));
    for (i = 0; i < ns4; i += 4)
    {
        __asm__ volatile(
            "prfm pldl3strm, [%[x]]\n\t"
            "prfm pldl3strm, [%[indx]]\n\t"
            :
            : [x] "r"(x + i + 4), [indx] "r"(indx + i + 4));

        real_madde(y[indx[i]], x[i], val);
        real_madde(y[indx[i + 1]], x[i + 1], val);
        real_madde(y[indx[i + 2]], x[i + 2], val);
        real_madde(y[indx[i + 3]], x[i + 3], val);
    }
    for (; i < ns; ++i)
    {
        real_madde(y[indx[i]], x[i], val);
    }
}
static inline void vec_fma2_d(double *y, const double *x, double val, HML_INT len)
{
    HML_INT i = 0;
    for (; i < len; i += 1)
    {
        y[i] += val * x[i];
    }
}