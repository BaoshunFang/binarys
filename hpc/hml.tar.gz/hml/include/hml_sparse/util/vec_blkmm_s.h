#pragma once

#include "../types.h"
#define BLOCK_DGEMM_RR_SQUARE BLOCK_S_DGEMM_RR_SQUARE
#define BLOCK_DGEMM_RR_GENERAL BLOCK_S_DGEMM_RR_GENERAL
#define BLOCK_DGEMM_CR_GENERAL BLOCK_S_DGEMM_CR_GENERAL
// #define iszero(num) (((num) > 0 && (num) < 1e-19) || (((num) < 0 && (num) > -1e-19)))
#define iszero(num) (((num) * (num) < 1e-20))
// gemm square
#define BLOCK_S_DGEMM_RR_SQUARE(C, A, B, bs, ldc, lda, ldb)                  \
    for (HML_INT __i = 0; __i < bs; __i++)                                   \
    {                                                                        \
        for (HML_INT j = 0; j < bs; j++)                                     \
        {                                                                    \
            for (HML_INT m = 0; m < bs; m++)                                 \
            {                                                                \
                (C)[__i * ldc + j] += (A)[__i * lda + m] * (B)[m * ldb + j]; \
            }                                                                \
        }                                                                    \
    }

// gemm rr
#define BLOCK_S_DGEMM_RR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)              \
    for (HML_INT __i = 0; __i < bs; __i++)                                   \
    {                                                                        \
        for (HML_INT j = 0; j < bs; j++)                                     \
        {                                                                    \
            for (HML_INT m = 0; m < bs; m++)                                 \
            {                                                                \
                (C)[__i * ldc + j] += (A)[__i * lda + m] * (B)[m * ldb + j]; \
            }                                                                \
        }                                                                    \
    }

// gemm cr
#define BLOCK_S_DGEMM_CR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)              \
    for (HML_INT __i = 0; __i < bs; __i++)                                   \
    {                                                                        \
        for (HML_INT j = 0; j < bs; j++)                                     \
        {                                                                    \
            for (HML_INT m = 0; m < bs; m++)                                 \
            {                                                                \
                (C)[__i * ldc + j] += (A)[m * lda + __i] * (B)[m * ldb + j]; \
            }                                                                \
        }                                                                    \
    }
