#pragma once

#include "../types.h"
#include "../compute.h"

#define vec_fma2 vec_fma2_s
#define vec_fmai vec_fmai_s
#define VEC_FMA2 VEC_FMA2_S
#define VEC_FMS2 VEC_FMS2_S
#define VEC_MUL2 VEC_MUL2_S
#define VEC_MUL2_4 VEC_MUL2_S4
#define vec_fma2_tr vec_fma2_tr_s

#define VEC_MUL2_S4(y, x, __val) VEC_MUL2_S(y, x, __val, 4)

#define VEC_MUL2_S(y, x, __val, len)         \
    do                                       \
    {                                        \
        {                                    \
            int32_t __i = 0;                 \
            for (; __i < len; __i += 1)      \
            {                                \
                (y)[__i] = __val * (x)[__i]; \
            }                                \
        }                                    \
    } while (0)

#define VEC_FMS2_S(y, x, __val, len)          \
    do                                        \
    {                                         \
        {                                     \
            int32_t __i = 0;                  \
            for (; __i < len; __i += 1)       \
            {                                 \
                (y)[__i] -= __val * (x)[__i]; \
            }                                 \
        }                                     \
    } while (0)

#define VEC_FMA2_S(y, x, __val, len)          \
    do                                        \
    {                                         \
        {                                     \
            int32_t __i = 0;                  \
            for (; __i < len; __i += 1)       \
            {                                 \
                (y)[__i] += __val * (x)[__i]; \
            }                                 \
        }                                     \
    } while (0)

static inline void vec_fmai_s(float *y, const HML_INT *indx, const float *x, const HML_INT ns, const float val)
{
    HML_INT ns4 = ((ns >> 2) << 2);
    HML_INT i = 0;

    __asm__ volatile(
        "prfm pldl3strm, [%[x]]\n\t"
        "prfm pldl3strm, [%[indx]]\n\t"
        :
        : [x] "r"(x), [indx] "r"(indx));
    for (i = 0; i < ns4; i += 4)
    {
        __asm__ volatile(
            "prfm pldl3strm, [%[x]]\n\t"
            "prfm pldl3strm, [%[indx]]\n\t"
            :
            : [x] "r"(x + i + 4), [indx] "r"(indx + i + 4));

        real_madde(y[indx[i]], x[i], val);
        real_madde(y[indx[i + 1]], x[i + 1], val);
        real_madde(y[indx[i + 2]], x[i + 2], val);
        real_madde(y[indx[i + 3]], x[i + 3], val);
    }
    for (; i < ns; ++i)
    {
        real_madde(y[indx[i]], x[i], val);
    }
}
static inline void vec_fma2_s(float *y, const float *x, float val, HML_INT len)
{
    HML_INT i = 0;
    for (; i < len; i += 1)
    {
        y[i] += val * x[i];
    }
}