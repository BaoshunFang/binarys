#pragma once

#include "../types.h"

HML_INT hml_binary_search(const HML_INT *start, const HML_INT *end, const HML_INT target);
const HML_INT *hml_lower_bound(const HML_INT *start, const HML_INT *end, const HML_INT target);
const HML_INT *hml_upper_bound(const HML_INT *start, const HML_INT *end, const HML_INT target);
