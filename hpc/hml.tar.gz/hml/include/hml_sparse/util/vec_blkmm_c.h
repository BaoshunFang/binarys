#pragma once

#include "../types.h"
#define BLOCK_DGEMM_RR_SQUARE BLOCK_C_DGEMM_RR_SQUARE
#define BLOCK_DGEMM_RR_GENERAL BLOCK_C_DGEMM_RR_GENERAL
#define BLOCK_DGEMM_CR_GENERAL BLOCK_C_DGEMM_CR_GENERAL
#define BLOCK_DGEMM_RR_SQUARE_CONJ2 BLOCK_C_DGEMM_RR_SQUARE_CONJ2
#define BLOCK_DGEMM_RR_GENERAL_CONJ2 BLOCK_C_DGEMM_RR_GENERAL_CONJ2
#define BLOCK_DGEMM_CR_GENERAL_CONJ2 BLOCK_C_DGEMM_CR_GENERAL_CONJ2
#define iszero(num) ((num).imag * (num).imag + (num).real * (num).real < 1e-20)
// gemm square
#ifdef CMLA
#define BLOCK_C_DGEMM_RR_SQUARE(C, A, B, bs, ldc, lda, ldb)                          \
    {                                                                                \
        float32x4_t z_v_00 = vdupq_n_f32(0);                                         \
        float32x4_t z_v_01 = vdupq_n_f32(0);                                         \
        float32x4_t z_v_10 = vdupq_n_f32(0);                                         \
        float32x4_t z_v_11 = vdupq_n_f32(0);                                         \
        float32x4_t y_v_00, y_v_01;                                                  \
        float32x4_t y_v_10, y_v_11;                                                  \
        float32x4_t x_v_00, x_v_01, x_v_10, x_v_11;                                  \
        for (HML_INT __i = 0; __i < (bs); __i += 2)                                  \
        {                                                                            \
            for (HML_INT j = 0; j < (bs); j += 4)                                    \
            {                                                                        \
                z_v_00 = vld1q_f32((void *)((C) + __i * (ldc) + j));                 \
                z_v_01 = vld1q_f32((void *)((C) + __i * (ldc) + j + 2));             \
                z_v_10 = vld1q_f32((void *)((C) + (__i + 1) * (ldc) + j));           \
                z_v_11 = vld1q_f32((void *)((C) + (__i + 1) * (ldc) + j + 2));       \
                for (HML_INT k = 0; k < (bs); k += 2)                                \
                {                                                                    \
                    const HML_Complex8 *X = (A) + __i * (lda) + k;                   \
                    const HML_Complex8 *X1 = (A) + (__i + 1) * (lda) + k;            \
                    const HML_Complex8 *Y00 = (B) + k * (ldb) + j;                   \
                    const HML_Complex8 *Y10 = (B) + (k + 1) * (ldb) + j;             \
                    const HML_Complex8 *Y01 = (B) + k * (ldb) + j + 2;               \
                    const HML_Complex8 *Y11 = (B) + (k + 1) * (ldb) + j + 2;         \
                    x_v_00 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)X));        \
                    x_v_01 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)(X + 1)));  \
                    x_v_10 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)(X1)));     \
                    x_v_11 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)(X1 + 1))); \
                    y_v_00 = vld1q_f32((void *)Y00);                                 \
                    y_v_01 = vld1q_f32((void *)Y01);                                 \
                    y_v_10 = vld1q_f32((void *)Y10);                                 \
                    y_v_11 = vld1q_f32((void *)Y11);                                 \
                    z_v_00 = vcmlaq_f32(z_v_00, x_v_00, y_v_00);                     \
                    z_v_01 = vcmlaq_f32(z_v_01, x_v_00, y_v_01);                     \
                    z_v_10 = vcmlaq_f32(z_v_10, x_v_10, y_v_00);                     \
                    z_v_11 = vcmlaq_f32(z_v_11, x_v_10, y_v_01);                     \
                    z_v_00 = vcmlaq_rot90_f32(z_v_00, x_v_00, y_v_00);               \
                    z_v_01 = vcmlaq_rot90_f32(z_v_01, x_v_00, y_v_01);               \
                    z_v_10 = vcmlaq_rot90_f32(z_v_10, x_v_10, y_v_00);               \
                    z_v_11 = vcmlaq_rot90_f32(z_v_11, x_v_10, y_v_01);               \
                    z_v_00 = vcmlaq_f32(z_v_00, x_v_01, y_v_10);                     \
                    z_v_01 = vcmlaq_f32(z_v_01, x_v_01, y_v_11);                     \
                    z_v_10 = vcmlaq_f32(z_v_10, x_v_11, y_v_10);                     \
                    z_v_11 = vcmlaq_f32(z_v_11, x_v_11, y_v_11);                     \
                    z_v_00 = vcmlaq_rot90_f32(z_v_00, x_v_01, y_v_10);               \
                    z_v_01 = vcmlaq_rot90_f32(z_v_01, x_v_01, y_v_11);               \
                    z_v_10 = vcmlaq_rot90_f32(z_v_10, x_v_11, y_v_10);               \
                    z_v_11 = vcmlaq_rot90_f32(z_v_11, x_v_11, y_v_11);               \
                }                                                                    \
                vst1q_f32((void *)((C) + __i * (ldc) + j), z_v_00);                  \
                vst1q_f32((void *)((C) + __i * (ldc) + j + 2), z_v_01);              \
                vst1q_f32((void *)((C) + (__i + 1) * (ldc) + j), z_v_10);            \
                vst1q_f32((void *)((C) + (__i + 1) * (ldc) + j + 2), z_v_11);        \
            }                                                                        \
        }                                                                            \
    }
#else
#define BLOCK_C_DGEMM_RR_SQUARE(C, A, B, bs, ldc, lda, ldb)                                                                                         \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT j = 0; j < bs; j++)                                                                                                            \
        {                                                                                                                                           \
            for (HML_INT m = 0; m < bs - 3; m += 4)                                                                                                 \
            {                                                                                                                                       \
                HML_Complex8 *tmp = C + __i * ldc + j;                                                                                              \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real - (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].real - (A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].real + (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].real - (A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].real + (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].real - (A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].real + (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif
// gemm rr
#ifdef CMLA
#define BLOCK_C_DGEMM_RR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)                                                                                         \
    {                                                                                                                                                   \
        float32x4_t z_v_0, z_v_1, z_v_2, z_v_3;                                                                                                         \
        float32x4_t x_v_0;                                                                                                                              \
        float32x4_t y_v_0, y_v_1, y_v_2, y_v_3;                                                                                                         \
        for (HML_INT __i = 0; __i < (bs); __i++)                                                                                                        \
        {                                                                                                                                               \
            for (HML_INT k = 0; k < (bs); k++)                                                                                                          \
            {                                                                                                                                           \
                const HML_Complex8 *X = (A) + __i * (lda) + k;                                                                                          \
                x_v_0 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)X));                                                                                \
                if (iszero(X[0]))                                                                                                                       \
                    continue;                                                                                                                           \
                HML_INT j = 0;                                                                                                                          \
                for (; j < (N)-7; j += 8)                                                                                                               \
                {                                                                                                                                       \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                          \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                      \
                    z_v_0 = vld1q_f32((void *)(__C + 0));                                                                                               \
                    z_v_1 = vld1q_f32((void *)(__C + 2));                                                                                               \
                    z_v_2 = vld1q_f32((void *)(__C + 4));                                                                                               \
                    z_v_3 = vld1q_f32((void *)(__C + 6));                                                                                               \
                    y_v_0 = vld1q_f32((void *)(__B + 0));                                                                                               \
                    y_v_1 = vld1q_f32((void *)(__B + 2));                                                                                               \
                    y_v_2 = vld1q_f32((void *)(__B + 4));                                                                                               \
                    y_v_3 = vld1q_f32((void *)(__B + 6));                                                                                               \
                    z_v_0 = vcmlaq_f32(z_v_0, y_v_0, x_v_0);                                                                                            \
                    z_v_1 = vcmlaq_f32(z_v_1, y_v_1, x_v_0);                                                                                            \
                    z_v_2 = vcmlaq_f32(z_v_2, y_v_2, x_v_0);                                                                                            \
                    z_v_3 = vcmlaq_f32(z_v_3, y_v_3, x_v_0);                                                                                            \
                    z_v_0 = vcmlaq_rot90_f32(z_v_0, y_v_0, x_v_0);                                                                                      \
                    z_v_1 = vcmlaq_rot90_f32(z_v_1, y_v_1, x_v_0);                                                                                      \
                    z_v_2 = vcmlaq_rot90_f32(z_v_2, y_v_2, x_v_0);                                                                                      \
                    z_v_3 = vcmlaq_rot90_f32(z_v_3, y_v_3, x_v_0);                                                                                      \
                    vst1q_f32((void *)(__C + 0), z_v_0);                                                                                                \
                    vst1q_f32((void *)(__C + 2), z_v_1);                                                                                                \
                    vst1q_f32((void *)(__C + 4), z_v_2);                                                                                                \
                    vst1q_f32((void *)(__C + 6), z_v_3);                                                                                                \
                }                                                                                                                                       \
                for (; j < (N)-1; j += 2)                                                                                                               \
                {                                                                                                                                       \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                          \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                      \
                    z_v_0 = vld1q_f32((void *)__C);                                                                                                     \
                    y_v_0 = vld1q_f32((void *)__B);                                                                                                     \
                    z_v_0 = vcmlaq_f32(z_v_0, y_v_0, x_v_0);                                                                                            \
                    z_v_0 = vcmlaq_rot90_f32(z_v_0, y_v_0, x_v_0);                                                                                      \
                    vst1q_f32((void *)__C, z_v_0);                                                                                                      \
                }                                                                                                                                       \
                for (; j < (N); j++)                                                                                                                    \
                {                                                                                                                                       \
                    HML_Complex8 *tmp = C + __i * ldc + j;                                                                                              \
                    tmp->real += (A)[__i * lda + k + 0].real * (B)[(k + 0) * ldb + j].real - (A)[__i * lda + k + 0].imag * (B)[(k + 0) * ldb + j].imag; \
                    tmp->imag += (A)[__i * lda + k + 0].imag * (B)[(k + 0) * ldb + j].real + (A)[__i * lda + k + 0].real * (B)[(k + 0) * ldb + j].imag; \
                }                                                                                                                                       \
            }                                                                                                                                           \
        }                                                                                                                                               \
    }
#else
#define BLOCK_C_DGEMM_RR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)                                                                                     \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT j = 0; j < N; j++)                                                                                                             \
        {                                                                                                                                           \
            for (HML_INT m = 0; m < bs; m++)                                                                                                        \
            {                                                                                                                                       \
                HML_Complex8 *tmp = C + __i * ldc + j;                                                                                              \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real - (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif
// gemm cr
#ifdef CMLA
#define BLOCK_C_DGEMM_CR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)                                                                                         \
    {                                                                                                                                                   \
        float32x4_t z_v_0, z_v_1, z_v_2, z_v_3;                                                                                                         \
        float32x4_t x_v_0;                                                                                                                              \
        float32x4_t y_v_0, y_v_1, y_v_2, y_v_3;                                                                                                         \
        for (HML_INT __i = 0; __i < (bs); __i++)                                                                                                        \
        {                                                                                                                                               \
            for (HML_INT k = 0; k < (bs); k++)                                                                                                          \
            {                                                                                                                                           \
                const HML_Complex8 *X = (A) + k * (lda) + __i;                                                                                          \
                x_v_0 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)X));                                                                                \
                HML_INT j = 0;                                                                                                                          \
                if (iszero(X[0]))                                                                                                                       \
                    continue;                                                                                                                           \
                for (; j < (N)-7; j += 8)                                                                                                               \
                {                                                                                                                                       \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                          \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                      \
                    z_v_0 = vld1q_f32((void *)(__C + 0));                                                                                               \
                    z_v_1 = vld1q_f32((void *)(__C + 2));                                                                                               \
                    z_v_2 = vld1q_f32((void *)(__C + 4));                                                                                               \
                    z_v_3 = vld1q_f32((void *)(__C + 6));                                                                                               \
                    y_v_0 = vld1q_f32((void *)(__B + 0));                                                                                               \
                    y_v_1 = vld1q_f32((void *)(__B + 2));                                                                                               \
                    y_v_2 = vld1q_f32((void *)(__B + 4));                                                                                               \
                    y_v_3 = vld1q_f32((void *)(__B + 6));                                                                                               \
                    z_v_0 = vcmlaq_f32(z_v_0, y_v_0, x_v_0);                                                                                            \
                    z_v_1 = vcmlaq_f32(z_v_1, y_v_1, x_v_0);                                                                                            \
                    z_v_2 = vcmlaq_f32(z_v_2, y_v_2, x_v_0);                                                                                            \
                    z_v_3 = vcmlaq_f32(z_v_3, y_v_3, x_v_0);                                                                                            \
                    z_v_0 = vcmlaq_rot90_f32(z_v_0, y_v_0, x_v_0);                                                                                      \
                    z_v_1 = vcmlaq_rot90_f32(z_v_1, y_v_1, x_v_0);                                                                                      \
                    z_v_2 = vcmlaq_rot90_f32(z_v_2, y_v_2, x_v_0);                                                                                      \
                    z_v_3 = vcmlaq_rot90_f32(z_v_3, y_v_3, x_v_0);                                                                                      \
                    vst1q_f32((void *)(__C + 0), z_v_0);                                                                                                \
                    vst1q_f32((void *)(__C + 2), z_v_1);                                                                                                \
                    vst1q_f32((void *)(__C + 4), z_v_2);                                                                                                \
                    vst1q_f32((void *)(__C + 6), z_v_3);                                                                                                \
                }                                                                                                                                       \
                for (; j < (N)-1; j += 2)                                                                                                               \
                {                                                                                                                                       \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                          \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                      \
                    z_v_0 = vld1q_f32((void *)__C);                                                                                                     \
                    y_v_0 = vld1q_f32((void *)__B);                                                                                                     \
                    z_v_0 = vcmlaq_f32(z_v_0, y_v_0, x_v_0);                                                                                            \
                    z_v_0 = vcmlaq_rot90_f32(z_v_0, y_v_0, x_v_0);                                                                                      \
                    vst1q_f32((void *)__C, z_v_0);                                                                                                      \
                }                                                                                                                                       \
                for (; j < (N); j++)                                                                                                                    \
                {                                                                                                                                       \
                    HML_Complex8 *tmp = C + __i * ldc + j;                                                                                              \
                    tmp->real += (A)[k * lda + __i + 0].real * (B)[(k + 0) * ldb + j].real - (A)[k * lda + __i + 0].imag * (B)[(k + 0) * ldb + j].imag; \
                    tmp->imag += (A)[k * lda + __i + 0].imag * (B)[(k + 0) * ldb + j].real + (A)[k * lda + __i + 0].real * (B)[(k + 0) * ldb + j].imag; \
                }                                                                                                                                       \
            }                                                                                                                                           \
        }                                                                                                                                               \
    }
#else
#define BLOCK_C_DGEMM_CR_GENERAL(C, A, B, bs, ldc, lda, N, ldb)                                                                                     \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                          \
    {                                                                                                                                               \
        for (HML_INT m = 0; m < bs; m++)                                                                                                            \
        {                                                                                                                                           \
            for (HML_INT j = 0; j < N; j++)                                                                                                         \
            {                                                                                                                                       \
                HML_Complex8 *tmp = C + __i * ldc + j;                                                                                              \
                tmp->real += (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].real - (A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].imag; \
                tmp->imag += (A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                       \
        }                                                                                                                                           \
    }
#endif
#ifdef CMLA
#define BLOCK_C_DGEMM_RR_SQUARE_CONJ2(C, A, B, bs, ldc, lda, ldb)                    \
    {                                                                                \
        float32x4_t z_v_00 = vdupq_n_f32(0);                                         \
        float32x4_t z_v_01 = vdupq_n_f32(0);                                         \
        float32x4_t z_v_10 = vdupq_n_f32(0);                                         \
        float32x4_t z_v_11 = vdupq_n_f32(0);                                         \
        float32x4_t y_v_00, y_v_01;                                                  \
        float32x4_t y_v_10, y_v_11;                                                  \
        float32x4_t x_v_00, x_v_01, x_v_10, x_v_11;                                  \
        for (HML_INT __i = 0; __i < (bs); __i += 2)                                  \
        {                                                                            \
            for (HML_INT j = 0; j < (bs); j += 4)                                    \
            {                                                                        \
                z_v_00 = vld1q_f32((void *)((C) + __i * (ldc) + j));                 \
                z_v_01 = vld1q_f32((void *)((C) + __i * (ldc) + j + 2));             \
                z_v_10 = vld1q_f32((void *)((C) + (__i + 1) * (ldc) + j));           \
                z_v_11 = vld1q_f32((void *)((C) + (__i + 1) * (ldc) + j + 2));       \
                for (HML_INT k = 0; k < (bs); k += 2)                                \
                {                                                                    \
                    const HML_Complex8 *X = (A) + __i * (lda) + k;                   \
                    const HML_Complex8 *X1 = (A) + (__i + 1) * (lda) + k;            \
                    const HML_Complex8 *Y00 = (B) + k * (ldb) + j;                   \
                    const HML_Complex8 *Y10 = (B) + (k + 1) * (ldb) + j;             \
                    const HML_Complex8 *Y01 = (B) + k * (ldb) + j + 2;               \
                    const HML_Complex8 *Y11 = (B) + (k + 1) * (ldb) + j + 2;         \
                    x_v_00 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)X));        \
                    x_v_01 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)(X + 1)));  \
                    x_v_10 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)(X1)));     \
                    x_v_11 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)(X1 + 1))); \
                    y_v_00 = vld1q_f32((void *)Y00);                                 \
                    y_v_01 = vld1q_f32((void *)Y01);                                 \
                    y_v_10 = vld1q_f32((void *)Y10);                                 \
                    y_v_11 = vld1q_f32((void *)Y11);                                 \
                    z_v_00 = vcmlaq_f32(z_v_00, x_v_00, y_v_00);                     \
                    z_v_01 = vcmlaq_f32(z_v_01, x_v_00, y_v_01);                     \
                    z_v_10 = vcmlaq_f32(z_v_10, x_v_10, y_v_00);                     \
                    z_v_11 = vcmlaq_f32(z_v_11, x_v_10, y_v_01);                     \
                    z_v_00 = vcmlaq_rot270_f32(z_v_00, x_v_00, y_v_00);              \
                    z_v_01 = vcmlaq_rot270_f32(z_v_01, x_v_00, y_v_01);              \
                    z_v_10 = vcmlaq_rot270_f32(z_v_10, x_v_10, y_v_00);              \
                    z_v_11 = vcmlaq_rot270_f32(z_v_11, x_v_10, y_v_01);              \
                    z_v_00 = vcmlaq_f32(z_v_00, x_v_01, y_v_10);                     \
                    z_v_01 = vcmlaq_f32(z_v_01, x_v_01, y_v_11);                     \
                    z_v_10 = vcmlaq_f32(z_v_10, x_v_11, y_v_10);                     \
                    z_v_11 = vcmlaq_f32(z_v_11, x_v_11, y_v_11);                     \
                    z_v_00 = vcmlaq_rot270_f32(z_v_00, x_v_01, y_v_10);              \
                    z_v_01 = vcmlaq_rot270_f32(z_v_01, x_v_01, y_v_11);              \
                    z_v_10 = vcmlaq_rot270_f32(z_v_10, x_v_11, y_v_10);              \
                    z_v_11 = vcmlaq_rot270_f32(z_v_11, x_v_11, y_v_11);              \
                }                                                                    \
                vst1q_f32((void *)((C) + __i * (ldc) + j), z_v_00);                  \
                vst1q_f32((void *)((C) + __i * (ldc) + j + 2), z_v_01);              \
                vst1q_f32((void *)((C) + (__i + 1) * (ldc) + j), z_v_10);            \
                vst1q_f32((void *)((C) + (__i + 1) * (ldc) + j + 2), z_v_11);        \
            }                                                                        \
        }                                                                            \
    }
#else
#define BLOCK_C_DGEMM_RR_SQUARE_CONJ2(C, A, B, bs, ldc, lda, ldb)                                                                                    \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                           \
    {                                                                                                                                                \
        for (HML_INT j = 0; j < bs; j++)                                                                                                             \
        {                                                                                                                                            \
            for (HML_INT m = 0; m < bs - 3; m += 4)                                                                                                  \
            {                                                                                                                                        \
                HML_Complex8 *tmp = C + __i * ldc + j;                                                                                               \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag;  \
                tmp->imag += -(A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].real + (A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].imag;  \
                tmp->imag += -(A)[__i * lda + m + 1].imag * (B)[(m + 1) * ldb + j].real + (A)[__i * lda + m + 1].real * (B)[(m + 1) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].real + (A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].imag;  \
                tmp->imag += -(A)[__i * lda + m + 2].imag * (B)[(m + 2) * ldb + j].real + (A)[__i * lda + m + 2].real * (B)[(m + 2) * ldb + j].imag; \
                tmp->real += (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].real + (A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].imag;  \
                tmp->imag += -(A)[__i * lda + m + 3].imag * (B)[(m + 3) * ldb + j].real + (A)[__i * lda + m + 3].real * (B)[(m + 3) * ldb + j].imag; \
            }                                                                                                                                        \
        }                                                                                                                                            \
    }
#endif
#ifdef CMLA
#define BLOCK_C_DGEMM_RR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb)                                                                                    \
    {                                                                                                                                                    \
        float32x4_t z_v_0, z_v_1, z_v_2, z_v_3;                                                                                                          \
        float32x4_t x_v_0;                                                                                                                               \
        float32x4_t y_v_0, y_v_1, y_v_2, y_v_3;                                                                                                          \
        for (HML_INT __i = 0; __i < (bs); __i++)                                                                                                         \
        {                                                                                                                                                \
            for (HML_INT k = 0; k < (bs); k++)                                                                                                           \
            {                                                                                                                                            \
                const HML_Complex8 *X = (A) + __i * (lda) + k;                                                                                           \
                x_v_0 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)X));                                                                                 \
                HML_INT j = 0;                                                                                                                           \
                if (iszero(X[0]))                                                                                                                        \
                    continue;                                                                                                                            \
                for (; j < (N)-7; j += 8)                                                                                                                \
                {                                                                                                                                        \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                           \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                       \
                    z_v_0 = vld1q_f32((void *)(__C + 0));                                                                                                \
                    z_v_1 = vld1q_f32((void *)(__C + 2));                                                                                                \
                    z_v_2 = vld1q_f32((void *)(__C + 4));                                                                                                \
                    z_v_3 = vld1q_f32((void *)(__C + 6));                                                                                                \
                    y_v_0 = vld1q_f32((void *)(__B + 0));                                                                                                \
                    y_v_1 = vld1q_f32((void *)(__B + 2));                                                                                                \
                    y_v_2 = vld1q_f32((void *)(__B + 4));                                                                                                \
                    y_v_3 = vld1q_f32((void *)(__B + 6));                                                                                                \
                    z_v_0 = vcmlaq_f32(z_v_0, x_v_0, y_v_0);                                                                                             \
                    z_v_1 = vcmlaq_f32(z_v_1, x_v_0, y_v_1);                                                                                             \
                    z_v_2 = vcmlaq_f32(z_v_2, x_v_0, y_v_2);                                                                                             \
                    z_v_3 = vcmlaq_f32(z_v_3, x_v_0, y_v_3);                                                                                             \
                    z_v_0 = vcmlaq_rot270_f32(z_v_0, x_v_0, y_v_0);                                                                                      \
                    z_v_1 = vcmlaq_rot270_f32(z_v_1, x_v_0, y_v_1);                                                                                      \
                    z_v_2 = vcmlaq_rot270_f32(z_v_2, x_v_0, y_v_2);                                                                                      \
                    z_v_3 = vcmlaq_rot270_f32(z_v_3, x_v_0, y_v_3);                                                                                      \
                    vst1q_f32((void *)(__C + 0), z_v_0);                                                                                                 \
                    vst1q_f32((void *)(__C + 2), z_v_1);                                                                                                 \
                    vst1q_f32((void *)(__C + 4), z_v_2);                                                                                                 \
                    vst1q_f32((void *)(__C + 6), z_v_3);                                                                                                 \
                }                                                                                                                                        \
                for (; j < (N)-1; j += 2)                                                                                                                \
                {                                                                                                                                        \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                           \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                       \
                    z_v_0 = vld1q_f32((void *)__C);                                                                                                      \
                    y_v_0 = vld1q_f32((void *)__B);                                                                                                      \
                    z_v_0 = vcmlaq_f32(z_v_0, x_v_0, y_v_0);                                                                                             \
                    z_v_0 = vcmlaq_rot270_f32(z_v_0, x_v_0, y_v_0);                                                                                      \
                    vst1q_f32((void *)__C, z_v_0);                                                                                                       \
                }                                                                                                                                        \
                for (; j < (N); j++)                                                                                                                     \
                {                                                                                                                                        \
                    HML_Complex8 *tmp = C + __i * ldc + j;                                                                                               \
                    tmp->real += (A)[__i * lda + k + 0].real * (B)[(k + 0) * ldb + j].real + (A)[__i * lda + k + 0].imag * (B)[(k + 0) * ldb + j].imag;  \
                    tmp->imag += -(A)[__i * lda + k + 0].imag * (B)[(k + 0) * ldb + j].real + (A)[__i * lda + k + 0].real * (B)[(k + 0) * ldb + j].imag; \
                }                                                                                                                                        \
            }                                                                                                                                            \
        }                                                                                                                                                \
    }
#else
#define BLOCK_C_DGEMM_RR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb)                                                                                \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                           \
    {                                                                                                                                                \
        for (HML_INT j = 0; j < N; j++)                                                                                                              \
        {                                                                                                                                            \
            for (HML_INT m = 0; m < bs; m++)                                                                                                         \
            {                                                                                                                                        \
                HML_Complex8 *tmp = C + __i * ldc + j;                                                                                               \
                tmp->real += (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].imag;  \
                tmp->imag += -(A)[__i * lda + m + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[__i * lda + m + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                        \
        }                                                                                                                                            \
    }
#endif
#ifdef CMLA
#define BLOCK_C_DGEMM_CR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb)                                                                                    \
    {                                                                                                                                                    \
        float32x4_t z_v_0, z_v_1, z_v_2, z_v_3;                                                                                                          \
        float32x4_t x_v_0;                                                                                                                               \
        float32x4_t y_v_0, y_v_1, y_v_2, y_v_3;                                                                                                          \
        for (HML_INT __i = 0; __i < (bs); __i++)                                                                                                         \
        {                                                                                                                                                \
            for (HML_INT k = 0; k < (bs); k++)                                                                                                           \
            {                                                                                                                                            \
                const HML_Complex8 *X = (A) + k * (lda) + __i;                                                                                           \
                x_v_0 = vreinterpretq_f32_f64(vld1q_dup_f64((void *)X));                                                                                 \
                HML_INT j = 0;                                                                                                                           \
                if (iszero(X[0]))                                                                                                                        \
                    continue;                                                                                                                            \
                for (; j < (N)-7; j += 8)                                                                                                                \
                {                                                                                                                                        \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                           \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                       \
                    z_v_0 = vld1q_f32((void *)(__C + 0));                                                                                                \
                    z_v_1 = vld1q_f32((void *)(__C + 2));                                                                                                \
                    z_v_2 = vld1q_f32((void *)(__C + 4));                                                                                                \
                    z_v_3 = vld1q_f32((void *)(__C + 6));                                                                                                \
                    y_v_0 = vld1q_f32((void *)(__B + 0));                                                                                                \
                    y_v_1 = vld1q_f32((void *)(__B + 2));                                                                                                \
                    y_v_2 = vld1q_f32((void *)(__B + 4));                                                                                                \
                    y_v_3 = vld1q_f32((void *)(__B + 6));                                                                                                \
                    z_v_0 = vcmlaq_f32(z_v_0, x_v_0, y_v_0);                                                                                             \
                    z_v_1 = vcmlaq_f32(z_v_1, x_v_0, y_v_1);                                                                                             \
                    z_v_2 = vcmlaq_f32(z_v_2, x_v_0, y_v_2);                                                                                             \
                    z_v_3 = vcmlaq_f32(z_v_3, x_v_0, y_v_3);                                                                                             \
                    z_v_0 = vcmlaq_rot270_f32(z_v_0, x_v_0, y_v_0);                                                                                      \
                    z_v_1 = vcmlaq_rot270_f32(z_v_1, x_v_0, y_v_1);                                                                                      \
                    z_v_2 = vcmlaq_rot270_f32(z_v_2, x_v_0, y_v_2);                                                                                      \
                    z_v_3 = vcmlaq_rot270_f32(z_v_3, x_v_0, y_v_3);                                                                                      \
                    vst1q_f32((void *)(__C + 0), z_v_0);                                                                                                 \
                    vst1q_f32((void *)(__C + 2), z_v_1);                                                                                                 \
                    vst1q_f32((void *)(__C + 4), z_v_2);                                                                                                 \
                    vst1q_f32((void *)(__C + 6), z_v_3);                                                                                                 \
                }                                                                                                                                        \
                for (; j < (N)-1; j += 2)                                                                                                                \
                {                                                                                                                                        \
                    HML_Complex8 *__C = (C) + __i * (ldc) + j;                                                                                           \
                    const HML_Complex8 *__B = (B) + k * (ldb) + j;                                                                                       \
                    z_v_0 = vld1q_f32((void *)__C);                                                                                                      \
                    y_v_0 = vld1q_f32((void *)__B);                                                                                                      \
                    z_v_0 = vcmlaq_f32(z_v_0, x_v_0, y_v_0);                                                                                             \
                    z_v_0 = vcmlaq_rot270_f32(z_v_0, x_v_0, y_v_0);                                                                                      \
                    vst1q_f32((void *)__C, z_v_0);                                                                                                       \
                }                                                                                                                                        \
                for (; j < (N); j++)                                                                                                                     \
                {                                                                                                                                        \
                    HML_Complex8 *tmp = C + __i * ldc + j;                                                                                               \
                    tmp->real += (A)[k * lda + __i + 0].real * (B)[(k + 0) * ldb + j].real + (A)[k * lda + __i + 0].imag * (B)[(k + 0) * ldb + j].imag;  \
                    tmp->imag += -(A)[k * lda + __i + 0].imag * (B)[(k + 0) * ldb + j].real + (A)[k * lda + __i + 0].real * (B)[(k + 0) * ldb + j].imag; \
                }                                                                                                                                        \
            }                                                                                                                                            \
        }                                                                                                                                                \
    }
#else
#define BLOCK_C_DGEMM_CR_GENERAL_CONJ2(C, A, B, bs, ldc, lda, N, ldb)                                                                                \
    for (HML_INT __i = 0; __i < bs; __i++)                                                                                                           \
    {                                                                                                                                                \
        for (HML_INT m = 0; m < bs; m++)                                                                                                             \
        {                                                                                                                                            \
            for (HML_INT j = 0; j < N; j++)                                                                                                          \
            {                                                                                                                                        \
                HML_Complex8 *tmp = C + __i * ldc + j;                                                                                               \
                tmp->real += (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].real + (A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].imag;  \
                tmp->imag += -(A)[m * lda + __i + 0].imag * (B)[(m + 0) * ldb + j].real + (A)[m * lda + __i + 0].real * (B)[(m + 0) * ldb + j].imag; \
            }                                                                                                                                        \
        }                                                                                                                                            \
    }
#endif
