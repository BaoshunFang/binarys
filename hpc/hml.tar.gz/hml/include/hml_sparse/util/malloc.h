#pragma once

/**
 * @brief header for ict malloc utils
 */

#include <stdlib.h>


#define DEFAULT_ALIGNMENT 32

void *hml_malloc(size_t bytes);

void *hml_memalign(size_t bytes, size_t alignment);

void hml_free(void *point);

#define L1_CACHE_SIZE   (32 * 1024)
#define L2_CACHE_SIZE   (512 * 1024)
#define L3_CACHE_SIZE   (16 * 1024 * 1024)
void hml_clear_cache();

