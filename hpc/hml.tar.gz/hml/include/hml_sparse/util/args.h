#pragma once

#include <getopt.h>
#include <stdlib.h>
#include "hml_sparse/spdef.h"
#include <stdbool.h>

#define DEFAULT_DATA_FILE ""
#define DEFAULT_THREAD_NUM 1
#define DEFAULT_CHECK false
#define DEFAULT_LAYOUT HML_SPARSE_LAYOUT_ROW_MAJOR
#define DEFAULT_SPARSE_OPERATION HML_SPARSE_OPERATION_NON_TRANSPOSE
#define DEFAULT_ITER 1

hml_sparse_layout_t hml_sparse_layout_parse(const char *arg);
hml_sparse_operation_t hml_sparse_operation_parse(const char *arg);
hml_sparse_matrix_type_t hml_sparse_matrix_type_parse(const char *arg);
hml_sparse_fill_mode_t hml_sparse_fill_mode_parse(const char *arg);
hml_sparse_diag_type_t hml_sparse_diag_type_parse(const char *arg);

void args_help(const int argc, const char *argv[]);
bool args_get_if_check(const int argc, const char *argv[]);
int args_get_thread_num(const int argc, const char *argv[]);
int args_get_columns(const int argc, const char *argv[], int k);
int args_get_iter(const int argc, const char *argv[]);

const char *args_get_data_file(const int argc, const char *argv[]);
const char *args_get_data_fileA(const int argc, const char *argv[]);
const char *args_get_data_fileB(const int argc, const char *argv[]);

hml_sparse_layout_t hml_args_get_layout_helper(const int argc, const char *argv[], const int layout_opt);
struct hml_matrix_descr hml_args_get_matrix_descr_helper(const int argc, const char *argv[], const int type_opt, const int fill_opt, const int diag_opt);
hml_sparse_operation_t hml_args_get_trans_helper(const int argc, const char *argv[], const int trans_opt);

hml_sparse_layout_t hml_args_get_layout(const int argc, const char *argv[]);
hml_sparse_layout_t hml_args_get_layoutB(const int argc, const char *argv[]);
hml_sparse_layout_t hml_args_get_layoutC(const int argc, const char *argv[]);

struct hml_matrix_descr hml_args_get_matrix_descrA(const int argc, const char *argv[]);
struct hml_matrix_descr hml_args_get_matrix_descrB(const int argc, const char *argv[]);

hml_sparse_operation_t hml_args_get_transA(const int argc, const char *argv[]);
hml_sparse_operation_t hml_args_get_transB(const int argc, const char *argv[]);

void hml_arg_parse(const int argc, const char *argv[], hml_sparse_layout_t *layout, hml_sparse_operation_t *transA, hml_sparse_operation_t *transB, struct hml_matrix_descr *descr);

