
// yanghao @ Hygon Information Technology Co. 2024/7

#pragma once


#ifdef __cplusplus
    extern "C" {
#endif


#include <pthread.h>
#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


// thread safe memory pool
struct hml_mem_pool;

// create a new mem pool
struct hml_mem_pool *hml_create_mem_pool(int has_lock);

// discard an existing mem pool
void hml_discard_mem_pool(struct hml_mem_pool *pool);

// allocate memory from the pool
void *hml_pool_alloc(struct hml_mem_pool *pool, size_t size);

// allocate memory from thread-specific pool
void *hml_pool_malloc(size_t size);

// return memory block back to pool
void hml_pool_free(void *ptr);

// check completeness of the memory pool
void hml_check_mem_pool(struct hml_mem_pool *pool);


#ifdef __cplusplus
    }
#endif

