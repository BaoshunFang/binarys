#pragma once

#include "hml_sparse/types.h"
#include "hml_sparse/spdef.h"

void hml_sparse_nnz_counter_coo(const HML_INT *row_indx, const HML_INT *col_indx, const HML_INT nnz, HML_INT *lo_p, HML_INT *diag_p, HML_INT *hi_p);
HML_INT64 hml_sparse_operations_mm(const HML_INT rows, const HML_INT cols, const HML_INT lo, const HML_INT diag, const HML_INT hi, const hml_sparse_operation_t operation, const struct hml_matrix_descr descr, const HML_INT columns, const hml_sparse_datatype_t datatype);
HML_INT64 hml_sparse_operations_mv(const HML_INT rows, const HML_INT cols, const HML_INT lo, const HML_INT diag, const HML_INT hi, const hml_sparse_operation_t operation, const struct hml_matrix_descr descr, const hml_sparse_datatype_t datatype);
