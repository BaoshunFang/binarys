#pragma once

/**
 * @brief header for multithread utils
 */
#ifdef _OPENMP
#include <omp.h>
#endif

int hml_get_core_num();

void hml_set_thread_num(const int num);

int hml_get_thread_num();

int hml_get_thread_id();
