#pragma once

#include "../types.h"
#define BLOCK_DGEMV_ROW BLOCK_S_DGEMV_ROW
#define BLOCK_DGEMV_COL BLOCK_S_DGEMV_COL
// gemv s row
#define BLOCK_S_DGEMV_ROW(y, A, x, bs, lda)          \
    for (HML_INT __i = 0; __i < bs; __i++)           \
    {                                                \
        for (HML_INT j = 0; j < bs; j++)             \
        {                                            \
            (y)[__i] += (A)[__i * lda + j] * (x)[j]; \
        }                                            \
    }

// gemv s col
#define BLOCK_S_DGEMV_COL(y, A, x, bs, lda)              \
    for (HML_INT j = 0; j < bs; j++)                     \
        for (HML_INT __i = 0; __i < bs; __i++)           \
        {                                                \
            {                                            \
                (y)[__i] += (A)[j * lda + __i] * (x)[j]; \
            }                                            \
        }
