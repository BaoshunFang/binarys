#pragma once
#include <stdint.h>
#include "hml_sparse/types.h"
#include "hml_sparse/spmat.h"

bool LUdecompose_s(HML_INT row, HML_INT col, float *x, float *y);
bool LUdecompose_d(HML_INT row, HML_INT col, double *x, double *y);
bool LUdecompose_c(HML_INT row, HML_INT col, HML_Complex8 *x, HML_Complex8 *y);
bool LUdecompose_z(HML_INT row, HML_INT col, HML_Complex16 *x, HML_Complex16 *y);

#ifndef COMPLEX
#ifndef DOUBLE

#define LUdecompose LUdecompose_s
#else

#define LUdecompose LUdecompose_d

#endif
#else
#ifndef DOUBLE

#define LUdecompose LUdecompose_c

#else

#define LUdecompose LUdecompose_z

#endif
#endif