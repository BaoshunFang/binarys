#pragma once

#include "../types.h"
#define BLOCK_DGEMV_ROW BLOCK_D_DGEMV_ROW
#define BLOCK_DGEMV_COL BLOCK_D_DGEMV_COL
// gemv d row
#define BLOCK_D_DGEMV_ROW(y, A, x, bs, lda)          \
    for (HML_INT __i = 0; __i < bs; __i++)           \
    {                                                \
        for (HML_INT j = 0; j < bs; j++)             \
        {                                            \
            (y)[__i] += (A)[__i * lda + j] * (x)[j]; \
        }                                            \
    }

// gemv d col
#define BLOCK_D_DGEMV_ROW(y, A, x, bs, lda)          \
    for (HML_INT __i = 0; __i < bs; __i++)           \
    {                                                \
        for (HML_INT j = 0; j < bs; j++)             \
        {                                            \
            (y)[__i] += (A)[__i * lda + j] * (x)[j]; \
        }                                            \
    }
