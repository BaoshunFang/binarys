
#pragma once


#include "hml_sparse/types.h"
#include <stdlib.h>


static inline int random_int(int m) {return rand() % m;}
static inline double random_float() {return (double)rand() / RAND_MAX;}

void hml_fill_random_s(float *arr, unsigned int seed, const size_t size);
void hml_fill_random_d(double *arr, unsigned int seed, const size_t size);
void hml_fill_random_c(HML_Complex8 *arr, unsigned int seed, const size_t size);
void hml_fill_random_z(HML_Complex16 *arr, unsigned int seed, const size_t size);

