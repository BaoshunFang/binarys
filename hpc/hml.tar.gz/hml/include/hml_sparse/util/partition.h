#pragma once

/**
 * @brief header for data partition utils
 */

#include <stdint.h>
#include "hml_sparse/types.h"
#include "hml_sparse/spmat.h"

#define cross_block_low(id, p, n) ((id) * (n) / (p))
#define cross_block_high(id, p, n) cross_block_low((id) + 1, p, n)
#define cross_block_size(id, p, n) \
  (cross_block_low((id) + 1, p, n) - (cross_block_low(id, p, n)))
#define cross_block_owner(index, p, n) (((p) * ((index) + 1) - 1) / (n))

void find_divisors(HML_INT n, HML_INT *divisors, HML_INT *num);
void balanced_divisors2(HML_INT m, HML_INT n, HML_INT num_threads, HML_INT *divm_p, HML_INT *divn_p);

int lower_bound_int(const HML_INT *t, HML_INT l, HML_INT r, HML_INT value);
int lower_bound_int64(const HML_INT64 *t, HML_INT64 l, HML_INT64 r, HML_INT64 value);

void balanced_partition_row_by_nnz(const HML_INT *acc_sum_arr, HML_INT rows, HML_INT num_threads, HML_INT *partition);
void balanced_partition_row_by_flop(const HML_INT64 *acc_sum_arr, HML_INT rows, HML_INT num_threads, HML_INT *partition);
void balance_workload_by_nnz(const int *sum_nnz, int rows, int threads, int *partition);

void block_partition(HML_INT *pointerB, HML_INT *pointerE, HML_INT *block_indx, HML_INT block_dim_len, HML_INT another_dim_len, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);

// pos[index(r,bi,ldp)]
void csr_s_col_partition(const spmat_csr_s_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void csr_d_col_partition(const spmat_csr_d_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void csr_c_col_partition(const spmat_csr_c_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void csr_z_col_partition(const spmat_csr_z_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);

// pos[index(c,bi,ldp)]
void csc_s_row_partition(const spmat_csc_s_t *A, HML_INT cs, HML_INT ce, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void csc_d_row_partition(const spmat_csc_d_t *A, HML_INT cs, HML_INT ce, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void csc_c_row_partition(const spmat_csc_c_t *A, HML_INT cs, HML_INT ce, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void csc_z_row_partition(const spmat_csc_z_t *A, HML_INT cs, HML_INT ce, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);

// pos[index(r,bi,ldp)]
void bsr_s_col_partition(const spmat_bsr_s_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void bsr_d_col_partition(const spmat_bsr_d_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void bsr_c_col_partition(const spmat_bsr_c_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);
void bsr_z_col_partition(const spmat_bsr_z_t *A, HML_INT rs, HML_INT re, HML_INT block_size, HML_INT **pos_p, HML_INT *block_num_p, HML_INT *ldp_p);

#ifndef COMPLEX
#ifndef DOUBLE

#define csr_col_partition csr_s_col_partition
#define bsr_col_partition bsr_s_col_partition
#define csc_row_partition csc_s_row_partition

#else

#define csr_col_partition csr_d_col_partition
#define bsr_col_partition bsr_d_col_partition
#define csc_row_partition csc_d_row_partition

#endif
#else
#ifndef DOUBLE

#define csr_col_partition csr_c_col_partition
#define bsr_col_partition bsr_c_col_partition
#define csc_row_partition csc_c_row_partition

#else

#define csr_col_partition csr_z_col_partition
#define bsr_col_partition bsr_z_col_partition
#define csc_row_partition csc_z_row_partition

#endif
#endif
