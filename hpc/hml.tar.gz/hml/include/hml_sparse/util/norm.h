#pragma once

/**
 * @brief header for parameter check utils
 */

#include <stdlib.h>
#include "../spdef.h"
#include "../types.h"
#include "../spmat.h"
#include <stdbool.h>

float CalEpisilon_s();
double CalEpisilon_d();

double InfiniteNorm_d(const HML_INT n, const double *xa, const double *xb);
double GeNorm1_d(HML_INT n, HML_INT nnz, const HML_INT *col_index, const double *val);
double TrSyNorm1_d(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const double *val, struct hml_matrix_descr descr);
double DiNorm1_d(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const double *val, struct hml_matrix_descr descr);

double DesNorm1_d(HML_INT rows, HML_INT cols, const double *val, HML_INT ldv, hml_sparse_layout_t layout);
double DesDiffNorm1_d(const HML_INT rows, const HML_INT cols, const double *xa, const HML_INT lda, const double *xb, const HML_INT ldb, hml_sparse_layout_t layout);

float InfiniteNorm_s(const HML_INT n, const float *xa, const float *xb);
float GeNorm1_s(HML_INT n, HML_INT nnz, const HML_INT *col_index, const float *val);
float TrSyNorm1_s(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const float *val, struct hml_matrix_descr descr);
float DiNorm1_s(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const float *val, struct hml_matrix_descr descr);

float DesNorm1_s(HML_INT rows, HML_INT cols, const float *val, HML_INT ldv, hml_sparse_layout_t layout);
float DesDiffNorm1_s(const HML_INT rows, const HML_INT cols, const float *xa, const HML_INT lda, const float *xb, const HML_INT ldb, hml_sparse_layout_t layout);

float InfiniteNorm_c(const HML_INT n, const HML_Complex8 *xa, const HML_Complex8 *xb);
float GeNorm1_c(HML_INT n, HML_INT nnz, const HML_INT *col_index, const HML_Complex8 *val);
float TrSyNorm1_c(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const HML_Complex8 *val, struct hml_matrix_descr descr);
float DiNorm1_c(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const HML_Complex8 *val, struct hml_matrix_descr descr);

float DesNorm1_c(HML_INT rows, HML_INT cols, const HML_Complex8 *val, HML_INT ldv, hml_sparse_layout_t layout);
float DesDiffNorm1_c(const HML_INT rows, const HML_INT cols, const HML_Complex8 *xa, const HML_INT lda, const HML_Complex8 *xb, const HML_INT ldb, hml_sparse_layout_t layout);

double InfiniteNorm_z(const HML_INT n, const HML_Complex16 *xa, const HML_Complex16 *xb);
double GeNorm1_z(HML_INT n, HML_INT nnz, const HML_INT *col_index, const HML_Complex16 *val);
double TrSyNorm1_z(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const HML_Complex16 *val, struct hml_matrix_descr descr);
double DiNorm1_z(HML_INT n, HML_INT nnz, const HML_INT *row_index, const HML_INT *col_index, const HML_Complex16 *val, struct hml_matrix_descr descr);

double DesNorm1_z(HML_INT rows, HML_INT cols, const HML_Complex16 *val, HML_INT ldv, hml_sparse_layout_t layout);
double DesDiffNorm1_z(const HML_INT rows, const HML_INT cols, const HML_Complex16 *xa, const HML_INT lda, const HML_Complex16 *xb, const HML_INT ldb, hml_sparse_layout_t layout);
