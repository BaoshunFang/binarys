#pragma once

/**
 * @brief header for timing utils
 */

#include <stdint.h>


typedef struct
{
    int64_t count;
    double memo[256];

    double start;
    double end;
}
hml_timer_t;


double hml_timing_wtime();

void hml_timing_start(hml_timer_t *timer);

void hml_timing_end(hml_timer_t *timer);

// 统计平均时间间隔
double hml_timing_average_time(hml_timer_t *timer);

// 统计中位数时间间隔
double hml_timing_median_time(hml_timer_t *timer);

double hml_timing_elapsed_time(const hml_timer_t *timer);

double hml_timing_gflops(const hml_timer_t *timer, int64_t operations);

void hml_timing_elaped_time_print(const hml_timer_t *timer, const char *name);

void hml_timing_gflops_print(const hml_timer_t *timer, int64_t operations, const char *name);

#define hml_timing(func, ...)        \
    hml_timer_t func##_timer;        \
    hml_timing_start(&func##_timer); \
    func(__VA_ARGS__);               \
    hml_timing_end(&func##_timer);   \
    hml_timing_elaped_time_print(&func##_timer, #func);
