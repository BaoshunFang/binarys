#pragma once

/**
 * @brief header for error detection utils
 */

#include "../types.h"

#define hml_call_exit(func, message)              \
  do                                              \
  {                                               \
    hml_sparse_status_t status = func;            \
    if (status != HML_SPARSE_STATUS_SUCCESS)      \
    {                                             \
      printf("%s\n", message);                    \
      switch (status)                             \
      {                                           \
      case HML_SPARSE_STATUS_NOT_INITIALIZED:     \
        printf("status : not initialized!!!\n");  \
        break;                                    \
      case HML_SPARSE_STATUS_ALLOC_FAILED:        \
        printf("status : alloc failed!!!\n");     \
        break;                                    \
      case HML_SPARSE_STATUS_INVALID_VALUE:       \
        printf("status : invalid value!!!\n");    \
        break;                                    \
      case HML_SPARSE_STATUS_EXECUTION_FAILED:    \
        printf("status : execution failed!!!\n"); \
        break;                                    \
      case HML_SPARSE_STATUS_INTERNAL_ERROR:      \
        printf("status : internal error!!!\n");   \
        break;                                    \
      case HML_SPARSE_STATUS_NOT_SUPPORTED:       \
        printf("status : not supported!!!\n");    \
        break;                                    \
      default:                                    \
        printf("status : status invalid!!!\n");   \
        break;                                    \
      }                                           \
      fflush(0);                                  \
      exit(-1);                                   \
    }                                             \
  } while (0);

#define mkl_call_exit(func, message)              \
  do                                              \
  {                                               \
    int status = func;                            \
    if (status != 0)                              \
    {                                             \
      printf("%s\n", message);                    \
      switch (status)                             \
      {                                           \
      case 1:                                     \
        printf("status : not initialized!!!\n");  \
        break;                                    \
      case 2:                                     \
        printf("status : alloc failed!!!\n");     \
        break;                                    \
      case 3:                                     \
        printf("status : invalid value!!!\n");    \
        break;                                    \
      case 4:                                     \
        printf("status : execution failed!!!\n"); \
        break;                                    \
      case 5:                                     \
        printf("status : internal error!!!\n");   \
        break;                                    \
      case 6:                                     \
        printf("status : not supported!!!\n");    \
        break;                                    \
      default:                                    \
        printf("status : status invalid!!!\n");   \
        break;                                    \
      }                                           \
      fflush(0);                                  \
      exit(-1);                                   \
    }                                             \
  } while (0);

#define roc_call_exit(func, message)                                     \
  do                                                                     \
  {                                                                      \
    int status = func;                                                   \
    if (status != 0)                                                     \
    {                                                                    \
      printf("%s\n", message);                                           \
      switch (status)                                                    \
      {                                                                  \
      case 1:                                                            \
        printf("status : handle not initialized, invalid or null!!!\n"); \
        break;                                                           \
      case 2:                                                            \
        printf("status : function is not implemented!!!\n");             \
        break;                                                           \
      case 3:                                                            \
        printf("status : invalid pointer parameter!!!\n");               \
        break;                                                           \
      case 4:                                                            \
        printf("status : invalid size parameter!!!\n");                  \
        break;                                                           \
      case 5:                                                            \
        printf("status : failed memory allocation, copy, dealloc!!!\n"); \
        break;                                                           \
      case 6:                                                            \
        printf("status : other internal library failure!!!\n");          \
        break;                                                           \
      case 7:                                                            \
        printf("status : invalid value parameter!!!\n");                 \
        break;                                                           \
      case 8:                                                            \
        printf("status : device arch is not supported!!!\n");            \
        break;                                                           \
      case 9:                                                            \
        printf("status : encountered zero pivot!!!\n");                  \
        break;                                                           \
      default:                                                           \
        printf("status : status invalid!!!\n");                          \
        break;                                                           \
      }                                                                  \
      fflush(0);                                                         \
      exit(-1);                                                          \
    }                                                                    \
  } while (0);
