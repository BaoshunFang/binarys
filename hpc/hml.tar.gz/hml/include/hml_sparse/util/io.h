#pragma once

/**
 * @brief header for file read and write utils
 */

#include "../spdef.h"
#include "../types.h"
#include <stdlib.h>
#include <stdio.h>

#define BUFFER_SIZE 1024

FILE *hml_open(const char *filename, const char *modes);
void hml_close(FILE *stream);

void result_write(const char *path, const size_t ele_num, size_t ele_size, const void *data);

void hml_read_coo(const char *file, HML_INT *m_p, HML_INT *n_p, HML_INT *nnz_p, HML_INT **row_index, HML_INT **col_index, float **values);
void hml_read_coo_d(const char *file, HML_INT *m_p, HML_INT *n_p, HML_INT *nnz_p, HML_INT **row_index, HML_INT **col_index, double **values);
void hml_read_coo_c(const char *file, HML_INT *m_p, HML_INT *n_p, HML_INT *nnz_p, HML_INT **row_index, HML_INT **col_index, HML_Complex8 **values);
void hml_read_coo_z(const char *file, HML_INT *m_p, HML_INT *n_p, HML_INT *nnz_p, HML_INT **row_index, HML_INT **col_index, HML_Complex16 **values);

