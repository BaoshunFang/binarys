#pragma once

/**
 * @brief header for all basic type definitions except the internal sparse matrix
 */

#include <stdint.h>
#include <stdbool.h>

#ifndef DOUBLE
#define HML_Float float
#define HML_Complex HML_Complex8
#else
#define HML_Float double
#define HML_Complex HML_Complex16
#endif

#ifndef COMPLEX
#define HML_Number HML_Float
#else
#define HML_Number HML_Complex
#endif

#ifndef COMPLEX
#ifndef DOUBLE
#define HML_Point point_s_t
#define S S
#else
#define HML_Point point_d_t
#define D D
#endif
#else
#ifndef DOUBLE
#define HML_Point point_c_t
#define C C
#else
#define HML_Point point_z_t
#define Z Z
#endif
#endif

#ifndef HML_Complex8
typedef struct
{
    float real;
    float imag;
} HML_Complex8;
#endif

#ifndef HML_Complex16
typedef struct
{
    double real;
    double imag;
} HML_Complex16;
#endif

#ifndef HML_INT
#define HML_INT int32_t
#endif

#ifndef HML_UINT
#define HML_UINT uint32_t
#endif

#ifndef HML_LONG
#define HML_LONG int64_t
#endif

#ifndef HML_UINT8
#define HML_UINT8 uint8_t
#endif

#ifndef HML_INT8
#define HML_INT8 int8_t
#endif

#ifndef HML_INT16
#define HML_INT16 int16_t
#endif

#ifndef HML_INT32
#define HML_INT32 int32_t
#endif

#ifndef HML_INT64
#define HML_INT64 int64_t
#endif

typedef struct
{
    HML_INT x;
    HML_INT y;
} int2_t;

typedef struct
{
    HML_INT x;
    HML_INT y;
    HML_INT z;
} int3_t;

typedef struct
{
    HML_INT x;
    HML_INT y;
    float v;
} point_s_t;

typedef struct
{
    HML_INT x;
    HML_INT y;
    double v;
} point_d_t;

typedef struct
{
    HML_INT x;
    HML_INT y;
    HML_Complex8 v;
} point_c_t;

typedef struct
{
    HML_INT x;
    HML_INT y;
    HML_Complex16 v;
} point_z_t;
