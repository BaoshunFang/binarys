#pragma once

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

extern "C" const char *hfft_get_build_date();
extern "C" const char *hfft_get_build_time();
extern "C" const char *hfft_get_commit_uid();
extern "C" const char *hfft_get_version_tag();

#ifdef __cplusplus
}  /* extern "C" */
#endif /* __cplusplus */
