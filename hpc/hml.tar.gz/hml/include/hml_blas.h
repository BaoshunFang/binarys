/*******************************************************************************
 * Copyright (C) 2025 Hygon,Inc. All rights reserved.
 * Description: blas interface for the user
 * Author:  HML
 * Create: 2025.11
 *******************************************************************************/

#ifndef HML_CBLAS_F77_H
#define HML_CBLAS_F77_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
#if __cplusplus > 199711L
#define NOTHROW noexcept
#else
#define NOTHROW throw()
#endif
#else
#define NOTHROW
#endif

#ifndef HML_BLAS_TYPES_DEF
#define HML_BLAS_TYPES_DEF

// 1. hml_int_t
// 2. complex

typedef int hml_int_t;

// if you want to customize your complex struct 
// you should define:
// 1. macro  HML_BLAS_COMPLEX_STRUCT
// 2. datatype blas_complex_float 
// 3. datatype blas_complex_double
// 4. blas_make_complex_float blas_make_complex_double 
// 5. blas_complex_float_real blas_complex_float_image
// 6. blas_complex_double_real blas_complex_double_image
// then include hml_blas.h 

#ifndef HML_BLAS_COMPLEX_CUSTOM

#if defined(HML_BLAS_COMPLEX_STRUCTURE)

typedef struct { float real, imag; } blas_complex_float;
typedef struct { double real, imag; } blas_complex_double;

#define blas_complex_float_real(z)  ((z).real)
#define blas_complex_float_imag(z)  ((z).imag)
#define blas_complex_double_real(z)  ((z).real)
#define blas_complex_double_imag(z)  ((z).imag)
static inline blas_complex_float blas_make_complex_float(float real, float imag) {
    blas_complex_float complex_z;
    complex_z.real = real;
    complex_z.imag = imag;
    return complex_z;
}

static inline blas_complex_double blas_make_complex_double(double real, double imag) {
    blas_complex_double complex_z;
    complex_z.real = real;
    complex_z.imag = imag;
    return complex_z;
}

#elif defined(HML_BLAS_COMPLEX_CPP)

#define blas_complex_float std::complex<float>
#define blas_complex_double std::complex<double>
#define blas_make_complex_float(real, imag) (std::complex<float>(real, imag))
#define blas_make_complex_double(real, imag) (std::complex<double>(real, imag))
#define blas_complex_float_real(z)       ((z).real())
#define blas_complex_float_imag(z)       ((z).imag())
#define blas_complex_double_real(z)      ((z).real())
#define blas_complex_double_imag(z)      ((z).imag())

#else

// #ifndef __cplusplus
// #include <complex.h>
// #endif 

#define blas_complex_float    float _Complex
#define blas_complex_double   double _Complex
#define blas_make_complex_float(real, imag) ((real) + ((imag)*_Complex_I))
#define blas_make_complex_double(real, imag) ((real) + ((imag)*_Complex_I))
#define blas_complex_float_real(z)       (creal(z))
#define blas_complex_float_imag(z)       (cimag(z))
#define blas_complex_double_real(z)      (creal(z))
#define blas_complex_double_imag(z)      (cimag(z))

#endif // HML_BLAS_COMPLEX_STRUCTURE

#endif //HML_BLAS_COMPLEX_CUSTOM

#endif  // HML_BLAS_TYPES_DEF

#if defined(__INTEL_COMPILER) || defined(__INTEL_LLVM_COMPILER) || defined(__clang__) 
#define BLAS_COMPLEX_RETURN_ARGUMENT
#endif 

// compat with blis 
typedef blas_complex_float  scomplex;
typedef blas_complex_double dcomplex;

#ifdef __cplusplus
extern "C" {
#endif  // __cplusplus

// all api
// 1. standard f77 api
// 2. batch
// 3. extend

/// 1. standard f77 api ===============================

void xerbla_(const char *srname, const int *info, const int lsrname);
int  lsame_(const char *ca, const char *cb, const hml_int_t lca,
            const hml_int_t lcb);

// scalar
float  scabs1_(const blas_complex_float *c);
double dcabs1_(const blas_complex_double *z);

// level 1
float sasum_(const hml_int_t *n, const float *x, const hml_int_t *incx) NOTHROW;
void saxpy_(const hml_int_t *n, const float *alpha, const float *x,
            const hml_int_t *incx, float *y, const hml_int_t *incy) NOTHROW;
void scopy_(const hml_int_t *n, const float *x, const hml_int_t *incx, float *y,
            const hml_int_t *incy) NOTHROW;
float sdot_(const hml_int_t *n, const float *x, const hml_int_t *incx,
            const float *y, const hml_int_t *incy) NOTHROW;
float snrm2_(const hml_int_t *n, const float *x, const hml_int_t *incx) NOTHROW;
void srot_(const hml_int_t *n, float *x, const hml_int_t *incx, float *y,
           const hml_int_t *incy, const float *c, const float *s) NOTHROW;
void srotg_(float *a, float *b, float *c, float *s) NOTHROW;
void srotm_(const hml_int_t *n, float *x, const hml_int_t *incx, float *y,
            const hml_int_t *incy, const float *param) NOTHROW;
void srotmg_(float *d1, float *d2, float *x1, const float *y1,
             float *param) NOTHROW;
void sscal_(const hml_int_t *n, const float *a, float *x,
            const hml_int_t *incx) NOTHROW;
void sswap_(const hml_int_t *n, float *x, const hml_int_t *incx, float *y,
            const hml_int_t *incy) NOTHROW;
void saxpby_(const hml_int_t *n, const float *alpha, const float *x,
            const hml_int_t *incx, const float *beta, float *y,
            const hml_int_t *incy) NOTHROW;
hml_int_t isamax_(const hml_int_t *n, const float *x,
                  const hml_int_t *incx) NOTHROW;

// hml_int_t isamin_(const hml_int_t *n, const float *x, const hml_int_t *incx)
// NOTHROW;

float sdsdot_(const hml_int_t *n, const float *sb, const float *x,
              const hml_int_t *incx, const float *y,
              const hml_int_t *incy) NOTHROW;
float scnrm2_(const hml_int_t *n, const blas_complex_float *x,
              const hml_int_t *incx) NOTHROW;
float scasum_(const hml_int_t *n, const blas_complex_float *x,
              const hml_int_t *incx) NOTHROW;

void snrm2sub_(const hml_int_t *n, const float *x, const hml_int_t *incx, float* ret) NOTHROW; 
void sdotsub_(const hml_int_t *n, const float *x, const hml_int_t *incx, const float *y, const hml_int_t *incy, float* ret) NOTHROW;
void sasumsub_(const hml_int_t *n, const float *x, const hml_int_t *incx,float* ret) NOTHROW; 
void isamaxsub_(const hml_int_t *n, const float *x, const hml_int_t *incx, hml_int_t* ret) NOTHROW; 
void sdsdotsub_(const hml_int_t *n, const float *sb, const float *x, const hml_int_t *incx, const float *y, const hml_int_t *incy, float* ret) NOTHROW; 
void scnrm2sub_(const hml_int_t *n, const blas_complex_float *x, const hml_int_t *incx, float* ret) NOTHROW; 
void scasumsub_(const hml_int_t *n, const blas_complex_float *x, const hml_int_t *incx, float* ret) NOTHROW;

double dasum_(const hml_int_t *n, const double *x,
              const hml_int_t *incx) NOTHROW;
void daxpy_(const hml_int_t *n, const double *alpha, const double *x,
            const hml_int_t *incx, double *y, const hml_int_t *incy) NOTHROW;
void dcopy_(const hml_int_t *n, const double *x, const hml_int_t *incx,
            double *y, const hml_int_t *incy) NOTHROW;
double ddot_(const hml_int_t *n, const double *x, const hml_int_t *incx,
             const double *y, const hml_int_t *incy) NOTHROW;
double dnrm2_(const hml_int_t *n, const double *x,
              const hml_int_t *incx) NOTHROW;
void drot_(const hml_int_t *n, double *x, const hml_int_t *incx, double *y,
           const hml_int_t *incy, const double *c, const double *s) NOTHROW;
void drotg_(double *a, double *b, double *c, double *s) NOTHROW;
void drotm_(const hml_int_t *n, double *x, const hml_int_t *incx, double *y,
            const hml_int_t *incy, const double *param) NOTHROW;
void drotmg_(double *d1, double *d2, double *x1, const double *y1,
             double *param) NOTHROW;
void dscal_(const hml_int_t *n, const double *a, double *x,
            const hml_int_t *incx) NOTHROW;
void dswap_(const hml_int_t *n, double *x, const hml_int_t *incx, double *y,
            const hml_int_t *incy) NOTHROW;
void daxpby_(const hml_int_t *n, const double *alpha, const double *x,
            const hml_int_t *incx, const double *beta, double *y,
            const hml_int_t *incy) NOTHROW;
hml_int_t idamax_(const hml_int_t *n, const double *x,
                  const hml_int_t *incx) NOTHROW;
// hml_int_t idamin_(const hml_int_t *n, const double *x, const hml_int_t *incx) NOTHROW;

double dsdot_(const hml_int_t *n, const float *x, const hml_int_t *incx,
              const float *y, const hml_int_t *incy) NOTHROW;
double dzasum_(const hml_int_t *n, const blas_complex_double *x,
               const hml_int_t *incx) NOTHROW;
double dznrm2_(const hml_int_t *n, const blas_complex_double *x,
              const hml_int_t *incx) NOTHROW;

void dnrm2sub_(const hml_int_t *n, const double *x, const hml_int_t *incx, double* ret) NOTHROW; 
void ddotsub_(const hml_int_t *n, const double *x, const hml_int_t *incx, const double *y, const hml_int_t *incy, double* ret) NOTHROW;
void idamaxsub_(const hml_int_t *n, const double *x, const hml_int_t *incx, hml_int_t* ret) NOTHROW; 
void dasumsub_(const hml_int_t *n, const double *x, const hml_int_t *incx, double* ret) NOTHROW; 
void dsdotsub_(const hml_int_t *n, const float *x, const hml_int_t *incx, const float *y, const hml_int_t *incy, double* ret) NOTHROW;
void dznrm2sub_(const hml_int_t *n, const blas_complex_double *x,const hml_int_t *incx, double*) NOTHROW;
void dzasumsub_(const hml_int_t *n, const blas_complex_double *x, const hml_int_t *incx, double* ret) NOTHROW;

void caxpy_(const hml_int_t *n, const blas_complex_float *alpha,
            const blas_complex_float *x, const hml_int_t *incx,
            blas_complex_float *y, const hml_int_t *incy) NOTHROW;
void ccopy_(const hml_int_t *n, const blas_complex_float *x,
           const hml_int_t *incx, blas_complex_float *y,
           const hml_int_t *incy) NOTHROW;
#ifdef BLAS_COMPLEX_RETURN_ARGUMENT
// intel
void cdotc_(blas_complex_float *ans, const hml_int_t *n, const blas_complex_float *x,
            const hml_int_t *incx, const blas_complex_float *y,
            const hml_int_t *incy) NOTHROW;
void cdotu_(blas_complex_float * ans, const hml_int_t *n, const blas_complex_float *x,
             const hml_int_t *incx, const blas_complex_float *y,
             const hml_int_t *incy) NOTHROW;
#else 
blas_complex_float cdotc_(const hml_int_t *n, const blas_complex_float *x,
                           const hml_int_t *incx, const blas_complex_float *y,
                           const hml_int_t *incy) NOTHROW;
blas_complex_float cdotu_(const hml_int_t *n, const blas_complex_float *x,
                           const hml_int_t *incx, const blas_complex_float *y,
                           const hml_int_t *incy) NOTHROW;
#endif 
void crot_(const hml_int_t *n, blas_complex_float *x, const hml_int_t *incx,
           blas_complex_float *y, const hml_int_t *incy, const float *c,
           const blas_complex_float *s) NOTHROW;
void crotg_(blas_complex_float *a, const blas_complex_float *b, float *c,
            blas_complex_float *s) NOTHROW;
void cscal_(const hml_int_t *n, const blas_complex_float *a,
            blas_complex_float *x, const hml_int_t *incx) NOTHROW;
void csrot_(const hml_int_t *n, blas_complex_float *x, const hml_int_t *incx,
            blas_complex_float *y, const hml_int_t *incy, const float *c,
            const float *s) NOTHROW;
void csscal_(const hml_int_t *n, const float *a, blas_complex_float *x,
             const hml_int_t *incx) NOTHROW;
void cswap_(const hml_int_t *n, blas_complex_float *x, const hml_int_t *incx,
            blas_complex_float *y, const hml_int_t *incy) NOTHROW;
void caxpby_(const hml_int_t *n, const blas_complex_float *alpha,
            const blas_complex_float *x, const hml_int_t *incx,
            const blas_complex_float *beta, blas_complex_float *y,
            const hml_int_t *incy) NOTHROW;
hml_int_t icamax_(const hml_int_t *n, const blas_complex_float *x,
                  const hml_int_t *incx) NOTHROW;
// hml_int_t icamin_(const hml_int_t *n, const blas_complex_float *x, const
// hml_int_t *incx) NOTHROW;
void cdotcsub_(const hml_int_t *n, const blas_complex_float *x, const hml_int_t *incx, const blas_complex_float *y, const hml_int_t *incy, blas_complex_float* ret) NOTHROW;
void cdotusub_(const hml_int_t *n, const blas_complex_float *x, const hml_int_t *incx, const blas_complex_float *y, const hml_int_t *incy, blas_complex_float* ret) NOTHROW;
void icamaxsub_(const hml_int_t *n, const blas_complex_float *x, const hml_int_t *incx, hml_int_t* ret) NOTHROW; 

void zaxpy_(const hml_int_t *n, const blas_complex_double *alpha,
           const blas_complex_double *x, const hml_int_t *incx,
           blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zcopy_(const hml_int_t *n, const blas_complex_double *x,
           const hml_int_t *incx, blas_complex_double *y,
           const hml_int_t *incy) NOTHROW;
        
           
#ifdef BLAS_COMPLEX_RETURN_ARGUMENT
// intel
void zdotc_(blas_complex_double * ans, const hml_int_t *n,
           const blas_complex_double *x, const hml_int_t *incx,
           const blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zdotu_(blas_complex_double * ans, const hml_int_t *n,
           const blas_complex_double *x, const hml_int_t *incx,
           const blas_complex_double *y, const hml_int_t *incy) NOTHROW;
#else 
blas_complex_double zdotc_(const hml_int_t *n,
           const blas_complex_double *x, const hml_int_t *incx,
           const blas_complex_double *y, const hml_int_t *incy) NOTHROW;
blas_complex_double zdotu_(const hml_int_t *n,
           const blas_complex_double *x, const hml_int_t *incx,
           const blas_complex_double *y, const hml_int_t *incy) NOTHROW;
#endif 
void zdrot_(const hml_int_t *n, blas_complex_double *x, const hml_int_t *incx,
           blas_complex_double *y, const hml_int_t *incy, const double *c,
           const double *s) NOTHROW;
void zdscal_(const hml_int_t *n, const double *a, blas_complex_double *x,
            const hml_int_t *incx) NOTHROW;
void zrot_(const hml_int_t *n, blas_complex_double *x, const hml_int_t *incx,
          blas_complex_double *y, const hml_int_t *incy, const double *c,
          const blas_complex_double *s) NOTHROW;
void zrotg_(blas_complex_double *a, const blas_complex_double *b, double *c,
           blas_complex_double *s) NOTHROW;
void zscal_(const hml_int_t *n, const blas_complex_double *a,
           blas_complex_double *x, const hml_int_t *incx) NOTHROW;
void zswap_(const hml_int_t *n, blas_complex_double *x, const hml_int_t *incx,
           blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zaxpby_(const hml_int_t *n, const blas_complex_double *alpha,
            const blas_complex_double *x, const hml_int_t *incx,
            const blas_complex_double *beta, blas_complex_double *y,
            const hml_int_t *incy) NOTHROW;
hml_int_t izamax_(const hml_int_t *n, const blas_complex_double *x,
                 const hml_int_t *incx) NOTHROW;

void zdotcsub_(const hml_int_t *n, const blas_complex_double *x, const hml_int_t *incx, const blas_complex_double *y, const hml_int_t *incy, blas_complex_double* ret) NOTHROW;
void zdotusub_(const hml_int_t *n, const blas_complex_double *x, const hml_int_t *incx, const blas_complex_double *y, const hml_int_t *incy, blas_complex_double* ret) NOTHROW;
void izamaxsub_(const hml_int_t *n, const blas_complex_double *x, const hml_int_t *incx, hml_int_t* ret) NOTHROW; 

#define isamax_sub_ isamaxsub_
#define idamax_sub_ idamaxsub_
#define icamax_sub_ icamaxsub_
#define izamax_sub_ izamaxsub_
#define sdot_sub_   sdotsub_
#define ddot_sub_   ddotsub_
#define cdotc_sub_  cdotcsub_           
#define cdotu_sub_  cdotusub_   
#define zdotc_sub_  zdotcsub_           
#define zdotu_sub_  zdotusub_
#define snrm2_sub_  snrm2sub_
#define sasum_sub_  sasumsub_
#define dnrm2_sub_  dnrm2sub_
#define dasum_sub_  dasumsub_
#define scnrm2_sub_ scnrm2sub_
#define scasum_sub_ scasumsub_
#define dznrm2_sub_ dznrm2sub_
#define dzasum_sub_ dzasumsub_
#define sdsdot_sub_ sdsdotsub_
#define dsdot_sub_  dsdotsub_

// level 2

void sgbmv_(const char *trans, const hml_int_t *m, const hml_int_t *n,
           const hml_int_t *kl, const hml_int_t *ku, const float *alpha,
           const float *a, const hml_int_t *lda, const float *x,
           const hml_int_t *incx, const float *beta, float *y,
           const hml_int_t *incy) NOTHROW;
void sgemv_(const char *trans, 
            const hml_int_t *m, const hml_int_t *n,
            const float *alpha, 
            const float *a, const hml_int_t *lda,
            const float *x, const hml_int_t *incx, 
            const float *beta, 
            float *y, const hml_int_t *incy) NOTHROW;
void sger_(const hml_int_t *m, const hml_int_t *n, const float *alpha,
          const float *x, const hml_int_t *incx, const float *y,
          const hml_int_t *incy, float *a, const hml_int_t *lda) NOTHROW;
void ssbmv_(const char *uplo, const hml_int_t *n, const hml_int_t *k,
           const float *alpha, const float *a, const hml_int_t *lda,
           const float *x, const hml_int_t *incx, const float *beta, float *y,
           const hml_int_t *incy) NOTHROW;
void sspmv_(const char *uplo, const hml_int_t *n, const float *alpha,
           const float *ap, const float *x, const hml_int_t *incx,
           const float *beta, float *y, const hml_int_t *incy) NOTHROW;
void sspr_(const char *uplo, const hml_int_t *n, const float *alpha,
          const float *x, const hml_int_t *incx, float *ap) NOTHROW;
void sspr2_(const char *uplo, const hml_int_t *n, const float *alpha,
           const float *x, const hml_int_t *incx, const float *y,
           const hml_int_t *incy, float *ap) NOTHROW;
void ssymv_(const char *uplo, const hml_int_t *n, const float *alpha,
           const float *a, const hml_int_t *lda, const float *x,
           const hml_int_t *incx, const float *beta, float *y,
           const hml_int_t *incy) NOTHROW;
void ssyr_(const char *uplo, const hml_int_t *n, const float *alpha,
          const float *x, const hml_int_t *incx, float *a,
          const hml_int_t *lda) NOTHROW;
void ssyr2_(const char *uplo, const hml_int_t *n, const float *alpha,
           const float *x, const hml_int_t *incx, const float *y,
           const hml_int_t *incy, float *a, const hml_int_t *lda) NOTHROW;
void stbmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const float *a,
           const hml_int_t *lda, float *x, const hml_int_t *incx) NOTHROW;
void stbsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const float *a,
           const hml_int_t *lda, float *x, const hml_int_t *incx) NOTHROW;
void stpmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const float *ap, float *x,
           const hml_int_t *incx) NOTHROW;
void stpsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const float *ap, float *x,
           const hml_int_t *incx) NOTHROW;
void strmv_(const char *uplo, const char *transa, const char *diag,
           const hml_int_t *n, const float *a, const hml_int_t *lda, float *b,
           const hml_int_t *incx) NOTHROW;
void strsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const float *a, const hml_int_t *lda, float *x,
           const hml_int_t *incx) NOTHROW;


void dgbmv_(const char *trans, const hml_int_t *m, const hml_int_t *n,
           const hml_int_t *kl, const hml_int_t *ku, const double *alpha,
           const double *a, const hml_int_t *lda, const double *x,
           const hml_int_t *incx, const double *beta, double *y,
           const hml_int_t *incy) NOTHROW;
void dgemv_(const char *trans, 
            const hml_int_t *m, const hml_int_t *n,
            const double *alpha, 
            const double *a, const hml_int_t *lda,
            const double *x, const hml_int_t *incx, 
            const double *beta,
            double *y, const hml_int_t *incy) NOTHROW;
void dger_(const hml_int_t *m, const hml_int_t *n, const double *alpha,
          const double *x, const hml_int_t *incx, const double *y,
          const hml_int_t *incy, double *a, const hml_int_t *lda) NOTHROW;
void dsbmv_(const char *uplo, const hml_int_t *n, const hml_int_t *k,
           const double *alpha, const double *a, const hml_int_t *lda,
           const double *x, const hml_int_t *incx, const double *beta,
           double *y, const hml_int_t *incy) NOTHROW;
void dspmv_(const char *uplo, const hml_int_t *n, const double *alpha,
           const double *ap, const double *x, const hml_int_t *incx,
           const double *beta, double *y, const hml_int_t *incy) NOTHROW;
void dspr_(const char *uplo, const hml_int_t *n, const double *alpha,
          const double *x, const hml_int_t *incx, double *ap) NOTHROW;
void dspr2_(const char *uplo, const hml_int_t *n, const double *alpha,
           const double *x, const hml_int_t *incx, const double *y,
           const hml_int_t *incy, double *ap) NOTHROW;
void dsymv_(const char *uplo, const hml_int_t *n, const double *alpha,
           const double *a, const hml_int_t *lda, const double *x,
           const hml_int_t *incx, const double *beta, double *y,
           const hml_int_t *incy) NOTHROW;
void dsyr_(const char *uplo, const hml_int_t *n, const double *alpha,
          const double *x, const hml_int_t *incx, double *a,
          const hml_int_t *lda) NOTHROW;
void dsyr2_(const char *uplo, const hml_int_t *n, const double *alpha,
           const double *x, const hml_int_t *incx, const double *y,
           const hml_int_t *incy, double *a, const hml_int_t *lda) NOTHROW;
void dtbmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const double *a,
           const hml_int_t *lda, double *x, const hml_int_t *incx) NOTHROW;
void dtbsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const double *a,
           const hml_int_t *lda, double *x, const hml_int_t *incx) NOTHROW;
void dtpmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const double *ap, double *x,
           const hml_int_t *incx) NOTHROW;
void dtpsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const double *ap, double *x,
           const hml_int_t *incx) NOTHROW;
void dtrmv_(const char *uplo, const char *transa, const char *diag,
           const hml_int_t *n, const double *a, const hml_int_t *lda, double *b,
           const hml_int_t *incx) NOTHROW;
void dtrsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const double *a, const hml_int_t *lda, double *x,
           const hml_int_t *incx) NOTHROW;

void cgbmv_(const char *trans, const hml_int_t *m, const hml_int_t *n,
           const hml_int_t *kl, const hml_int_t *ku,
           const blas_complex_float *alpha, 
           const blas_complex_float *a, const hml_int_t *lda, 
           const blas_complex_float *x, const hml_int_t *incx, 
           const blas_complex_float *beta,
           blas_complex_float *y, const hml_int_t *incy) NOTHROW;
void cgemv_(const char *trans, 
            const hml_int_t *m, const hml_int_t *n,
            const blas_complex_float *alpha, 
            const blas_complex_float *a, const hml_int_t *lda, 
            const blas_complex_float *x, const hml_int_t *incx, 
            const blas_complex_float *beta,
            blas_complex_float *y, const hml_int_t *incy) NOTHROW;
void cgerc_(const hml_int_t *m, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *y,
           const hml_int_t *incy, blas_complex_float *a,
           const hml_int_t *lda) NOTHROW;
void cgeru_(const hml_int_t *m, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *y,
           const hml_int_t *incy, blas_complex_float *a,
           const hml_int_t *lda) NOTHROW;
void chbmv_(const char *uplo, const hml_int_t *n, const hml_int_t *k,
           const blas_complex_float *alpha, const blas_complex_float *a,
           const hml_int_t *lda, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *beta,
           blas_complex_float *y, const hml_int_t *incy) NOTHROW;
void chemv_(const char *uplo, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *a,
           const hml_int_t *lda, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *beta,
           blas_complex_float *y, const hml_int_t *incy) NOTHROW;
void cher_(const char *uplo, const hml_int_t *n, const float *alpha,
          const blas_complex_float *x, const hml_int_t *incx,
          blas_complex_float *a, const hml_int_t *lda) NOTHROW;
void cher2_(const char *uplo, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *y,
           const hml_int_t *incy, blas_complex_float *a,
           const hml_int_t *lda) NOTHROW;
void chpmv_(const char *uplo, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *ap,
           const blas_complex_float *x, const hml_int_t *incx,
           const blas_complex_float *beta, blas_complex_float *y,
           const hml_int_t *incy) NOTHROW;
void chpr_(const char *uplo, const hml_int_t *n, const float *alpha,
          const blas_complex_float *x, const hml_int_t *incx,
          blas_complex_float *ap) NOTHROW;
void chpr2_(const char *uplo, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *y,
           const hml_int_t *incy, blas_complex_float *ap) NOTHROW;
void csymv_(const char *uplo, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *a,
           const hml_int_t *lda, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *beta,
           blas_complex_float *y, const hml_int_t *incy) NOTHROW;
void csyr_(const char *uplo, const hml_int_t *n,
          const blas_complex_float *alpha, const blas_complex_float *x,
          const hml_int_t *incx, blas_complex_float *a,
          const hml_int_t *lda) NOTHROW;
void csyr2_(const char *uplo, const hml_int_t *n,
           const blas_complex_float *alpha, const blas_complex_float *x,
           const hml_int_t *incx, const blas_complex_float *y,
           const hml_int_t *incy, blas_complex_float *a,
           const hml_int_t *lda) NOTHROW;
void ctbmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const blas_complex_float *a,
           const hml_int_t *lda, blas_complex_float *x,
           const hml_int_t *incx) NOTHROW;
void ctbsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const blas_complex_float *a,
           const hml_int_t *lda, blas_complex_float *x,
           const hml_int_t *incx) NOTHROW;
void ctpmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const blas_complex_float *ap,
           blas_complex_float *x, const hml_int_t *incx) NOTHROW;
void ctpsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const blas_complex_float *ap,
           blas_complex_float *x, const hml_int_t *incx) NOTHROW;
void ctrmv_(const char *uplo, const char *transa, const char *diag,
           const hml_int_t *n, const blas_complex_float *a,
           const hml_int_t *lda, blas_complex_float *b,
           const hml_int_t *incx) NOTHROW;
void ctrsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const blas_complex_float *a,
           const hml_int_t *lda, blas_complex_float *x,
           const hml_int_t *incx) NOTHROW;

void zgbmv_(const char *trans, const hml_int_t *m, const hml_int_t *n,
           const hml_int_t *kl, const hml_int_t *ku,
           const blas_complex_double *alpha, const blas_complex_double *a,
           const hml_int_t *lda, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *beta,
           blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zgemv_(const char *trans, 
            const hml_int_t *m, const hml_int_t *n,
            const blas_complex_double *alpha, 
            const blas_complex_double *a, const hml_int_t *lda, 
            const blas_complex_double *x, const hml_int_t *incx, 
            const blas_complex_double *beta,
            blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zgerc_(const hml_int_t *m, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *y,
           const hml_int_t *incy, blas_complex_double *a,
           const hml_int_t *lda) NOTHROW;
void zgeru_(const hml_int_t *m, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *y,
           const hml_int_t *incy, blas_complex_double *a,
           const hml_int_t *lda) NOTHROW;
void zhbmv_(const char *uplo, const hml_int_t *n, const hml_int_t *k,
           const blas_complex_double *alpha, const blas_complex_double *a,
           const hml_int_t *lda, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *beta,
           blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zhemv_(const char *uplo, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *a,
           const hml_int_t *lda, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *beta,
           blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zher_(const char *uplo, const hml_int_t *n, const double *alpha,
          const blas_complex_double *x, const hml_int_t *incx,
          blas_complex_double *a, const hml_int_t *lda) NOTHROW;
void zher2_(const char *uplo, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *y,
           const hml_int_t *incy, blas_complex_double *a,
           const hml_int_t *lda) NOTHROW;
void zhpmv_(const char *uplo, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *ap,
           const blas_complex_double *x, const hml_int_t *incx,
           const blas_complex_double *beta, blas_complex_double *y,
           const hml_int_t *incy) NOTHROW;
void zhpr_(const char *uplo, const hml_int_t *n, const double *alpha,
          const blas_complex_double *x, const hml_int_t *incx,
          blas_complex_double *ap) NOTHROW;
void zhpr2_(const char *uplo, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *y,
           const hml_int_t *incy, blas_complex_double *ap) NOTHROW;
void zsymv_(const char *uplo, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *a,
           const hml_int_t *lda, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *beta,
           blas_complex_double *y, const hml_int_t *incy) NOTHROW;
void zsyr_(const char *uplo, const hml_int_t *n,
          const blas_complex_double *alpha, const blas_complex_double *x,
          const hml_int_t *incx, blas_complex_double *a,
          const hml_int_t *lda) NOTHROW;
void zsyr2_(const char *uplo, const hml_int_t *n,
           const blas_complex_double *alpha, const blas_complex_double *x,
           const hml_int_t *incx, const blas_complex_double *y,
           const hml_int_t *incy, blas_complex_double *a,
           const hml_int_t *lda) NOTHROW;
void ztbmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const blas_complex_double *a,
           const hml_int_t *lda, blas_complex_double *x,
           const hml_int_t *incx) NOTHROW;
void ztbsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const hml_int_t *k, const blas_complex_double *a,
           const hml_int_t *lda, blas_complex_double *x,
           const hml_int_t *incx) NOTHROW;
void ztpmv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const blas_complex_double *ap,
           blas_complex_double *x, const hml_int_t *incx) NOTHROW;
void ztpsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const blas_complex_double *ap,
           blas_complex_double *x, const hml_int_t *incx) NOTHROW;
void ztrmv_(const char *uplo, const char *transa, const char *diag,
           const hml_int_t *n, const blas_complex_double *a,
           const hml_int_t *lda, blas_complex_double *b,
           const hml_int_t *incx) NOTHROW;
void ztrsv_(const char *uplo, const char *trans, const char *diag,
           const hml_int_t *n, const blas_complex_double *a,
           const hml_int_t *lda, blas_complex_double *x,
           const hml_int_t *incx) NOTHROW;

// levle 3

void sgemm_(const char *transa, const char *transb, 
            const hml_int_t *m, const hml_int_t *n, const hml_int_t *k, 
            const float *alpha,
            const float *a, const hml_int_t *lda, 
            const float *b, const hml_int_t *ldb, 
            const float *beta, 
            float *c, const hml_int_t *ldc) NOTHROW;
void sgemmt_(const char *uplo, const char *transa, const char *transb,
             const hml_int_t *n, const hml_int_t *k, 
             const float *alpha,
             const float *a, const hml_int_t *lda, 
             const float *b, const hml_int_t *ldb, 
             const float *beta, 
             float *c, const hml_int_t *ldc) NOTHROW;
void ssymm_(const char *side, const char *uplo, 
            const hml_int_t *m, const hml_int_t *n, 
            const float *alpha, 
            const float *a, const hml_int_t *lda, 
            const float *b, const hml_int_t *ldb,
            const float *beta, 
            float *c, const hml_int_t *ldc) NOTHROW;
void ssyr2k_(const char *uplo, const char *trans, 
             const hml_int_t *n, const hml_int_t *k, 
             const float *alpha, 
             const float *a, const hml_int_t *lda, 
             const float *b, const hml_int_t *ldb,
             const float *beta, 
             float *c, const hml_int_t *ldc) NOTHROW;
void ssyrk_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const float *alpha, 
            const float *a, const hml_int_t *lda, 
            const float *beta, 
            float *c, const hml_int_t *ldc) NOTHROW;
void strmm_(const char *side, const char *uplo, const char *transa, const char *diag, 
           const hml_int_t *m, const hml_int_t *n,
           const float *alpha, 
           const float *a, const hml_int_t *lda, 
           float *b,  const hml_int_t *ldb) NOTHROW;
void strsm_(const char *side, const char *uplo, const char *transa, const char *diag, 
            const hml_int_t *m, const hml_int_t *n,
            const float *alpha, 
            const float *a, const hml_int_t *lda, 
            float *b, const hml_int_t *ldb) NOTHROW; 

void dgemm_(const char *transa, const char *transb, 
            const hml_int_t *m, const hml_int_t *n, const hml_int_t *k, 
            const double *alpha,
            const double *a, const hml_int_t *lda, 
            const double *b, const hml_int_t *ldb, 
            const double *beta, 
            double *c, const hml_int_t *ldc) NOTHROW;
void dgemmt_(const char *uplo, const char *transa, const char *transb,
            const hml_int_t *n, const hml_int_t *k, 
            const double *alpha,
            const double *a, const hml_int_t *lda, 
            const double *b, const hml_int_t *ldb, 
            const double *beta, 
            double *c, const hml_int_t *ldc) NOTHROW;
void dsymm_(const char *side, const char *uplo, 
            const hml_int_t *m, const hml_int_t *n, 
            const double *alpha, 
            const double *a, const hml_int_t *lda, 
            const double *b, const hml_int_t *ldb,
            const double *beta, 
            double *c, const hml_int_t *ldc) NOTHROW;
void dsyr2k_(const char *uplo, const char *trans, 
             const hml_int_t *n, const hml_int_t *k, 
             const double *alpha, 
             const double *a, const hml_int_t *lda, 
             const double *b, const hml_int_t *ldb,
             const double *beta, 
             double *c, const hml_int_t *ldc) NOTHROW;
void dsyrk_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const double *alpha, 
            const double *a, const hml_int_t *lda, 
            const double *beta, 
            double *c, const hml_int_t *ldc) NOTHROW;
void dtrmm_(const char *side, const char *uplo, const char *transa, const char *diag, 
            const hml_int_t *m, const hml_int_t *n,
            const double *alpha, 
            const double *a, const hml_int_t *lda,
            double *b, const hml_int_t *ldb) NOTHROW;
void dtrsm_(const char *side, const char *uplo, const char *transa, const char *diag, 
            const hml_int_t *m, const hml_int_t *n,
            const double *alpha, 
            const double *a, const hml_int_t *lda,
            double *b, const hml_int_t *ldb) NOTHROW;

void cgemm_(const char *transa, const char *transb, const hml_int_t *m,
           const hml_int_t *n, const hml_int_t *k,
           const blas_complex_float *alpha, const blas_complex_float *a,
           const hml_int_t *lda, const blas_complex_float *b,
           const hml_int_t *ldb, const blas_complex_float *beta,
           blas_complex_float *c, const hml_int_t *ldc) NOTHROW;

void cgemm3m_(const char *transa, const char *transb, const hml_int_t *m,
              const hml_int_t *n, const hml_int_t *k,
              const blas_complex_float *alpha, const blas_complex_float *a,
              const hml_int_t *lda, const blas_complex_float *b,
              const hml_int_t *ldb, const blas_complex_float *beta,
              blas_complex_float *c, const hml_int_t *ldc) NOTHROW;

void cgemmt_(const char *uplo, const char *transa, const char *transb,
            const hml_int_t *n, const hml_int_t *k,
            const blas_complex_float *alpha, 
            const blas_complex_float *a, const hml_int_t *lda, 
            const blas_complex_float *b, const hml_int_t *ldb, 
            const blas_complex_float *beta,
            blas_complex_float *c, const hml_int_t *ldc) NOTHROW;
void chemm_(const char *side, const char *uplo, 
            const hml_int_t *m, const hml_int_t *n, 
            const blas_complex_float *alpha,
            const blas_complex_float *a, const hml_int_t *lda,
            const blas_complex_float *b, const hml_int_t *ldb,
            const blas_complex_float *beta, 
            blas_complex_float *c, const hml_int_t *ldc) NOTHROW;
void cher2k_(const char *uplo, const char *trans, 
             const hml_int_t *n, const hml_int_t *k, 
             const blas_complex_float *alpha,
             const blas_complex_float *a, const hml_int_t *lda,
             const blas_complex_float *b, const hml_int_t *ldb,
             const float *beta, 
             blas_complex_float *c, const hml_int_t *ldc) NOTHROW;
void cherk_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const float *alpha, 
            const blas_complex_float *a, const hml_int_t *lda, 
            const float *beta, 
            blas_complex_float *c, const hml_int_t *ldc) NOTHROW;
void csymm_(const char *side, const char *uplo, 
            const hml_int_t *m, const hml_int_t *n, 
            const blas_complex_float *alpha,
            const blas_complex_float *a, const hml_int_t *lda,
            const blas_complex_float *b, const hml_int_t *ldb,
            const blas_complex_float *beta, 
            blas_complex_float *c, const hml_int_t *ldc) NOTHROW;
void csyr2k_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const blas_complex_float *alpha,
            const blas_complex_float *a, const hml_int_t *lda,
            const blas_complex_float *b, const hml_int_t *ldb,
            const blas_complex_float *beta, 
            blas_complex_float *c, const hml_int_t *ldc) NOTHROW;
void csyrk_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const blas_complex_float *alpha,
            const blas_complex_float *a, const hml_int_t *lda,
            const blas_complex_float *beta, 
            blas_complex_float *c, const hml_int_t *ldc) NOTHROW;
void ctrmm_(const char *side, const char *uplo, const char *transa, const char *diag, 
            const hml_int_t *m, const hml_int_t *n,
            const blas_complex_float *alpha, 
            const blas_complex_float *a, const hml_int_t *lda, 
            blas_complex_float *b, const hml_int_t *ldb) NOTHROW;
void ctrsm_(const char *side, const char *uplo, const char *transa, const char *diag, 
            const hml_int_t *m, const hml_int_t *n,
            const blas_complex_float *alpha, 
            const blas_complex_float *a, const hml_int_t *lda, 
            blas_complex_float *b, const hml_int_t *ldb) NOTHROW;

void zgemm_(const char *transa, const char *transb, 
            const hml_int_t *m, const hml_int_t *n, const hml_int_t *k,
           const blas_complex_double *alpha, 
           const blas_complex_double *a, const hml_int_t *lda, 
           const blas_complex_double *b, const hml_int_t *ldb, 
           const blas_complex_double *beta,
           blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void zgemm3m_(const char *transa, const char *transb, const hml_int_t *m,
             const hml_int_t *n, const hml_int_t *k,
             const blas_complex_double *alpha, const blas_complex_double *a,
             const hml_int_t *lda, const blas_complex_double *b,
             const hml_int_t *ldb, const blas_complex_double *beta,
             blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void zgemmt_(const char *uplo, const char *transa, const char *transb,
            const hml_int_t *n, const hml_int_t *k,
            const blas_complex_double *alpha, 
            const blas_complex_double *a, const hml_int_t *lda, 
            const blas_complex_double *b, const hml_int_t *ldb, 
            const blas_complex_double *beta,
            blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void zhemm_(const char *side, const char *uplo, 
            const hml_int_t *m, const hml_int_t *n, 
            const blas_complex_double *alpha,
            const blas_complex_double *a, const hml_int_t *lda,
            const blas_complex_double *b, const hml_int_t *ldb,
            const blas_complex_double *beta, 
            blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void zher2k_(const char *uplo, const char *trans, 
             const hml_int_t *n, const hml_int_t *k, 
             const blas_complex_double *alpha,
             const blas_complex_double *a, const hml_int_t *lda,
             const blas_complex_double *b, const hml_int_t *ldb,
             const double *beta, 
             blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void zherk_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const double *alpha,
            const blas_complex_double *a, const hml_int_t *lda,
            const double *beta, 
            blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void zsymm_(const char *side, const char *uplo, 
            const hml_int_t *m, const hml_int_t *n, 
            const blas_complex_double *alpha,
            const blas_complex_double *a, const hml_int_t *lda,
            const blas_complex_double *b, const hml_int_t *ldb,
            const blas_complex_double *beta, 
            blas_complex_double *c,
            const hml_int_t *ldc) NOTHROW;
void zsyr2k_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const blas_complex_double *alpha,
            const blas_complex_double *a, const hml_int_t *lda,
            const blas_complex_double *b, const hml_int_t *ldb,
            const blas_complex_double *beta, 
            blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void zsyrk_(const char *uplo, const char *trans, 
            const hml_int_t *n, const hml_int_t *k, 
            const blas_complex_double *alpha,
            const blas_complex_double *a, const hml_int_t *lda,
            const blas_complex_double *beta, 
            blas_complex_double *c, const hml_int_t *ldc) NOTHROW;
void ztrmm_(const char *side, const char *uplo, const char *transa, const char *diag, 
            const hml_int_t *m, const hml_int_t *n, 
            const blas_complex_double *alpha, 
            const blas_complex_double *a, const hml_int_t *lda, 
            blas_complex_double *b, const hml_int_t *ldb) NOTHROW;
void ztrsm_(const char *side, const char *uplo, const char *transa, const char *diag, 
            const hml_int_t *m, const hml_int_t *n, 
            const blas_complex_double *alpha, 
            const blas_complex_double *a, const hml_int_t *lda, 
            blas_complex_double *b, const hml_int_t *ldb) NOTHROW;

#define sgemmtr_ sgemmt_
#define dgemmtr_ dgemmt_
#define cgemmtr_ cgemmt_
#define zgemmtr_ zgemmt_

/// 2. batch            =============================

void sgemm_batch_(const char *transa_array, const char *transb_array,
                 const hml_int_t *m_array, const hml_int_t *n_array,
                 const hml_int_t *k_array, const float *alpha_array,
                 const float **a_array, const hml_int_t *lda_array,
                 const float **b_array, const hml_int_t *ldb_array,
                 const float *beta_array, float **c_array,
                 const hml_int_t *ldc_array, const hml_int_t *group_count,
                 const hml_int_t *group_size) NOTHROW;
void dgemm_batch_(const char *transa_array, const char *transb_array,
                 const hml_int_t *m_array, const hml_int_t *n_array,
                 const hml_int_t *k_array, const double *alpha_array,
                 const double **a_array, const hml_int_t *lda_array,
                 const double **b_array, const hml_int_t *ldb_array,
                 const double *beta_array, double **c_array,
                 const hml_int_t *ldc_array, const hml_int_t *group_count,
                 const hml_int_t *group_size) NOTHROW;
void cgemm_batch_(const char *transa_array, const char *transb_array,
                 const hml_int_t *m_array, const hml_int_t *n_array,
                 const hml_int_t *k_array,
                 const blas_complex_float *alpha_array,
                 const blas_complex_float **a_array, const hml_int_t *lda_array,
                 const blas_complex_float **b_array, const hml_int_t *ldb_array,
                 const blas_complex_float *beta_array,
                 blas_complex_float **c_array, const hml_int_t *ldc_array,
                 const hml_int_t *group_count,
                 const hml_int_t *group_size) NOTHROW;
void zgemm_batch_(
    const char *transa_array, const char *transb_array,
    const hml_int_t *m_array, const hml_int_t *n_array,
    const hml_int_t *k_array, const blas_complex_double *alpha_array,
    const blas_complex_double **a_array, const hml_int_t *lda_array,
    const blas_complex_double **b_array, const hml_int_t *ldb_array,
    const blas_complex_double *beta_array, blas_complex_double **c_array,
    const hml_int_t *ldc_array, const hml_int_t *group_count,
    const hml_int_t *group_size) NOTHROW;



/// 3. entend           =============================
/// @brief 获取当前调用线程请求的线程数。
///        消费正的 local 覆盖；活动 OpenMP 并行区内返回 1，
///        不消费 local。实际运算可以使用更少线程。
/// @return 请求的正线程数。
int  hml_blas_get_num_threads();
/// @brief 设置当前调用线程持久的 HML 线程数请求。
/// @param[in]     nt  请求线程数；非正值表示清除 HML 覆盖。
void hml_blas_set_num_threads(int nt);
/// @brief 设置当前调用线程下一次消费查询使用的线程数。
/// @param[in]     nt  请求线程数；非正值表示清除 local 覆盖。
void hml_blas_set_local_threads(int nt);

///  mkl style
void hml_somatcopy(char ordering, char trans, size_t rows, size_t cols, const float alpha, const float* A, size_t lda, float* B, size_t ldb);
void hml_domatcopy(char ordering, char trans, size_t rows, size_t cols, const double alpha, const double *A, size_t lda, double *B, size_t ldb);
void hml_comatcopy(char ordering, char trans, size_t rows, size_t cols, const void *alpha, const void *A, size_t lda, void *B, size_t ldb);
void hml_zomatcopy(char ordering, char trans, size_t rows, size_t cols, const void *alpha, const void *A, size_t lda, void *B, size_t ldb);

///  imatcopy / omatcopy / omatcopy2 / omatadd (f77-style) =========
void simatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const float *alpha, float *a, const hml_int_t *lda,
               const hml_int_t *ldb) NOTHROW;
void dimatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const double *alpha, double *a, const hml_int_t *lda,
               const hml_int_t *ldb) NOTHROW;
void cimatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const blas_complex_float *alpha, blas_complex_float *a,
               const hml_int_t *lda, const hml_int_t *ldb) NOTHROW;
void zimatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const blas_complex_double *alpha, blas_complex_double *a,
               const hml_int_t *lda, const hml_int_t *ldb) NOTHROW;

void somatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const float *alpha, const float *a, const hml_int_t *lda,
               float *b, const hml_int_t *ldb) NOTHROW;
void domatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const double *alpha, const double *a, const hml_int_t *lda,
               double *b, const hml_int_t *ldb) NOTHROW;
void comatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const blas_complex_float *alpha, const blas_complex_float *a,
               const hml_int_t *lda, blas_complex_float *b,
               const hml_int_t *ldb) NOTHROW;
void zomatcopy_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
               const blas_complex_double *alpha, const blas_complex_double *a,
               const hml_int_t *lda, blas_complex_double *b,
               const hml_int_t *ldb) NOTHROW;

void somatcopy2_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
                const float *alpha, const float *a, const hml_int_t *lda,
                const hml_int_t *stridea, float *b, const hml_int_t *ldb,
                const hml_int_t *strideb) NOTHROW;
void domatcopy2_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
                const double *alpha, const double *a, const hml_int_t *lda,
                const hml_int_t *stridea, double *b, const hml_int_t *ldb,
                const hml_int_t *strideb) NOTHROW;
void comatcopy2_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
                const blas_complex_float *alpha, const blas_complex_float *a,
                const hml_int_t *lda, const hml_int_t *stridea,
                blas_complex_float *b, const hml_int_t *ldb,
                const hml_int_t *strideb) NOTHROW;
void zomatcopy2_(const char *trans, const hml_int_t *rows, const hml_int_t *cols,
                const blas_complex_double *alpha, const blas_complex_double *a,
                const hml_int_t *lda, const hml_int_t *stridea,
                blas_complex_double *b, const hml_int_t *ldb,
                const hml_int_t *strideb) NOTHROW;

void somatadd_(const char *transa, const char *transb, const hml_int_t *m,
              const hml_int_t *n, const float *alpha, const float *a,
              const hml_int_t *lda, const float *beta, const float *b,
              const hml_int_t *ldb, float *c, const hml_int_t *ldc) NOTHROW;
void domatadd_(const char *transa, const char *transb, const hml_int_t *m,
              const hml_int_t *n, const double *alpha, const double *a,
              const hml_int_t *lda, const double *beta, const double *b,
              const hml_int_t *ldb, double *c, const hml_int_t *ldc) NOTHROW;
void comatadd_(const char *transa, const char *transb, const hml_int_t *m,
              const hml_int_t *n, const blas_complex_float *alpha,
              const blas_complex_float *a, const hml_int_t *lda,
              const blas_complex_float *beta, const blas_complex_float *b,
              const hml_int_t *ldb, blas_complex_float *c,
              const hml_int_t *ldc) NOTHROW;
void zomatadd_(const char *transa, const char *transb, const hml_int_t *m,
              const hml_int_t *n, const blas_complex_double *alpha,
              const blas_complex_double *a, const hml_int_t *lda,
              const blas_complex_double *beta, const blas_complex_double *b,
              const hml_int_t *ldb, blas_complex_double *c,
              const hml_int_t *ldc) NOTHROW;

#ifdef __cplusplus
}
#endif  // __cplusplus

#endif  // HML_BLAS_H
