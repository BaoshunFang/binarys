#pragma once

/**
 * @brief header for all hml_sparse public APIs;
 */

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#include "hml_sparse/types.h" // basic type define
#include "hml_sparse/opt.h"   // optimazation
#include "hml_sparse/spdef.h" // hml_sparse type define
#include "hml_sparse/spapi.h" // hml_sparse API

#include "hml_sparse/util/assert.h"
#include "hml_sparse/util/check.h"
#include "hml_sparse/util/error.h"
#include "hml_sparse/util/malloc.h"
#include "hml_sparse/util/random.h"
#include "hml_sparse/util/timing.h"
#include "hml_sparse/util/partition.h"
#include "hml_sparse/util/args.h"
#include "hml_sparse/util/bisearch.h"
#include "hml_sparse/util/analysis.h"
#include "hml_sparse/util/io.h"
#include "hml_sparse/util/algebra.h"

#ifdef __cplusplus
}
#endif /*__cplusplus */
