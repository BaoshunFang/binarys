
#ifndef HYGONVML_EXPORT_H
#define HYGONVML_EXPORT_H

#ifdef HYGONVML_STATIC_DEFINE
#  define HYGONVML_EXPORT
#  define HYGONVML_NO_EXPORT
#else
#  ifndef HYGONVML_EXPORT
#    ifdef hvml_EXPORTS
        /* We are building this library */
#      define HYGONVML_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define HYGONVML_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef HYGONVML_NO_EXPORT
#    define HYGONVML_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef HYGONVML_DEPRECATED
#  define HYGONVML_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef HYGONVML_DEPRECATED_EXPORT
#  define HYGONVML_DEPRECATED_EXPORT HYGONVML_EXPORT HYGONVML_DEPRECATED
#endif

#ifndef HYGONVML_DEPRECATED_NO_EXPORT
#  define HYGONVML_DEPRECATED_NO_EXPORT HYGONVML_NO_EXPORT HYGONVML_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef HYGONVML_NO_DEPRECATED
#    define HYGONVML_NO_DEPRECATED
#  endif
#endif

#endif /* HYGONVML_EXPORT_H */
