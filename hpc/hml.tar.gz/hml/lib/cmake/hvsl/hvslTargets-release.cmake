#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hvsl::hvsl" for configuration "Release"
set_property(TARGET hvsl::hvsl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hvsl::hvsl PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhvsl.so.0.1.0"
  IMPORTED_SONAME_RELEASE "libhvsl.so.0"
  )

list(APPEND _cmake_import_check_targets hvsl::hvsl )
list(APPEND _cmake_import_check_files_for_hvsl::hvsl "${_IMPORT_PREFIX}/lib/libhvsl.so.0.1.0" )

# Import target "hvsl::hvsl_static" for configuration "Release"
set_property(TARGET hvsl::hvsl_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hvsl::hvsl_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhvsl.a"
  )

list(APPEND _cmake_import_check_targets hvsl::hvsl_static )
list(APPEND _cmake_import_check_files_for_hvsl::hvsl_static "${_IMPORT_PREFIX}/lib/libhvsl.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
