#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "scalapack" for configuration ""
set_property(TARGET scalapack APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(scalapack PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libhscalapack.so.1.6.0"
  IMPORTED_SONAME_NOCONFIG "libhscalapack.so.1.6"
  )

list(APPEND _cmake_import_check_targets scalapack )
list(APPEND _cmake_import_check_files_for_scalapack "${_IMPORT_PREFIX}/lib/libhscalapack.so.1.6.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
