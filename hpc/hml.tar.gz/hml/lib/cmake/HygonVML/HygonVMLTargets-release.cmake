#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "HygonVML::hvml" for configuration "Release"
set_property(TARGET HygonVML::hvml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(HygonVML::hvml PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhvml.so.1.9.19"
  IMPORTED_SONAME_RELEASE "libhvml.so.1"
  )

list(APPEND _cmake_import_check_targets HygonVML::hvml )
list(APPEND _cmake_import_check_files_for_HygonVML::hvml "${_IMPORT_PREFIX}/lib/libhvml.so.1.9.19" )

# Import target "HygonVML::hvml_static" for configuration "Release"
set_property(TARGET HygonVML::hvml_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(HygonVML::hvml_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhvml.a"
  )

list(APPEND _cmake_import_check_targets HygonVML::hvml_static )
list(APPEND _cmake_import_check_files_for_HygonVML::hvml_static "${_IMPORT_PREFIX}/lib/libhvml.a" )

# Import target "HygonVML::hlm_static" for configuration "Release"
set_property(TARGET HygonVML::hlm_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(HygonVML::hlm_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM;C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhlm.a"
  )

list(APPEND _cmake_import_check_targets HygonVML::hlm_static )
list(APPEND _cmake_import_check_files_for_HygonVML::hlm_static "${_IMPORT_PREFIX}/lib/libhlm.a" )

# Import target "HygonVML::hlm" for configuration "Release"
set_property(TARGET HygonVML::hlm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(HygonVML::hlm PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhlm.so.1.9.19"
  IMPORTED_SONAME_RELEASE "libhlm.so.1"
  )

list(APPEND _cmake_import_check_targets HygonVML::hlm )
list(APPEND _cmake_import_check_files_for_HygonVML::hlm "${_IMPORT_PREFIX}/lib/libhlm.so.1.9.19" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
