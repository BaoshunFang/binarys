# ==========================================================================
# HygonVMLConfig.cmake - CMake package configuration for HygonVML.
#
# Consumed by downstream projects via:
#
#   find_package(HygonVML 1.9 REQUIRED)
#   target_link_libraries(app PRIVATE HygonVML::hvml)   # vector, shared
#   target_link_libraries(app PRIVATE HygonVML::hlm)    # scalar, shared
#
# Optional components map to the four buildable artifacts:
#
#   find_package(HygonVML REQUIRED COMPONENTS hvml_static hlm_static)
#
# All paths below are derived from the location of this file at find_package()
# time (see 
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was HygonVMLConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

#################################################################################### / PACKAGE_PREFIX_DIR), so nothing here is tied to
# the prefix that was configured at build time.
# ==========================================================================


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was HygonVMLConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

set(HygonVML_VERSION "1.9.19")
set(HygonVML_GIT_VERSION "028c75f")

set_and_check(HygonVML_INCLUDE_DIR "${PACKAGE_PREFIX_DIR}/include")
set_and_check(HygonVML_LIBRARY_DIR "${PACKAGE_PREFIX_DIR}/lib")

# Kept for projects that predate imported targets; prefer the targets.
set(HygonVML_INCLUDE_DIRS "${HygonVML_INCLUDE_DIR}")

include("${CMAKE_CURRENT_LIST_DIR}/HygonVMLTargets.cmake")

# Advertise which artifacts this install actually shipped, so that
# find_package(... COMPONENTS ...) fails loudly instead of silently
# handing back a target that was never built.
foreach(_hvml_comp hvml;hvml_static;hlm_static;hlm)
  if(TARGET HygonVML::${_hvml_comp})
    set(HygonVML_${_hvml_comp}_FOUND TRUE)
  endif()
endforeach()
unset(_hvml_comp)

if(TARGET HygonVML::hvml)
  set(HygonVML_LIBRARIES HygonVML::hvml)
elseif(TARGET HygonVML::hvml_static)
  set(HygonVML_LIBRARIES HygonVML::hvml_static)
endif()

check_required_components(HygonVML)
