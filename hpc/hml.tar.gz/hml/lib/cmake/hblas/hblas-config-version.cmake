# hblas-config-version.cmake - version checking for find_package(hblas).
#
# SameMajorVersion semantics: the requested version must not be newer than
# this package, and its major version must match.
# This file is generated from hblas-config-version.cmake.in by either the
# configure+make build (via sed) or the CMake build (via configure_file).

set(PACKAGE_VERSION "1.9.3")

if(PACKAGE_VERSION VERSION_LESS PACKAGE_FIND_VERSION)
  set(PACKAGE_VERSION_COMPATIBLE FALSE)
else()
  if(NOT PACKAGE_FIND_VERSION_MAJOR STREQUAL "1")
    set(PACKAGE_VERSION_COMPATIBLE FALSE)
  else()
    set(PACKAGE_VERSION_COMPATIBLE TRUE)
  endif()
  if(PACKAGE_FIND_VERSION STREQUAL PACKAGE_VERSION)
    set(PACKAGE_VERSION_EXACT TRUE)
  endif()
endif()
