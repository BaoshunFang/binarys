#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hblas::hblas" for configuration "Release"
set_property(TARGET hblas::hblas APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hblas::hblas PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhblas.so.1.9.3"
  IMPORTED_SONAME_RELEASE "libhblas.so.1"
  )

list(APPEND _cmake_import_check_targets hblas::hblas )
list(APPEND _cmake_import_check_files_for_hblas::hblas "${_IMPORT_PREFIX}/lib/libhblas.so.1.9.3" )

# Import target "hblas::hblas_static" for configuration "Release"
set_property(TARGET hblas::hblas_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hblas::hblas_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM;C;CXX;Fortran"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhblas.a"
  )

list(APPEND _cmake_import_check_targets hblas::hblas_static )
list(APPEND _cmake_import_check_files_for_hblas::hblas_static "${_IMPORT_PREFIX}/lib/libhblas.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
