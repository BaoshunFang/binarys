# hblas-config.cmake - CMake package configuration for HBLAS (Hygon BLAS).
#
# Usage:
#   find_package(hblas CONFIG REQUIRED)
#   target_link_libraries(your_app PRIVATE hblas::hblas)
#
# Provides the imported target:
#   hblas::hblas
# and the variables:
#   hblas_VERSION, hblas_INCLUDE_DIRS, hblas_LIBRARIES
#
# This file is generated from hblas-config.cmake.in by either the
# configure+make build (via sed) or the CMake build (via configure_file).

# Compute the install prefix from this file's location:
# <prefix>/lib/cmake/hblas/hblas-config.cmake -> <prefix>
get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

set(hblas_VERSION "1.9.3")
set(hblas_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include")

include(CMakeFindDependencyMacro)


if(NOT TARGET hblas::hblas)
  add_library(hblas::hblas SHARED IMPORTED)
  set_target_properties(hblas::hblas PROPERTIES
    IMPORTED_LOCATION "${PACKAGE_PREFIX_DIR}/lib/libhblas-seq.so"
    INTERFACE_INCLUDE_DIRECTORIES "${hblas_INCLUDE_DIRS}"
    
  )
endif()

set(hblas_LIBRARIES hblas::hblas)

unset(PACKAGE_PREFIX_DIR)
