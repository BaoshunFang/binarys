
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was hblasConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# hblas 是内嵌合并库（BLAS + LAPACK 打进同一个 libhblas）的唯一 CMake 包。
# hblas::hblas 同时提供 BLAS 与 LAPACK API；本包即完整功能集，无需再
# find_package(hlapack)。
include(CMakeFindDependencyMacro)
find_dependency(Threads)
find_dependency(OpenMP)

include("${CMAKE_CURRENT_LIST_DIR}/hblasTargets.cmake")

set(HBLAS_EMBEDS_HLAPACK TRUE)
set(HBLAS_LAPACK_VERSION "1.9.3")
set(HBLAS_VERSION "1.9.3")

check_required_components(hblas)
